#!/usr/bin/env node
/**
 * Compare the logged entry features of trades Raj took vs skipped in blind review.
 * Read-only: uses trades_<strategy>.jsonl (needs a --log run with the feature-logging engine) + viewer_notes.json.
 *
 *   node backtest/swing/features.js            # sw15p
 *   node backtest/swing/features.js sw15p
 *
 * For each feature: median for blind ✓ take vs ✗ skip, then "filter out trades where feature < x" (or > x)
 * at a few cut points: how many skips it catches, how many takes it throws away, and avg net R of what is left
 * (on ALL dev-period trades, reviewed or not). Holdout trades (>= HOLDOUT_FROM) are never read.
 */
const fs = require('fs');
const path = require('path');
const { DATA_DIR } = require('./lib');

const S = process.argv[2] || 'sw15p';
const HOLDOUT = process.env.HOLDOUT_FROM || '2025-10-01';
const notes = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'viewer_notes.json'), 'utf8'));
const all = fs.readFileSync(path.join(DATA_DIR, `trades_${S}.jsonl`), 'utf8').split('\n').filter(Boolean)
  .map((l) => JSON.parse(l)).filter((t) => t.entryT < HOLDOUT);
if (!all.length || !all[0].feat) { console.log('No features in the trade log. Run: node backtest/swing/run.js --strategy=' + S + ' --assets=GOLD --to=2025-09-30 --log'); process.exit(1); }
for (const t of all) { const n = notes[`${S}|${t.asset}|${t.entryT}`]; t.bv = n ? (n.blindVerdict || n.verdict) : null; }

const take = all.filter((t) => t.bv === 'take'), skip = all.filter((t) => t.bv === 'skip');
const avg = (a) => (a.length ? a.reduce((s, t) => s + t.netR, 0) / a.length : NaN);
const f3 = (x) => (Number.isFinite(x) ? (x >= 0 ? '+' : '') + x.toFixed(3) : '   -  ');
const med = (a) => { const v = a.filter(Number.isFinite).sort((x, y) => x - y); return v.length ? v[Math.floor(v.length / 2)] : NaN; };
const pad = (s, n) => String(s).padEnd(n);

console.log(`${S}: dev trades ${all.length}  avgR ${f3(avg(all))}  |  blind take ${take.length} (${f3(avg(take))})  skip ${skip.length} (${f3(avg(skip))})\n`);

// direction of each filter: 'low' = small values are bad (skip when value < cut), 'high' = large values are bad
const FEATS = [
  ['oppR', 'low', 'room to the next opposite level, in R'],
  ['oppAtr', 'low', 'room to the next opposite level, in ATR'],
  ['room96Atr', 'low', 'room to the previous 1-day high (long) / low (short), ATR; 99 = already beyond'],
  ['room288Atr', 'low', 'room to the previous 3-day high / low, ATR'],
  ['range48Atr', 'low', 'high-low of the last 48 bars, ATR (small = range)'],
  ['emaX48', 'high', 'EMA9/15 crosses in the last 48 bars (many = chop)'],
  ['e15X48', 'high', 'close crossing EMA15 in the last 48 bars'],
  ['stretchAtr', 'high', 'distance from EMA15 at entry, ATR'],
  ['move20Atr', 'high', 'move in trade direction over the last 20 bars, ATR'],
  ['bodyAtr', 'low', 'entry candle body, ATR'],
  ['htfSlopeAbs', 'low', 'HTF EMA9 slope (abs)'],
];
for (const t of all) t.feat.htfSlopeAbs = t.feat.htfSlope == null ? null : Math.abs(t.feat.htfSlope);

for (const [k, side, desc] of FEATS) {
  const v = (t) => t.feat[k];
  console.log(`== ${k}: ${desc}`);
  console.log(`   median  take ${med(take.map(v))}   skip ${med(skip.map(v))}`);
  const vals = all.map(v).filter(Number.isFinite).sort((x, y) => x - y);
  const cuts = [...new Set([0.2, 0.35, 0.5].map((q) => vals[Math.floor(q * (vals.length - 1))]))];
  for (const cut of cuts) {
    const bad = (t) => Number.isFinite(v(t)) && (side === 'low' ? v(t) < cut : v(t) > cut);
    const kept = all.filter((t) => !bad(t));
    const k20 = kept.filter((t) => t.entryT < '2024'), k24 = kept.filter((t) => t.entryT >= '2024');
    console.log(`   drop if ${side === 'low' ? '<' : '>'} ${pad(cut, 6)} catches skips ${pad(skip.filter(bad).length + '/' + skip.length, 6)} loses takes ${pad(take.filter(bad).length + '/' + take.length, 6)}`
      + ` kept ${pad(kept.length, 4)} avgR ${f3(avg(kept))}  (2020-23 ${f3(avg(k20))}, 2024+ ${f3(avg(k24))})`);
  }
  console.log('');
}
