# Scalp Bot — Paper Trading System (BTC / ETH / GOLD)

A 6-month paper-trading scalping system. It analyzes the market with a fixed
rule-based strategy, simulates trades on a paper account, logs every trade
with full reasoning, and gradually re-weights its own signal components based
on statistical evidence. **No real money, no live orders.**

See `Paper_Trading_Bot_Specification.md` for the full design rationale.

---

## Repository layout

```
backend/            Node.js — strategy, paper engine, API, Socket.io, self-tuner
python-mt5-bridge/  Python — reads XAUUSD from MT5 (Exness demo) -> Node (Gold only)
dashboard/          React (Vite) — view-only live monitor
```

---

## Prerequisites

- Node.js >= 18
- MongoDB >= 6 **running as a replica set** (required for Change Streams)
- Python 3.10+ *inside Wine* for the Gold bridge (Linux server) — see below

### Initialize MongoDB as a single-node replica set (one time)

```bash
# in mongod.conf:  replication:\n  replSetName: rs0
# then, in the mongo shell:
rs.initiate()
```

---

## 1. Backend

```bash
cd backend
cp .env.example .env      # fill in MONGO_URI, FINNHUB_API_KEY, MT5_* later
npm install
npm start
```

On first run it seeds the paper balance and creates the default config
document. BTC and ETH start trading immediately on Binance's public feed
(no key needed). Gold stays idle until the Python bridge connects.

The API serves on `http://localhost:4000` (REST under `/api`, Socket.io for
live updates).

---

## 2. Python MT5 Bridge (Gold only)

`MetaTrader5` is a Windows-only library, so on a Linux server it must run
under **Wine**, with a **virtual display (Xvfb)** because the MT5 terminal
needs a GUI context. The bridge is read-only — it never places orders.

High-level server setup (Ubuntu 24.04):

```bash
# 1. Install Wine + Xvfb
sudo dpkg --add-architecture i386
sudo apt update && sudo apt install -y wine64 wine32 xvfb

# 2. Install the MT5 terminal under Wine, log into the Exness DEMO account once
#    (manually, so the terminal remembers the connection)
xvfb-run wine mt5setup.exe

# 3. Install a Windows Python inside the same Wine prefix, then:
wine python -m pip install -r python-mt5-bridge/requirements.txt

# 4. Run the bridge (env vars provide credentials; never hard-code them)
export MT5_ACCOUNT=...  MT5_PASSWORD=...  MT5_SERVER=...
export GOLD_SYMBOL=XAUUSD          # confirm exact symbol name for your Exness account
export GOLD_BRIDGE_WS_URL=ws://127.0.0.1:4101
xvfb-run wine python python-mt5-bridge/mt5_bridge.py
```

Run this under **systemd** with `Restart=always` so it recovers from Wine/MT5
hiccups. The Node backend exposes the gold bridge WebSocket on port `4101`
(override with `GOLD_BRIDGE_PORT`).

> If `XAUUSD` isn't found, check the Market Watch in your terminal — some
> Exness account types list it with a suffix (e.g. `XAUUSDm`). Set `GOLD_SYMBOL`
> accordingly.

---

## 3. Dashboard

```bash
cd dashboard
npm install
npm run dev        # http://localhost:5173, proxies /api to :4000
```

Shows: live balance, performance metrics (incl. Win Days %), equity curve,
open positions (with live trailing-stop level), filterable trade history, and
the self-tuning log (what changed and why). View-only — config editing is a
Phase 2 item.

---

## Daily / operational notes

- **MT5 token/login:** the Exness demo login is remembered by the terminal;
  no daily token refresh (unlike a broker REST API).
- **Self-tuner** runs once a day by default (see `TUNING_INTERVAL_MS` in
  `backend/src/index.js`) and only acts on assets with 30+ closed trades.
- **Validation discipline:** keep the final 1–2 months as untouched validation
  data — don't let the tuner's conclusions be judged only on the data it
  trained on. (See spec Section 8 / 15.)

---

## Honest limitations

This is a statistical feedback system, not a self-aware trader. Paper results
— even good ones over 6 months — do not guarantee live performance. Slippage,
latency, real fills, and regime shifts are not fully modeled. Nothing here
removes the need for your own judgment before risking real capital.
