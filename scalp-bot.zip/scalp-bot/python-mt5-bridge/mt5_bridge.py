#!/usr/bin/env python3
"""
MT5 -> Node Gold Bridge
=======================
Reads live XAUUSD ticks and closed 5-minute candles from a MetaTrader 5
terminal (Exness DEMO account) and streams them to the Node backend's
internal gold-bridge WebSocket server.

This process is the ONLY thing that talks to MT5. It deliberately does NOT
touch MongoDB directly and does NOT place any orders — it is a read-only
price feed. The Node paper engine does all trade simulation.

Message contract (must match feeds/internalGoldBridge.js on the Node side):
    {"type": "tick",   "price": <float>, "ts": <ISO8601 str>}
    {"type": "candle", "t": <ISO8601 str>, "o","h","l","c","v": <float>}

Run under Wine + Xvfb on the Linux server (see README for setup), supervised
by systemd so it auto-restarts if the MT5 terminal or Wine layer hiccups.
"""

import os
import sys
import time
import json
import signal
from datetime import datetime, timezone

try:
    import MetaTrader5 as mt5
except ImportError:
    print("[bridge] ERROR: MetaTrader5 package not found. "
          "Install with: pip install MetaTrader5  (inside the Wine Python env)", file=sys.stderr)
    sys.exit(1)

try:
    import websocket  # websocket-client
except ImportError:
    print("[bridge] ERROR: websocket-client not found. Install with: pip install websocket-client", file=sys.stderr)
    sys.exit(1)


# ---- Config (from environment; never hard-code credentials) ----
MT5_ACCOUNT = os.environ.get("MT5_ACCOUNT", "")
MT5_PASSWORD = os.environ.get("MT5_PASSWORD", "")
MT5_SERVER = os.environ.get("MT5_SERVER", "")
SYMBOL = os.environ.get("GOLD_SYMBOL", "XAUUSD")        # Exness may list it as "XAUUSDm" — adjust per account
NODE_WS_URL = os.environ.get("GOLD_BRIDGE_WS_URL", "ws://127.0.0.1:4101")
TICK_POLL_SEC = float(os.environ.get("TICK_POLL_SEC", "0.5"))   # how often to poll MT5 for a fresh tick
RECONNECT_SEC = float(os.environ.get("RECONNECT_SEC", "3"))

_running = True


def _log(msg):
    print(f"[bridge] {datetime.now(timezone.utc).isoformat()} {msg}", flush=True)


def _stop(signum, frame):
    global _running
    _running = False
    _log(f"received signal {signum}, shutting down")


signal.signal(signal.SIGINT, _stop)
signal.signal(signal.SIGTERM, _stop)


def init_mt5():
    """Initialize MT5 and log in to the Exness demo account."""
    if not mt5.initialize():
        _log(f"mt5.initialize() failed: {mt5.last_error()}")
        return False
    if MT5_ACCOUNT and MT5_PASSWORD and MT5_SERVER:
        ok = mt5.login(int(MT5_ACCOUNT), password=MT5_PASSWORD, server=MT5_SERVER)
        if not ok:
            _log(f"mt5.login() failed: {mt5.last_error()}")
            return False
        _log(f"logged in to account {MT5_ACCOUNT} on {MT5_SERVER}")
    else:
        _log("WARNING: MT5 credentials not fully set; relying on the terminal's existing login")

    if not mt5.symbol_select(SYMBOL, True):
        _log(f"symbol_select({SYMBOL}) failed — check the exact symbol name for this broker")
        return False
    _log(f"symbol {SYMBOL} selected")
    return True


def connect_node():
    """Open a WebSocket connection to the Node gold bridge, retrying forever."""
    while _running:
        try:
            ws = websocket.create_connection(NODE_WS_URL, timeout=10)
            _log(f"connected to Node gold bridge at {NODE_WS_URL}")
            return ws
        except Exception as e:
            _log(f"could not connect to Node ({e}); retrying in {RECONNECT_SEC}s")
            time.sleep(RECONNECT_SEC)
    return None


def send(ws, payload):
    ws.send(json.dumps(payload))


def fetch_last_closed_candle():
    """Return the most recently CLOSED 5m candle (index 1; index 0 is forming)."""
    rates = mt5.copy_rates_from_pos(SYMBOL, mt5.TIMEFRAME_M5, 0, 2)
    if rates is None or len(rates) < 2:
        return None
    r = rates[1]  # the closed one
    return {
        "type": "candle",
        "t": datetime.fromtimestamp(int(r["time"]), tz=timezone.utc).isoformat(),
        "o": float(r["open"]),
        "h": float(r["high"]),
        "l": float(r["low"]),
        "c": float(r["close"]),
        "v": float(r["tick_volume"]),
    }


def run():
    if not init_mt5():
        _log("MT5 init failed; exiting (systemd will restart)")
        sys.exit(1)

    ws = connect_node()
    if ws is None:
        return

    last_candle_time = None
    _log("streaming started")

    while _running:
        try:
            # --- tick ---
            tick = mt5.symbol_info_tick(SYMBOL)
            if tick is not None:
                # use the mid price (bid+ask)/2 for paper monitoring
                mid = (tick.bid + tick.ask) / 2 if tick.ask else tick.bid
                send(ws, {
                    "type": "tick",
                    "price": float(mid),
                    "ts": datetime.fromtimestamp(tick.time, tz=timezone.utc).isoformat(),
                })

            # --- closed candle (only send once per new closed bar) ---
            candle = fetch_last_closed_candle()
            if candle and candle["t"] != last_candle_time:
                send(ws, candle)
                last_candle_time = candle["t"]
                _log(f"sent closed candle {candle['t']} c={candle['c']}")

            time.sleep(TICK_POLL_SEC)

        except (websocket.WebSocketConnectionClosedException, BrokenPipeError, ConnectionResetError):
            _log("Node connection lost; reconnecting")
            ws = connect_node()
            if ws is None:
                break
        except Exception as e:
            _log(f"unexpected error: {e}")
            time.sleep(RECONNECT_SEC)

    try:
        if ws:
            ws.close()
    finally:
        mt5.shutdown()
        _log("shutdown complete")


if __name__ == "__main__":
    run()
