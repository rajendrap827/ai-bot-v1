import { useEffect, useRef, useState } from 'react';
import { io } from 'socket.io-client';

const API_BASE = import.meta.env.VITE_API_BASE || '';
const SOCKET_URL = import.meta.env.VITE_SOCKET_URL || 'http://localhost:4000';

export async function api(path) {
  const res = await fetch(`${API_BASE}/api${path}`);
  if (!res.ok) throw new Error(`API ${path} -> ${res.status}`);
  return res.json();
}

/** Subscribes to live backend events. Returns { connected, last } where
 *  `last` is the most recent event of each type, used to trigger refetches. */
export function useSocket() {
  const [connected, setConnected] = useState(false);
  const [events, setEvents] = useState({});
  const socketRef = useRef(null);

  useEffect(() => {
    const socket = io(SOCKET_URL, { transports: ['websocket'] });
    socketRef.current = socket;

    socket.on('connect', () => setConnected(true));
    socket.on('disconnect', () => setConnected(false));

    const types = ['trade:opened', 'trade:updated', 'trade:closed', 'equity:changed', 'tuning:decision'];
    types.forEach((t) => {
      socket.on(t, (payload) => setEvents((prev) => ({ ...prev, [t]: { payload, at: Date.now() } })));
    });

    return () => socket.close();
  }, []);

  return { connected, events };
}
