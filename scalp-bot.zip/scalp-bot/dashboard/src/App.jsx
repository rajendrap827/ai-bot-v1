import React, { useEffect, useState, useCallback } from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { api, useSocket } from './useData.js';

const ASSETS = ['BTC', 'ETH', 'GOLD'];
const fmtUsd = (n) => (n == null ? '—' : `$${Number(n).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`);
const fmtNum = (n, d = 2) => (n == null ? '—' : Number(n).toFixed(d));
const fmtTime = (t) => (t ? new Date(t).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—');

export default function App() {
  const { connected, events } = useSocket();
  const [balance, setBalance] = useState(null);
  const [equity, setEquity] = useState([]);
  const [open, setOpen] = useState([]);
  const [history, setHistory] = useState([]);
  const [tuning, setTuning] = useState([]);
  const [metrics, setMetrics] = useState(null);
  const [metricAsset, setMetricAsset] = useState('BTC');
  const [filters, setFilters] = useState({ asset: '', session: '', stage: '', exitReason: '' });

  const loadEquity = useCallback(async () => {
    const { points } = await api('/equity');
    setEquity(points.map((p) => ({ t: new Date(p.ts).getTime(), balance: p.balance })));
    if (points.length) setBalance(points[points.length - 1].balance);
  }, []);

  const loadOpen = useCallback(async () => {
    const { trades } = await api('/trades/open');
    setOpen(trades);
  }, []);

  const loadHistory = useCallback(async () => {
    const qs = Object.entries(filters).filter(([, v]) => v).map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join('&');
    const { trades } = await api(`/trades${qs ? `?${qs}` : ''}`);
    setHistory(trades);
  }, [filters]);

  const loadTuning = useCallback(async () => {
    const { logs } = await api('/tuning-log');
    setTuning(logs);
  }, []);

  const loadMetrics = useCallback(async (asset) => {
    try {
      const m = await api(`/diagnostics/metrics/${asset}`);
      setMetrics(m);
    } catch {
      setMetrics(null);
    }
  }, []);

  useEffect(() => { loadEquity(); loadOpen(); loadTuning(); }, [loadEquity, loadOpen, loadTuning]);
  useEffect(() => { loadHistory(); }, [loadHistory]);
  useEffect(() => { loadMetrics(metricAsset); }, [metricAsset, loadMetrics]);

  // React to live socket events by refetching the affected slices
  useEffect(() => { if (events['trade:opened'] || events['trade:updated']) loadOpen(); }, [events, loadOpen]);
  useEffect(() => {
    if (events['trade:closed']) { loadOpen(); loadHistory(); loadMetrics(metricAsset); }
  }, [events, loadOpen, loadHistory, loadMetrics, metricAsset]);
  useEffect(() => { if (events['equity:changed']) loadEquity(); }, [events, loadEquity]);
  useEffect(() => { if (events['tuning:decision']) loadTuning(); }, [events, loadTuning]);

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <h1>SCALP<span className="accent">·</span>BOT</h1>
          <span className="tag">Paper Trading Monitor</span>
        </div>
        <div className="balance">
          <div className="label">Paper Balance</div>
          <div className="value mono">{fmtUsd(balance)}</div>
          <div className="conn"><span className={`dot ${connected ? 'live' : ''}`} />{connected ? 'live' : 'disconnected'}</div>
        </div>
      </header>

      <MetricStrip metrics={metrics} asset={metricAsset} onAsset={setMetricAsset} />

      <div className="grid">
        <section className="panel">
          <h2>Equity Curve</h2>
          <EquityChart data={equity} />
        </section>

        <section className="panel">
          <h2>Open Positions <span className="hint">{open.length} active</span></h2>
          <OpenPositions rows={open} />
        </section>

        <section className="panel full">
          <h2>Trade History</h2>
          <Filters filters={filters} setFilters={setFilters} />
          <TradeHistory rows={history} />
        </section>

        <section className="panel full">
          <h2>Self-Tuning Log <span className="hint">why each weight changed</span></h2>
          <TuningLog rows={tuning} />
        </section>
      </div>

      <footer className="footnote">
        Paper trading only — no real capital. Signals fire on confirmed candles (anti-repaint). Self-tuning is rule-based
        (expectancy + shrinkage), never machine learning. Past paper performance does not guarantee live results.
      </footer>
    </div>
  );
}

function MetricStrip({ metrics, asset, onAsset }) {
  return (
    <div className="panel" style={{ margin: '18px 22px 0', borderRadius: 10 }}>
      <h2>
        Performance — {asset}
        <select value={asset} onChange={(e) => onAsset(e.target.value)} style={{ background: '#161c2a', color: '#e6ecf5', border: '1px solid #232c3d', borderRadius: 6, padding: '4px 8px', fontSize: 12 }}>
          {ASSETS.map((a) => <option key={a} value={a}>{a}</option>)}
        </select>
      </h2>
      <div className="metrics">
        <Metric k="Win Days %" v={metrics ? `${fmtNum(metrics.winDaysPct, 1)}%` : '—'} cls="gold" />
        <Metric k="Expectancy (R)" v={metrics ? fmtNum(metrics.expectancy, 3) : '—'} cls={metrics && metrics.expectancy > 0 ? 'good' : metrics && metrics.expectancy < 0 ? 'bad' : ''} />
        <Metric k="Win Rate" v={metrics ? `${fmtNum(metrics.winRate, 1)}%` : '—'} />
        <Metric k="Total Trades" v={metrics ? metrics.totalTrades : '—'} />
        <Metric k="Profit Factor" v={metrics && isFinite(metrics.profitFactor) ? fmtNum(metrics.profitFactor, 2) : metrics ? '∞' : '—'} />
        <Metric k="Max Drawdown" v={metrics ? fmtUsd(metrics.maxDrawdown) : '—'} cls="bad" />
        <Metric k="Sharpe" v={metrics ? fmtNum(metrics.sharpe, 2) : '—'} />
        <Metric k="Trading Days" v={metrics ? metrics.totalDays : '—'} />
      </div>
    </div>
  );
}

function Metric({ k, v, cls = '' }) {
  return (
    <div className="metric">
      <div className="k">{k}</div>
      <div className={`v mono ${cls}`}>{v}</div>
    </div>
  );
}

function EquityChart({ data }) {
  if (!data.length) return <div className="empty">No equity history yet. The curve fills in as trades close.</div>;
  return (
    <div style={{ padding: '12px 8px 16px', height: 320 }}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 8, right: 16, bottom: 4, left: 4 }}>
          <CartesianGrid stroke="#1b2230" vertical={false} />
          <XAxis dataKey="t" type="number" domain={['dataMin', 'dataMax']} tickFormatter={(t) => new Date(t).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })} stroke="#7d8aa3" fontSize={11} />
          <YAxis stroke="#7d8aa3" fontSize={11} domain={['auto', 'auto']} tickFormatter={(v) => `$${(v / 1000).toFixed(1)}k`} />
          <Tooltip contentStyle={{ background: '#121722', border: '1px solid #232c3d', borderRadius: 8, fontSize: 12 }} labelFormatter={(t) => new Date(t).toLocaleString()} formatter={(v) => [fmtUsd(v), 'Balance']} />
          <Line type="monotone" dataKey="balance" stroke="#f4b740" strokeWidth={2} dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

function OpenPositions({ rows }) {
  if (!rows.length) return <div className="empty">No open positions right now.</div>;
  return (
    <div className="scroll">
      <table>
        <thead><tr><th>Asset</th><th>Side</th><th>Entry</th><th>SL</th><th>Trail</th><th>Stage</th></tr></thead>
        <tbody>
          {rows.map((t) => (
            <tr key={t.tradeId}>
              <td className={`asset-chip asset-${t.asset}`}>{t.asset}</td>
              <td><span className={`tag-pill ${t.direction === 'LONG' ? 'long' : 'short'}`}>{t.direction}</span></td>
              <td className="mono">{fmtNum(t.execution?.entryPrice)}</td>
              <td className="mono">{fmtNum(t.execution?.sl)}</td>
              <td className="mono">{t.outcome?.trailingActive ? fmtNum(t.outcome?.currentTrailStop) : <span className="muted">—</span>}</td>
              <td className="muted">{t.entryBasis?.marketStage}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Filters({ filters, setFilters }) {
  const set = (k) => (e) => setFilters((f) => ({ ...f, [k]: e.target.value }));
  return (
    <div className="filters">
      <select value={filters.asset} onChange={set('asset')}><option value="">All assets</option>{ASSETS.map((a) => <option key={a}>{a}</option>)}</select>
      <select value={filters.session} onChange={set('session')}><option value="">All sessions</option>{['ASIAN', 'LONDON', 'OVERLAP', 'NY', 'NY_CLOSE'].map((s) => <option key={s}>{s}</option>)}</select>
      <select value={filters.stage} onChange={set('stage')}><option value="">All stages</option>{['ADVANCING', 'ACCUMULATION', 'DISTRIBUTION', 'DECLINING', 'UNCLEAR'].map((s) => <option key={s}>{s}</option>)}</select>
      <select value={filters.exitReason} onChange={set('exitReason')}><option value="">All exits</option>{['TP1_PARTIAL', 'TRAIL_STOP', 'SL', 'TIME'].map((s) => <option key={s}>{s}</option>)}</select>
    </div>
  );
}

function TradeHistory({ rows }) {
  if (!rows.length) return <div className="empty">No closed trades match these filters yet.</div>;
  return (
    <div className="scroll">
      <table>
        <thead>
          <tr><th>Asset</th><th>Side</th><th>Entry→Exit</th><th>Exit</th><th>R</th><th>PnL</th><th>Stage</th><th>Session</th><th>Fingerprint</th></tr>
        </thead>
        <tbody>
          {rows.map((t) => {
            const pnl = t.outcome?.pnlUsd ?? 0;
            return (
              <tr key={t.tradeId}>
                <td className={`asset-chip asset-${t.asset}`}>{t.asset}</td>
                <td><span className={`tag-pill ${t.direction === 'LONG' ? 'long' : 'short'}`}>{t.direction}</span></td>
                <td className="muted" style={{ fontSize: 11 }}>{fmtTime(t.execution?.entryTime)}</td>
                <td className="muted">{t.outcome?.exitReason || '—'}</td>
                <td className={`mono ${(t.outcome?.rMultiple ?? 0) >= 0 ? 'pos' : 'neg'}`}>{fmtNum(t.outcome?.rMultiple)}</td>
                <td className={`mono ${pnl >= 0 ? 'pos' : 'neg'}`}>{fmtUsd(pnl)}</td>
                <td className="muted">{t.entryBasis?.marketStage}</td>
                <td className="muted">{t.entryBasis?.session}</td>
                <td className="muted mono" style={{ fontSize: 10.5 }}>{t.prediction?.setupFingerprint}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

function TuningLog({ rows }) {
  if (!rows.length) return <div className="empty">No tuning decisions yet. The tuner activates after 30+ closed trades per asset.</div>;
  return (
    <div className="scroll">
      <table>
        <thead>
          <tr><th>When</th><th>Asset</th><th>Component</th><th>Action</th><th>Weight</th><th>Sample</th><th>Reason</th></tr>
        </thead>
        <tbody>
          {rows.map((l) => (
            <tr key={l._id} className="tuning-row">
              <td className="muted" style={{ fontSize: 11 }}>{fmtTime(l.ts)}</td>
              <td className={`asset-chip asset-${l.asset}`}>{l.asset}</td>
              <td className="mono">{l.component}</td>
              <td>{actionPill(l.action)}</td>
              <td className="mono">
                {fmtNum(l.weightBefore, 1)}
                {l.weightAfter !== l.weightBefore && (
                  <span className={l.weightAfter > l.weightBefore ? 'delta-up' : 'delta-down'}> → {fmtNum(l.weightAfter, 1)}</span>
                )}
              </td>
              <td className="mono muted">{l.sampleSize}</td>
              <td className="reason">{l.reason}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function actionPill(action) {
  const map = {
    decay: { cls: 'short', label: 'DECAY' },
    restore: { cls: 'long', label: 'RESTORE' },
    no_change: { cls: '', label: 'NO CHANGE' },
    hold_cooldown: { cls: '', label: 'COOLDOWN' },
  };
  const a = map[action] || { cls: '', label: action };
  return <span className={`tag-pill ${a.cls}`} style={!a.cls ? { color: '#7d8aa3', background: 'rgba(125,138,163,0.12)' } : {}}>{a.label}</span>;
}
