const axios = require('axios');
const env = require('../config/env');

let cachedEvents = null;
let cacheDate = null;

/**
 * Fetches today's (and tomorrow's, to cover overnight sessions) high-impact
 * economic calendar events from Finnhub. Cached per-day since the calendar
 * doesn't change minute-to-minute — re-fetching on every signal check would
 * waste API quota for no benefit.
 */
async function fetchCalendarEvents() {
  const today = new Date().toISOString().slice(0, 10);
  if (cachedEvents && cacheDate === today) return cachedEvents;

  if (!env.finnhubApiKey) {
    console.warn('[news] FINNHUB_API_KEY not set — news blackout filter is disabled.');
    cachedEvents = [];
    cacheDate = today;
    return cachedEvents;
  }

  const tomorrow = new Date(Date.now() + 86400000).toISOString().slice(0, 10);
  try {
    const url = `https://finnhub.io/api/v1/calendar/economic?from=${today}&to=${tomorrow}&token=${env.finnhubApiKey}`;
    const res = await axios.get(url, { timeout: 15000 });
    const events = (res.data.economicCalendar || [])
      .filter((e) => e.impact === 'high')
      .map((e) => ({
        name: e.event,
        scheduledTime: new Date(`${e.time}`),
        impact: 'HIGH',
        source: 'finnhub',
      }));
    cachedEvents = events;
    cacheDate = today;
    return events;
  } catch (err) {
    console.error('[news] Finnhub fetch failed:', err.message);
    return cachedEvents || [];
  }
}

/**
 * Returns the news context block for a trade taken at `entryTime`.
 * blackoutMinutes: how close to a HIGH-impact event counts as "in the blackout window".
 */
async function getNewsContext(entryTime, blackoutMinutes = 30) {
  const events = await fetchCalendarEvents();
  const nearby = events
    .map((e) => ({
      ...e,
      minutesFromEntry: Math.round((entryTime.getTime() - e.scheduledTime.getTime()) / 60000),
    }))
    .filter((e) => Math.abs(e.minutesFromEntry) <= 180); // keep anything within 3h for the trade log, even if not blackout-relevant

  const blackoutActive = nearby.some((e) => Math.abs(e.minutesFromEntry) <= blackoutMinutes);

  return {
    highImpactEventNearby: nearby.length > 0,
    events: nearby,
    blackoutActive,
    sentiment: { available: false, score: null, label: null, source: null },
  };
}

module.exports = { fetchCalendarEvents, getNewsContext };
