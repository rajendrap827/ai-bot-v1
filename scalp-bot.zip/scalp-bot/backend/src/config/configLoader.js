const { Config } = require('../models/Config');
const env = require('./env');

const CACHE_TTL_MS = 5000; // bounds DB reads regardless of tick frequency (BTC ticks can be several/sec)
const cache = new Map(); // key: `${strategyId}:${accountId}:${asset}` -> { cfg, doc, fetchedAt }

/**
 * Loads (or seeds, on first run) the live config document and returns a
 * flat, merged config object for a specific asset — global defaults with
 * any per-asset override applied on top. This is what scoring.js and
 * paperEngine.js actually consume.
 *
 * Cached briefly per asset: workers call this on every price tick for
 * SL/TP/trailing checks, and hitting MongoDB that often would defeat the
 * "no per-tick DB writes/reads" scaling decision. A tuner-applied config
 * change still takes effect within CACHE_TTL_MS.
 */
async function getMergedConfig(asset, strategyId = 'default', accountId = 'paper-main') {
  const key = `${strategyId}:${accountId}:${asset}`;
  const cached = cache.get(key);
  if (cached && Date.now() - cached.fetchedAt < CACHE_TTL_MS) {
    return { cfg: cached.cfg, doc: cached.doc };
  }

  let doc = await Config.findOne({ strategyId, accountId });
  if (!doc) {
    doc = await Config.create({
      strategyId,
      accountId,
      global: {
        paperBalance: env.defaults.paperBalance,
        riskPerTrade: env.defaults.riskPerTrade,
      },
    });
  }

  const g = doc.global.toObject ? doc.global.toObject() : doc.global;
  const perAssetEntry = doc.perAsset && doc.perAsset.get ? doc.perAsset.get(asset) : null;
  const assetOverride = perAssetEntry ? (perAssetEntry.toObject ? perAssetEntry.toObject() : perAssetEntry) : {};

  const merged = {
    ...g,
    riskPerTrade: assetOverride.riskPerTrade ?? g.riskPerTrade,
    slAtrMult: assetOverride.slAtrMult ?? g.slAtrMult ?? 1.5,
    rrRatio: assetOverride.rrRatio ?? g.rrRatio ?? 2.0,
    weights: { ...(g.weights || {}), ...(assetOverride.weights || {}) },
    paramsVersion: doc.meta.version,
  };

  cache.set(key, { cfg: merged, doc, fetchedAt: Date.now() });
  return { cfg: merged, doc };
}

/** Call this whenever the config is changed directly (e.g. by the tuner) to avoid a stale read within the TTL window. */
function invalidateConfigCache(asset, strategyId = 'default', accountId = 'paper-main') {
  cache.delete(`${strategyId}:${accountId}:${asset}`);
}

/** Returns just the current config version number (cheap, for trade tagging). */
async function getConfigVersion(strategyId = 'default', accountId = 'paper-main') {
  const doc = await Config.findOne({ strategyId, accountId }, 'meta.version').lean();
  return doc ? doc.meta.version : 1;
}

module.exports = { getMergedConfig, getConfigVersion, invalidateConfigCache };
