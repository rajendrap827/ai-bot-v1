const mongoose = require('mongoose');
const env = require('./env');

async function connectDB() {
  mongoose.set('strictQuery', true);

  await mongoose.connect(env.mongoUri);
  console.log(`[db] connected: ${mongoose.connection.name}`);

  // Change Streams require a replica set. Fail loudly and early rather than
  // silently falling back to polling — this was a deliberate scaling decision.
  try {
    const admin = mongoose.connection.db.admin();
    const status = await admin.command({ replSetGetStatus: 1 });
    if (!status || !status.ok) {
      console.warn('[db] WARNING: replSetGetStatus did not return ok=1. Change Streams may not work.');
    } else {
      console.log(`[db] replica set OK: ${status.set} (${status.members.length} member(s))`);
    }
  } catch (err) {
    console.warn(
      '[db] WARNING: MongoDB is not running as a replica set. ' +
      'Change Streams (used for live dashboard updates) will fail. ' +
      'Initialize a single-node replica set with: rs.initiate() in the mongo shell. ' +
      `Original error: ${err.message}`
    );
  }

  return mongoose.connection;
}

module.exports = { connectDB, mongoose };
