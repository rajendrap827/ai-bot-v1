require('dotenv').config();

function required(name, fallback) {
  const v = process.env[name];
  if (v === undefined || v === '') {
    if (fallback !== undefined) return fallback;
    return ''; // allow empty during early dev; connection code will warn clearly
  }
  return v;
}

module.exports = {
  mongoUri: required('MONGO_URI', 'mongodb://localhost:27017/scalpbot?replicaSet=rs0'),
  port: parseInt(required('PORT', '4000'), 10),
  socketCorsOrigin: required('SOCKET_CORS_ORIGIN', '*'),
  finnhubApiKey: required('FINNHUB_API_KEY'),
  mt5: {
    account: required('MT5_ACCOUNT'),
    password: required('MT5_PASSWORD'),
    server: required('MT5_SERVER'),
  },
  defaults: {
    paperBalance: parseFloat(required('DEFAULT_PAPER_BALANCE', '10000')),
    riskPerTrade: parseFloat(required('DEFAULT_RISK_PER_TRADE', '0.01')),
  },
};
