const { BalanceLog } = require('../models/Config');
const env = require('../config/env');

async function seedInitialBalance() {
  const existing = await BalanceLog.findOne({});
  if (existing) {
    console.log(`[bootstrap] balance log already exists, current balance: ${existing.balance}`);
    return;
  }
  await BalanceLog.create({
    balance: env.defaults.paperBalance,
    changeReason: 'initial_seed',
    changedBy: 'system',
  });
  console.log(`[bootstrap] seeded initial paper balance: ${env.defaults.paperBalance}`);
}

module.exports = { seedInitialBalance };
