const { v4: uuidv4 } = require('uuid');
const Trade = require('../models/Trade');
const { Config, BalanceLog } = require('../models/Config');

/**
 * Risk-based position sizing: size such that hitting the initial SL loses
 * exactly `riskUsd` (balance * riskPerTrade).
 */
function positionSize(entry, sl, balance, riskPerTrade) {
  const riskUsd = balance * riskPerTrade;
  const perUnit = Math.abs(entry - sl);
  if (perUnit <= 0) return { size: 0, riskUsd: 0 };
  return { size: riskUsd / perUnit, riskUsd };
}

async function currentBalance(accountId = 'paper-main') {
  const latest = await BalanceLog.findOne({}).sort({ ts: -1 }).lean();
  return latest ? latest.balance : null;
}

async function adjustBalance(delta, reason, changedBy = 'engine') {
  const bal = (await currentBalance()) ?? 0;
  const newBal = bal + delta;
  await BalanceLog.create({ balance: newBal, changeReason: reason, changedBy });
  return newBal;
}

/**
 * Opens a new paper position from a computed signal. Caller is responsible
 * for checking max-open-per-asset / daily caps before calling this.
 */
async function openTrade({ asset, timeframe, signal, cfg, paramsVersion, newsContext }) {
  const balance = (await currentBalance()) ?? cfg.paperBalance ?? 10000;
  const riskPerTrade = cfg.riskPerTrade ?? 0.01;
  const { size, riskUsd } = positionSize(signal.entry, signal.sl, balance, riskPerTrade);
  if (size <= 0) return null;

  const trade = await Trade.create({
    tradeId: uuidv4(),
    asset,
    timeframe,
    direction: signal.signal,
    paramsVersion,
    entryBasis: {
      marketStage: signal.stage,
      session: signal.session,
      htfTrend: signal.htfTrend,
      adx: signal.adx,
      checks: signal.checks,
      bullScore: signal.bullScore,
      bearScore: signal.bearScore,
      netMargin: signal.netMargin,
      confirmationCandle: signal.confirmationCandle,
      newsContext: newsContext || { highImpactEventNearby: false, events: [], blackoutActive: false },
    },
    prediction: {
      setupFingerprint: signal.setupFingerprint,
      predictedSuccessRate: null, // filled in by the analysis layer once enough history exists
      expectedR: cfg.rrRatio || 2.0,
    },
    execution: {
      entryTime: new Date(signal.time),
      entryPrice: signal.entry,
      sl: signal.sl,
      tp1: signal.tp1,
      tp2: signal.tp2,
      size,
      riskUsd,
    },
    outcome: { status: 'OPEN' },
  });
  return trade;
}

/**
 * Called on every new price tick (real-time) for a given asset's open trades.
 * Implements the hybrid exit:
 *   1) Full SL still active until TP1 is hit.
 *   2) On TP1 touch: close `hybridLockPct` of the position, lock that profit.
 *   3) Remaining size keeps the original SL until price reaches hybridTrailStartR.
 *   4) Once hybridTrailStartR is reached, SL trails behind price using
 *      trailAtrMult * ATR (chandelier-style), only ever tightening, never loosening.
 *   5) Remaining size exits when the trailing stop is hit (or the original
 *      SL, if trailing hasn't started yet).
 */
async function manageOpenTrades(asset, tickPrice, currentAtr, cfg) {
  const openTrades = await Trade.find({ asset, 'outcome.status': 'OPEN' });
  const lockPct = cfg.hybridLockPct ?? 0.5;
  const trailStartR = cfg.hybridTrailStartR ?? 1.0;
  const trailMult = cfg.trailAtrMult ?? 1.25;

  for (const trade of openTrades) {
    const { direction, execution, outcome } = trade;
    const entry = execution.entryPrice;
    const initialRisk = direction === 'LONG' ? entry - execution.sl : execution.sl - entry;
    if (initialRisk <= 0) continue;

    const favorableMove = direction === 'LONG' ? tickPrice - entry : entry - tickPrice;
    const rNow = favorableMove / initialRisk;

    // ── Step 1: TP1 partial close (profit lock) ──
    if (!outcome.tp1Hit) {
      const tp1Hit = direction === 'LONG' ? tickPrice >= execution.tp1 : tickPrice <= execution.tp1;
      const slHit = direction === 'LONG' ? tickPrice <= execution.sl : tickPrice >= execution.sl;

      if (slHit) {
        await closeTrade(trade, tickPrice, 'SL', execution.size);
        continue;
      }
      if (tp1Hit) {
        const closedSize = execution.size * lockPct;
        const pnl = direction === 'LONG'
          ? (tickPrice - entry) * closedSize
          : (entry - tickPrice) * closedSize;
        trade.outcome.tp1Hit = true;
        trade.outcome.tp1ClosedSize = closedSize;
        await adjustBalance(pnl, `trade:${trade.tradeId}:tp1_partial`);
        await trade.save();
        // remaining size continues with original SL until trailStartR
      }
      continue;
    }

    // ── Step 2: post-TP1, decide whether trailing has started ──
    const remainingSize = execution.size - outcome.tp1ClosedSize;
    if (remainingSize <= 0) {
      await closeTradeFinal(trade, tickPrice, 'TP1_PARTIAL');
      continue;
    }

    if (!outcome.trailingActive) {
      if (rNow >= trailStartR) {
        trade.outcome.trailingActive = true;
        trade.outcome.currentTrailStop = direction === 'LONG'
          ? tickPrice - currentAtr * trailMult
          : tickPrice + currentAtr * trailMult;
        await trade.save();
      } else {
        // still on the original SL for the remaining size
        const slHit = direction === 'LONG' ? tickPrice <= execution.sl : tickPrice >= execution.sl;
        if (slHit) await closeTrade(trade, tickPrice, 'SL', remainingSize, true);
        continue;
      }
    }

    // ── Step 3: trailing stop management (only ever tightens) ──
    const proposedStop = direction === 'LONG'
      ? tickPrice - currentAtr * trailMult
      : tickPrice + currentAtr * trailMult;

    if (direction === 'LONG' && proposedStop > trade.outcome.currentTrailStop) {
      trade.outcome.currentTrailStop = proposedStop;
      await trade.save();
    } else if (direction === 'SHORT' && proposedStop < trade.outcome.currentTrailStop) {
      trade.outcome.currentTrailStop = proposedStop;
      await trade.save();
    }

    const trailHit = direction === 'LONG'
      ? tickPrice <= trade.outcome.currentTrailStop
      : tickPrice >= trade.outcome.currentTrailStop;
    if (trailHit) {
      await closeTrade(trade, tickPrice, 'TRAIL_STOP', remainingSize, true);
    }
  }
}

/** Closes the remaining (post-TP1) portion of a trade and finalizes the record. */
async function closeTrade(trade, exitPrice, reason, sizeClosed, isPostTp1 = false) {
  const { direction, execution } = trade;
  const entry = execution.entryPrice;
  const pnlOnThisPortion = direction === 'LONG'
    ? (exitPrice - entry) * sizeClosed
    : (entry - exitPrice) * sizeClosed;

  await adjustBalance(pnlOnThisPortion, `trade:${trade.tradeId}:${reason.toLowerCase()}`);

  // Total trade PnL = whatever was locked at TP1 (if any) + this closing portion
  const tp1Pnl = trade.outcome.tp1Hit
    ? (direction === 'LONG'
        ? (execution.tp1 - entry) * trade.outcome.tp1ClosedSize
        : (entry - execution.tp1) * trade.outcome.tp1ClosedSize)
    : 0;
  const totalPnl = tp1Pnl + pnlOnThisPortion;
  const initialRisk = Math.abs(entry - execution.sl) * execution.size;
  const rMultiple = initialRisk ? totalPnl / initialRisk : 0;

  trade.outcome.status = 'CLOSED';
  trade.outcome.exitTime = new Date();
  trade.outcome.exitPrice = exitPrice;
  trade.outcome.exitReason = reason;
  trade.outcome.pnlUsd = Math.round(totalPnl * 100) / 100;
  const notional = entry * execution.size;
  trade.outcome.pnlPct = notional > 0 ? Math.round((totalPnl / notional) * 10000) / 100 : 0; // % of position notional
  trade.outcome.rMultiple = Math.round(rMultiple * 100) / 100;
  trade.outcome.predictionCorrect = totalPnl > 0;
  await trade.save();
}

/** Used when TP1 already closed 100% intent (lockPct effectively covers full size, edge case). */
async function closeTradeFinal(trade, exitPrice, reason) {
  trade.outcome.status = 'CLOSED';
  trade.outcome.exitTime = new Date();
  trade.outcome.exitPrice = exitPrice;
  trade.outcome.exitReason = reason;
  await trade.save();
}

module.exports = { positionSize, currentBalance, adjustBalance, openTrade, manageOpenTrades };
