const env = require('./config/env');
const { connectDB } = require('./config/db');
const { seedInitialBalance } = require('./config/bootstrap');
const { startChangeStreamWatchers } = require('./events/changeStreamWatcher');
const { createServer } = require('./api/server');
const { startCryptoWorker } = require('./workers/cryptoWorker');
const { startGoldWorker } = require('./workers/goldWorker');
const { runTuningCycle } = require('./tuning/tuner');

const TUNING_INTERVAL_MS = 24 * 60 * 60 * 1000; // run the self-tuner once a day; adjust as needed

async function main() {
  await connectDB();
  await seedInitialBalance();

  startChangeStreamWatchers();

  const { httpServer } = createServer();
  httpServer.listen(env.port, () => console.log(`[api] listening on port ${env.port}`));

  // NOTE: for the scale-readiness design (Section 11 of the spec — each
  // asset as an isolated worker process), these can later be split into
  // separate PM2/systemd processes without changing any of the worker code
  // itself, since each start*Worker() function is already self-contained.
  await startCryptoWorker('BTC');
  await startCryptoWorker('ETH');
  await startGoldWorker();

  setInterval(async () => {
    for (const asset of ['BTC', 'ETH', 'GOLD']) {
      try {
        const result = await runTuningCycle(asset);
        if (result.skipped) {
          console.log(`[tuner:${asset}] skipped — ${result.reason}`);
        } else {
          console.log(`[tuner:${asset}] cycle complete — ${result.decisions.length} component(s) reviewed`);
        }
      } catch (err) {
        console.error(`[tuner:${asset}] error:`, err.message);
      }
    }
  }, TUNING_INTERVAL_MS);

  console.log('[main] all systems started');
}

main().catch((err) => {
  console.error('[main] fatal startup error:', err);
  process.exit(1);
});
