const { Schema, model } = require('mongoose');

const CheckSchema = new Schema(
  {
    passed: { type: Boolean, required: true },
    weight: { type: Number, required: true },
    value: { type: Schema.Types.Mixed }, // e.g. "ADVANCING", "near_ema21", "bull_engulfing"
    distanceAtr: { type: Number },
  },
  { _id: false }
);

const NewsEventSchema = new Schema(
  {
    name: String,
    scheduledTime: Date,
    impact: { type: String, enum: ['LOW', 'MEDIUM', 'HIGH'] },
    minutesFromEntry: Number,
    source: { type: String, default: 'finnhub' },
  },
  { _id: false }
);

const TradeSchema = new Schema({
  tradeId: { type: String, required: true, unique: true },
  strategyId: { type: String, default: 'default' },
  accountId: { type: String, default: 'paper-main' },

  asset: { type: String, enum: ['BTC', 'ETH', 'GOLD'], required: true },
  timeframe: { type: String, default: '5m' },
  direction: { type: String, enum: ['LONG', 'SHORT'], required: true },
  paramsVersion: { type: Number, required: true },

  entryBasis: {
    marketStage: { type: String, enum: ['ADVANCING', 'ACCUMULATION', 'DISTRIBUTION', 'DECLINING', 'UNCLEAR'] },
    session: { type: String },
    htfTrend: { type: String, enum: ['BULL', 'BEAR', 'NA'] },
    adx: Number,
    checks: {
      stage: CheckSchema,
      aov: CheckSchema, // includes support/resistance/EMA200/EMA21/VWAP — VWAP folded in here, not a separate component
      pattern: CheckSchema,
      ema: CheckSchema,
      smc: CheckSchema,
      volume: CheckSchema,
    },
    bullScore: Number,
    bearScore: Number,
    netMargin: Number,
    confirmationCandle: Boolean,
    newsContext: {
      highImpactEventNearby: { type: Boolean, default: false },
      events: [NewsEventSchema],
      blackoutActive: { type: Boolean, default: false },
      sentiment: {
        available: { type: Boolean, default: false },
        score: { type: Number, default: null },
        label: { type: String, default: null },
        source: { type: String, default: null },
      },
    },
  },

  prediction: {
    setupFingerprint: String, // e.g. "ADV-AOV-PATTERN-EMA-SMC-NOVOL"
    predictedSuccessRate: { type: Number, default: null },
    expectedR: { type: Number, default: null },
  },

  execution: {
    entryTime: Date,
    entryPrice: Number,
    sl: Number,
    tp1: Number,
    tp2: Number, // soft reference target only — see exit logic
    size: Number,
    riskUsd: Number,
  },

  outcome: {
    status: { type: String, enum: ['OPEN', 'CLOSED'], default: 'OPEN' },
    exitTime: Date,
    exitPrice: Number,
    exitReason: { type: String, enum: ['TP1_PARTIAL', 'TRAIL_STOP', 'SL', 'TIME', null], default: null },
    pnlUsd: Number,
    pnlPct: Number,
    rMultiple: Number,
    barsHeld: Number,
    eventDuringTrade: { type: Boolean, default: false },
    predictionCorrect: { type: Boolean, default: null },

    // Hybrid-exit specific state (updated live as the trade progresses)
    tp1Hit: { type: Boolean, default: false },
    tp1ClosedSize: { type: Number, default: 0 },
    trailingActive: { type: Boolean, default: false },
    currentTrailStop: { type: Number, default: null },
  },

  postMortem: {
    tunedAfterThis: { type: Boolean, default: false },
    notes: { type: String, default: '' },
  },
}, { timestamps: true });

TradeSchema.index({ asset: 1, 'outcome.status': 1 });
TradeSchema.index({ 'prediction.setupFingerprint': 1 });
TradeSchema.index({ paramsVersion: 1 });

module.exports = model('Trade', TradeSchema);
