const { Schema, model } = require('mongoose');

const TuningLogSchema = new Schema({
  ts: { type: Date, default: Date.now },
  strategyId: { type: String, default: 'default' },
  asset: { type: String, enum: ['BTC', 'ETH', 'GOLD', 'ALL'], required: true },
  component: { type: String, enum: ['stage', 'aov', 'pattern', 'ema', 'smc', 'volume'], required: true },

  sampleSize: { type: Number, required: true },
  expectancyWithBefore: Number, // avg R-multiple of trades where this component fired, before shrinkage
  expectancyShrunk: Number, // after small-sample shrinkage toward the global average
  globalExpectancy: Number,

  weightBefore: Number,
  weightAfter: Number,
  action: { type: String, enum: ['no_change', 'decay', 'restore', 'hold_cooldown'], required: true },
  reason: { type: String, required: true }, // human-readable explanation, always populated

  configVersionBefore: Number,
  configVersionAfter: Number,
});

TuningLogSchema.index({ ts: -1 });
TuningLogSchema.index({ asset: 1, component: 1 });

module.exports = model('TuningLog', TuningLogSchema);
