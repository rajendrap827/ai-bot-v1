const { Schema, model } = require('mongoose');

/**
 * One document per logical config "slot" — but in practice we keep a single
 * live document per strategyId/accountId and version it via `meta.version`.
 * Historical versions are kept in the `configHistory` collection (see below)
 * so every trade's `paramsVersion` can be traced back to the exact rules
 * that produced it.
 */
const WeightsSchema = new Schema(
  {
    stage: { type: Number, default: 1 },
    aov: { type: Number, default: 1 },
    pattern: { type: Number, default: 1 },
    ema: { type: Number, default: 1 },
    smc: { type: Number, default: 1 },
    volume: { type: Number, default: 1 },
  },
  { _id: false }
);

const AssetParamsSchema = new Schema(
  {
    riskPerTrade: { type: Number, default: 0.01 },
    slAtrMult: { type: Number, default: 1.5 },
    rrRatio: { type: Number, default: 2.0 },
    weights: { type: WeightsSchema, default: () => ({}) },
  },
  { _id: false }
);

const ConfigSchema = new Schema({
  strategyId: { type: String, default: 'default' },
  accountId: { type: String, default: 'paper-main' },

  global: {
    paperBalance: { type: Number, default: 10000 },
    riskPerTrade: { type: Number, default: 0.01 },
    maxOpenPerAsset: { type: Number, default: 1 },
    minScore: { type: Number, default: 4 },
    netMargin: { type: Number, default: 1 },
    cooldownBars: { type: Number, default: 5 },
    useSessionFilter: { type: Boolean, default: true },
    requireAreaOfValue: { type: Boolean, default: true },
    requireConfirmCandle: { type: Boolean, default: true },
    exitMode: { type: String, enum: ['fixed', 'trail', 'hybrid'], default: 'hybrid' },
    hybridTrailStartR: { type: Number, default: 1.0 }, // start trailing once 1R profit is reached
    hybridLockPct: { type: Number, default: 0.5 }, // close 50% at TP1
    trailAtrMult: { type: Number, default: 1.25 },
    adxMin: { type: Number, default: 18 },
    htfTimeframe: { type: String, default: '1h' },
    htfLen: { type: Number, default: 50 },
    aovAtrMult: { type: Number, default: 1.5 }, // generic AOV distance (EMA200)
    aovEmaSlowAtrMult: { type: Number, default: 0.8 },
    vwapAtrMult: { type: Number, default: 0.8 }, // VWAP proximity threshold, folded into AOV
    useNewsBlackout: { type: Boolean, default: true },
    newsBlackoutMinutes: { type: Number, default: 30 },
  },

  perAsset: {
    type: Map,
    of: AssetParamsSchema,
    default: () => ({}),
  },

  meta: {
    version: { type: Number, default: 1 },
    updatedAt: { type: Date, default: Date.now },
    updatedBy: { type: String, enum: ['manual', 'auto-tuner'], default: 'manual' },
  },
});

const BalanceLogSchema = new Schema({
  ts: { type: Date, default: Date.now },
  balance: { type: Number, required: true },
  changeReason: { type: String, default: 'manual_adjustment' },
  changedBy: { type: String, default: 'user' },
});

module.exports = {
  Config: model('Config', ConfigSchema),
  BalanceLog: model('BalanceLog', BalanceLogSchema),
};
