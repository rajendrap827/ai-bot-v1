const { Schema, model } = require('mongoose');

/**
 * Stores closed candles only (never raw ticks — see Section 11 of the spec).
 * Used to warm-restart a worker without needing a full REST backfill, and
 * as the source for the Gold feed (written by the Python MT5 bridge).
 * Declared as a native MongoDB time-series collection for efficient storage.
 */
const CandleSchema = new Schema(
  {
    asset: { type: String, enum: ['BTC', 'ETH', 'GOLD'], required: true },
    timeframe: { type: String, required: true },
    t: { type: Date, required: true }, // timeseries timeField
    o: Number,
    h: Number,
    l: Number,
    c: Number,
    v: Number,
  },
  {
    timeseries: {
      timeField: 't',
      metaField: 'asset',
      granularity: 'minutes',
    },
  }
);

CandleSchema.index({ asset: 1, timeframe: 1, t: -1 });

module.exports = model('Candle', CandleSchema);
