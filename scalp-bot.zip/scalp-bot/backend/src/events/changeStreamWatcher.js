const Trade = require('../models/Trade');
const { BalanceLog } = require('../models/Config');
const TuningLog = require('../models/TuningLog');
const { emitTradeOpened, emitTradeUpdated, emitTradeClosed, emitEquityChanged, emitTuningDecision } = require('./bus');

/**
 * This is the ONLY place in the codebase that touches MongoDB Change Streams
 * directly. Workers (BTC/ETH/GOLD) run as separate processes and simply
 * write to MongoDB via paperEngine — they never call the event bus directly.
 * This watcher detects those writes and re-emits them through the internal
 * bus, which the Socket.io layer (api/socket.js) subscribes to. If the
 * underlying transport ever changes (e.g. to Redis/Kafka), only this file
 * needs to change.
 */
function startChangeStreamWatchers() {
  const tradeStream = Trade.watch([], { fullDocument: 'updateLookup' });
  tradeStream.on('change', (change) => {
    if (change.operationType === 'insert') {
      emitTradeOpened(change.fullDocument);
    } else if (change.operationType === 'update' || change.operationType === 'replace') {
      const doc = change.fullDocument;
      if (doc && doc.outcome && doc.outcome.status === 'CLOSED') {
        emitTradeClosed(doc);
      } else if (doc) {
        emitTradeUpdated(doc);
      }
    }
  });
  tradeStream.on('error', (err) => console.error('[changeStream:Trade] error:', err.message));

  const balanceStream = BalanceLog.watch([], { fullDocument: 'updateLookup' });
  balanceStream.on('change', (change) => {
    if (change.operationType === 'insert') {
      emitEquityChanged(change.fullDocument);
    }
  });
  balanceStream.on('error', (err) => console.error('[changeStream:BalanceLog] error:', err.message));

  const tuningStream = TuningLog.watch([], { fullDocument: 'updateLookup' });
  tuningStream.on('change', (change) => {
    if (change.operationType === 'insert') {
      emitTuningDecision(change.fullDocument);
    }
  });
  tuningStream.on('error', (err) => console.error('[changeStream:TuningLog] error:', err.message));

  console.log('[changeStreams] watching Trade, BalanceLog, TuningLog collections');

  return { tradeStream, balanceStream, tuningStream };
}

module.exports = { startChangeStreamWatchers };
