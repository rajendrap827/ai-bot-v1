const { EventEmitter } = require('events');

/**
 * Internal event bus. Business logic (workers, engine) emits through this
 * interface rather than coupling directly to MongoDB Change Streams or
 * Socket.io. If the system later needs to move to Redis/Kafka for the
 * underlying transport, only this file changes — nothing else.
 */
const bus = new EventEmitter();
bus.setMaxListeners(50);

const EVENTS = {
  TRADE_OPENED: 'trade:opened',
  TRADE_UPDATED: 'trade:updated', // TP1 hit, trailing stop moved, etc.
  TRADE_CLOSED: 'trade:closed',
  EQUITY_CHANGED: 'equity:changed',
  TUNING_DECISION: 'tuning:decision',
};

function emitTradeOpened(trade) { bus.emit(EVENTS.TRADE_OPENED, trade); }
function emitTradeUpdated(trade) { bus.emit(EVENTS.TRADE_UPDATED, trade); }
function emitTradeClosed(trade) { bus.emit(EVENTS.TRADE_CLOSED, trade); }
function emitEquityChanged(balance) { bus.emit(EVENTS.EQUITY_CHANGED, balance); }
function emitTuningDecision(decision) { bus.emit(EVENTS.TUNING_DECISION, decision); }

module.exports = { bus, EVENTS, emitTradeOpened, emitTradeUpdated, emitTradeClosed, emitEquityChanged, emitTuningDecision };
