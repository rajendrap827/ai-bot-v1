const WebSocket = require('ws');

/**
 * Binance public WebSocket — no API key needed.
 * Two separate streams are used deliberately:
 *  - kline_5m: closed-candle events, used to feed the scoring engine
 *    (signals only ever evaluated on a CONFIRMED candle — anti-repaint rule).
 *  - aggTrade: raw trade ticks, used ONLY for real-time SL/TP/trailing-stop
 *    monitoring (paperEngine.manageOpenTrades). Never written to the DB —
 *    this is the in-memory-only tick handling decided during scaling design.
 */
function connectBinanceFeed(symbol, { onClosedCandle, onTick, onError }) {
  const streams = `${symbol.toLowerCase()}@kline_5m/${symbol.toLowerCase()}@aggTrade`;
  const url = `wss://stream.binance.com:9443/stream?streams=${streams}`;

  let ws;
  let reconnectDelay = 1000;
  const maxReconnectDelay = 30000;

  function connect() {
    ws = new WebSocket(url);

    ws.on('open', () => {
      console.log(`[binance:${symbol}] connected`);
      reconnectDelay = 1000; // reset backoff on a clean connect
    });

    ws.on('message', (raw) => {
      let msg;
      try {
        msg = JSON.parse(raw.toString());
      } catch (e) {
        return;
      }
      const data = msg.data;
      if (!data) return;

      if (data.e === 'kline') {
        const k = data.k;
        if (k.x) { // x = true means this candle is CLOSED/confirmed
          onClosedCandle({
            t: new Date(k.t),
            o: parseFloat(k.o),
            h: parseFloat(k.h),
            l: parseFloat(k.l),
            c: parseFloat(k.c),
            v: parseFloat(k.v),
          });
        }
      } else if (data.e === 'aggTrade') {
        onTick({ price: parseFloat(data.p), ts: new Date(data.T) });
      }
    });

    ws.on('error', (err) => {
      console.error(`[binance:${symbol}] error:`, err.message);
      if (onError) onError(err);
    });

    ws.on('close', () => {
      console.warn(`[binance:${symbol}] disconnected — reconnecting in ${reconnectDelay}ms`);
      setTimeout(connect, reconnectDelay);
      reconnectDelay = Math.min(reconnectDelay * 2, maxReconnectDelay);
    });
  }

  connect();

  return {
    close: () => ws && ws.close(),
  };
}

/**
 * Fetches recent closed candles via REST (used once at worker startup to
 * pre-fill the in-memory candle buffer before the WebSocket stream takes
 * over — the scoring engine needs ~215+ bars of warmup for the 200 EMA).
 */
async function fetchRecentCandles(symbol, limit = 320) {
  const axios = require('axios');
  const url = `https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=5m&limit=${limit}`;
  const res = await axios.get(url, { timeout: 15000 });
  return res.data.map((row) => ({
    t: new Date(row[0]),
    o: parseFloat(row[1]),
    h: parseFloat(row[2]),
    l: parseFloat(row[3]),
    c: parseFloat(row[4]),
    v: parseFloat(row[5]),
  }));
}

module.exports = { connectBinanceFeed, fetchRecentCandles };
