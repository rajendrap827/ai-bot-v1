const axios = require('axios');
const { ema } = require('../strategy/indicators');

const BINANCE_INTERVAL_MAP = { '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1h', '4h': '4h', '1d': '1d' };

/**
 * Returns { bull, bear } from the last CLOSED bar on the higher timeframe.
 * For crypto this hits Binance REST directly. For Gold, the caller passes
 * in candles fetched from the MT5 bridge collection instead (see goldWorker).
 */
async function getHtfTrendBinance(symbol, htfTimeframe, htfLen) {
  const interval = BINANCE_INTERVAL_MAP[htfTimeframe] || '1h';
  const url = `https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${htfLen + 10}`;
  const res = await axios.get(url, { timeout: 15000 });
  const closes = res.data.map((row) => parseFloat(row[4]));
  const emaSeries = ema(closes, htfLen);

  // Use the second-to-last bar as "last closed" (Binance includes the
  // still-forming current bar as the last element of the kline list).
  const i = closes.length - 2;
  if (i < 1 || emaSeries[i] == null) return { bull: null, bear: null };
  return { bull: closes[i] > emaSeries[i], bear: closes[i] < emaSeries[i] };
}

module.exports = { getHtfTrendBinance };
