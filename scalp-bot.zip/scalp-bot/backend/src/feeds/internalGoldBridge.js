const WebSocket = require('ws');

/**
 * The Python MT5 bridge (running under Wine/Xvfb) connects to this server
 * as a WebSocket CLIENT and streams two message types:
 *   { type: 'tick', price, ts }                — used only for SL/TP/trailing checks, never stored
 *   { type: 'candle', t, o, h, l, c, v }        — closed 5m candle, fed to the scoring engine
 * This mirrors binanceFeed.js's callback shape so goldWorker.js can share
 * the same downstream logic as the crypto workers. Raw ticks never touch
 * MongoDB, consistent with the no-raw-tick-storage decision in Section 11.
 */
function startInternalGoldBridge(port, { onClosedCandle, onTick }) {
  const wss = new WebSocket.Server({ port });
  let bridgeConnected = false;

  wss.on('connection', (ws) => {
    bridgeConnected = true;
    console.log('[gold-bridge] Python MT5 bridge connected');

    ws.on('message', (raw) => {
      let msg;
      try {
        msg = JSON.parse(raw.toString());
      } catch (e) {
        return;
      }
      if (msg.type === 'tick') {
        onTick({ price: msg.price, ts: new Date(msg.ts) });
      } else if (msg.type === 'candle') {
        onClosedCandle({ t: new Date(msg.t), o: msg.o, h: msg.h, l: msg.l, c: msg.c, v: msg.v || 0 });
      }
    });

    ws.on('close', () => {
      bridgeConnected = false;
      console.warn('[gold-bridge] Python MT5 bridge disconnected — waiting for reconnect');
    });
  });

  console.log(`[gold-bridge] listening on port ${port} for the Python MT5 bridge`);

  return {
    isConnected: () => bridgeConnected,
    close: () => wss.close(),
  };
}

module.exports = { startInternalGoldBridge };
