const { ema, atr, adx, vwapDailyReset, pivotHigh, pivotLow, ffillOnFlag } = require('./indicators');
const { classifyStage, getSession } = require('./stage');
const { detectBOS, detectCHoCH, detectLiquiditySweep } = require('./smc');

/**
 * Computes the full signal for the last CONFIRMED bar (index = candles.length - 2,
 * since the last element is assumed to be the still-forming live bar).
 *
 * candles: array of { t, o, h, l, c, v }, oldest first.
 * cfg: merged config (global + per-asset overrides) for this asset.
 * asset: 'BTC' | 'ETH' | 'GOLD'
 * htf: { bull: bool|null, bear: bool|null } — from the higher-timeframe trend check
 */
function computeSignal(candles, cfg, asset, htf = { bull: null, bear: null }) {
  const n = candles.length;
  if (n < cfg.emaLen200 + 15) return { signal: null, reason: 'warmup' };

  const closes = candles.map((c) => c.c);
  const emaFast = ema(closes, cfg.emaFast || 9);
  const emaSlow = ema(closes, cfg.emaSlow || 21);
  const ema200 = ema(closes, cfg.emaLen200 || 200);
  const atrSeries = atr(candles, cfg.atrLen || 14);
  const adxSeries = adx(candles, cfg.adxLen || 14);
  const vwap = vwapDailyReset(candles);

  const srLookback = cfg.srLookback || 20;
  const ph = pivotHigh(candles, srLookback, srLookback);
  const pl = pivotLow(candles, srLookback, srLookback);
  const resSeries = ffillOnFlag(candles.map((c) => c.h), ph);
  const supSeries = ffillOnFlag(candles.map((c) => c.l), pl);

  const structLen = cfg.structLen || 5;
  const sh = pivotHigh(candles, structLen, structLen);
  const sl = pivotLow(candles, structLen, structLen);
  const swingHighSeries = ffillOnFlag(candles.map((c) => c.h), sh);
  const swingLowSeries = ffillOnFlag(candles.map((c) => c.l), sl);

  const i = n - 2; // last confirmed bar
  const row = candles[i];
  const prev = candles[i - 1];
  const a = atrSeries[i];
  if (a == null || a === 0) return { signal: null, reason: 'no_atr' };

  const stage = classifyStage(closes, ema200, atrSeries, i);

  // ── Area of Value (support/resistance/EMA200/EMA21/VWAP) ──
  const res = resSeries[i];
  const sup = supSeries[i];
  const nearRes = res != null && row.h >= res - a && row.l <= res + a;
  const nearSup = sup != null && row.h >= sup - a && row.l <= sup + a;
  const nearEma200 = Math.abs(row.c - ema200[i]) <= a * (cfg.aovAtrMult || 1.5);
  const nearEmaSlow = Math.abs(row.c - emaSlow[i]) <= a * (cfg.aovEmaSlowAtrMult || 0.8);
  const nearVwap = vwap[i] != null && Math.abs(row.c - vwap[i]) <= a * (cfg.vwapAtrMult || 0.8);
  const aovMatch = nearSup || nearRes || nearEma200 || nearEmaSlow || nearVwap;

  // ── Candlestick patterns ──
  const body = Math.abs(row.c - row.o);
  const range = row.h - row.l;
  const upperWick = row.h - Math.max(row.c, row.o);
  const lowerWick = Math.min(row.c, row.o) - row.l;
  const bodyPct = range > 0 ? body / range : 0;
  const avgBody = avgAbsBodyOverWindow(candles, i, 20);

  const hammer = lowerWick >= body * 2 && upperWick <= body * 0.3 && row.c > row.o && bodyPct < 0.4;
  const shootingStar = upperWick >= body * 2 && lowerWick <= body * 0.3 && row.c < row.o && bodyPct < 0.4;
  const bullEngulf = row.c > row.o && prev.c < prev.o && row.c > prev.o && row.o < prev.c;
  const bearEngulf = row.c < row.o && prev.c > prev.o && row.c < prev.o && row.o > prev.c;
  const bullPin = lowerWick >= body * 2.5 && row.c > row.o;
  const bearPin = upperWick >= body * 2.5 && row.c < row.o;

  // ── SMC: BOS / CHoCH / liquidity sweep ──
  const { bullBos, bearBos } = detectBOS(candles, swingHighSeries, swingLowSeries, i);
  const { bullChoch, bearChoch } = detectCHoCH(bullBos, bearBos, stage);
  const { bullSweep, bearSweep } = detectLiquiditySweep(candles, i, 20);

  // ── Volume (guarded — Gold feeds are frequently unreliable here) ──
  const volOk = row.v != null && row.v > 0;
  const avgVol = avgVolumeOverWindow(candles, i, 20);
  const highVolume = volOk && avgVol != null && row.v > avgVol * 1.3;
  const hl = range !== 0 ? range : 0.0001;
  const delta = volOk ? (row.v * (row.c - row.l)) / hl - (row.v * (row.h - row.c)) / hl : 0;

  // ── Confirmation candle ──
  const bullConfirm = row.c > row.o && row.c > prev.c && body > (avgBody || 0) * 0.4;
  const bearConfirm = row.c < row.o && row.c < prev.c && body > (avgBody || 0) * 0.4;

  // ── 6-component weighted scoring ──
  const w = cfg.weights || { stage: 1, aov: 1, pattern: 1, ema: 1, smc: 1, volume: 1 };

  const bullChecks = {
    stage: mk(stage === 'ADVANCING' || stage === 'ACCUMULATION', w.stage, stage),
    aov: mk(nearSup || nearEmaSlow || nearEma200 || nearVwap, w.aov, aovLabel({ nearSup, nearRes, nearEma200, nearEmaSlow, nearVwap })),
    pattern: mk(hammer || bullEngulf || bullPin, w.pattern, patternLabel({ hammer, bullEngulf, bullPin })),
    ema: mk(emaFast[i] > emaSlow[i], w.ema, 'ema9>ema21'),
    smc: mk(bullBos || bullChoch || bullSweep, w.smc, smcLabel({ bullBos, bullChoch, bullSweep })),
    volume: mk(highVolume && delta > 0, w.volume, highVolume ? 'surge_buy' : 'normal'),
  };
  const bearChecks = {
    stage: mk(stage === 'DECLINING' || stage === 'DISTRIBUTION', w.stage, stage),
    aov: mk(nearRes || nearEmaSlow || nearEma200 || nearVwap, w.aov, aovLabel({ nearSup, nearRes, nearEma200, nearEmaSlow, nearVwap })),
    pattern: mk(shootingStar || bearEngulf || bearPin, w.pattern, patternLabel({ shootingStar, bearEngulf, bearPin })),
    ema: mk(emaFast[i] < emaSlow[i], w.ema, 'ema9<ema21'),
    smc: mk(bearBos || bearChoch || bearSweep, w.smc, smcLabel({ bearBos, bearChoch, bearSweep })),
    volume: mk(highVolume && delta < 0, w.volume, highVolume ? 'surge_sell' : 'normal'),
  };

  const bullTotal = sumChecks(bullChecks);
  const bearTotal = sumChecks(bearChecks);

  // ── Session ──
  const sessionInfo = getSession(new Date(row.t));
  const sessionActive = cfg.useSessionFilter
    ? (asset === 'GOLD' ? sessionInfo.goldActive : sessionInfo.cryptoActive)
    : true;

  // ── Gates ──
  const htfLongOk = htf.bull === null ? true : htf.bull;
  const htfShortOk = htf.bear === null ? true : htf.bear;
  const adxOk = adxSeries[i] != null && adxSeries[i] >= (cfg.adxMin || 18);
  const aovLongOk = !cfg.requireAreaOfValue || (nearSup || nearEmaSlow || nearEma200 || nearVwap);
  const aovShortOk = !cfg.requireAreaOfValue || (nearRes || nearEmaSlow || nearEma200 || nearVwap);
  const confirmLongOk = !cfg.requireConfirmCandle || bullConfirm;
  const confirmShortOk = !cfg.requireConfirmCandle || bearConfirm;

  const longOk =
    sessionActive && adxOk && htfLongOk &&
    bullTotal >= (cfg.minScore || 4) &&
    bullTotal - bearTotal >= (cfg.netMargin || 1) &&
    aovLongOk && confirmLongOk;

  const shortOk =
    sessionActive && adxOk && htfShortOk &&
    bearTotal >= (cfg.minScore || 4) &&
    bearTotal - bullTotal >= (cfg.netMargin || 1) &&
    aovShortOk && confirmShortOk;

  const signal = longOk ? 'LONG' : shortOk ? 'SHORT' : null;

  // ── Initial SL / TP1 / TP2 (1 ATR beyond S/R, Rayner rule) ──
  let sl_ = null, tp1 = null, tp2 = null;
  const slMult = cfg.slAtrMult || 1.5;
  const rr = cfg.rrRatio || 2.0;
  if (signal === 'LONG') {
    sl_ = nearSup ? sup - a * slMult : nearEmaSlow ? emaSlow[i] - a * slMult : row.c - a * slMult;
    const risk = row.c - sl_;
    tp1 = row.c + risk * rr;
    tp2 = row.c + risk * (rr + 1);
  } else if (signal === 'SHORT') {
    sl_ = nearRes ? res + a * slMult : nearEmaSlow ? emaSlow[i] + a * slMult : row.c + a * slMult;
    const risk = sl_ - row.c;
    tp1 = row.c - risk * rr;
    tp2 = row.c - risk * (rr + 1);
  }

  const checks = signal === 'LONG' ? bullChecks : signal === 'SHORT' ? bearChecks : null;
  const setupFingerprint = checks ? buildFingerprint(checks) : null;

  return {
    signal,
    time: row.t,
    entry: row.c,
    sl: sl_,
    tp1,
    tp2,
    atr: a,
    stage,
    session: sessionInfo.name,
    htfTrend: htf.bull ? 'BULL' : htf.bear ? 'BEAR' : 'NA',
    adx: adxSeries[i],
    bullScore: bullTotal,
    bearScore: bearTotal,
    score: signal === 'LONG' ? bullTotal : signal === 'SHORT' ? bearTotal : Math.max(bullTotal, bearTotal),
    oppScore: signal === 'LONG' ? bearTotal : signal === 'SHORT' ? bullTotal : 0,
    netMargin: signal === 'LONG' ? bullTotal - bearTotal : signal === 'SHORT' ? bearTotal - bullTotal : 0,
    confirmationCandle: signal === 'LONG' ? bullConfirm : signal === 'SHORT' ? bearConfirm : false,
    checks,
    setupFingerprint,
  };
}

// ── helpers ──
function mk(passed, weight, value) {
  return { passed: !!passed, weight, value };
}
function sumChecks(checks) {
  return Object.values(checks).reduce((s, c) => s + (c.passed ? c.weight : 0), 0);
}
function buildFingerprint(checks) {
  return Object.entries(checks)
    .filter(([, c]) => c.passed)
    .map(([k]) => k.toUpperCase())
    .join('-') || 'NONE';
}
function aovLabel({ nearSup, nearRes, nearEma200, nearEmaSlow, nearVwap }) {
  if (nearSup) return 'near_support';
  if (nearRes) return 'near_resistance';
  if (nearEma200) return 'near_ema200';
  if (nearEmaSlow) return 'near_ema21';
  if (nearVwap) return 'near_vwap';
  return 'none';
}
function patternLabel(p) {
  return Object.entries(p).find(([, v]) => v)?.[0] || 'none';
}
function smcLabel(p) {
  return Object.entries(p).find(([, v]) => v)?.[0] || 'none';
}
function avgAbsBodyOverWindow(candles, i, window) {
  if (i < window) return null;
  let sum = 0;
  for (let j = i - window; j < i; j++) sum += Math.abs(candles[j].c - candles[j].o);
  return sum / window;
}
function avgVolumeOverWindow(candles, i, window) {
  if (i < window) return null;
  let sum = 0;
  for (let j = i - window; j < i; j++) sum += candles[j].v || 0;
  return sum / window;
}

module.exports = { computeSignal };
