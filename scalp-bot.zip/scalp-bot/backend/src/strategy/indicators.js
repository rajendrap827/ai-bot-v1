/**
 * Core indicator math, operating on an array of candles:
 * { t: <Date or ms>, o, h, l, c, v }
 * All functions return arrays aligned with the input (same length),
 * using `null` where there isn't enough history yet.
 */

function ema(values, period) {
  const k = 2 / (period + 1);
  const out = new Array(values.length).fill(null);
  let prev = null;
  for (let i = 0; i < values.length; i++) {
    if (values[i] == null) { out[i] = prev; continue; }
    prev = prev == null ? values[i] : values[i] * k + prev * (1 - k);
    out[i] = prev;
  }
  return out;
}

function trueRange(candles) {
  const out = new Array(candles.length).fill(null);
  for (let i = 0; i < candles.length; i++) {
    if (i === 0) { out[i] = candles[i].h - candles[i].l; continue; }
    const prevClose = candles[i - 1].c;
    out[i] = Math.max(
      candles[i].h - candles[i].l,
      Math.abs(candles[i].h - prevClose),
      Math.abs(candles[i].l - prevClose)
    );
  }
  return out;
}

function atr(candles, period = 14) {
  const tr = trueRange(candles);
  // Wilder's smoothing == ema with alpha = 1/period
  const out = new Array(candles.length).fill(null);
  let prev = null;
  const alpha = 1 / period;
  for (let i = 0; i < tr.length; i++) {
    prev = prev == null ? tr[i] : tr[i] * alpha + prev * (1 - alpha);
    out[i] = prev;
  }
  return out;
}

function adx(candles, period = 14) {
  const n = candles.length;
  const plusDM = new Array(n).fill(0);
  const minusDM = new Array(n).fill(0);
  for (let i = 1; i < n; i++) {
    const up = candles[i].h - candles[i - 1].h;
    const dn = candles[i - 1].l - candles[i].l;
    plusDM[i] = (up > dn && up > 0) ? up : 0;
    minusDM[i] = (dn > up && dn > 0) ? dn : 0;
  }
  const tr = trueRange(candles);
  const smooth = (arr) => {
    const out = new Array(arr.length).fill(null);
    let prev = null;
    const alpha = 1 / period;
    for (let i = 0; i < arr.length; i++) {
      prev = prev == null ? arr[i] : arr[i] * alpha + prev * (1 - alpha);
      out[i] = prev;
    }
    return out;
  };
  const trS = smooth(tr);
  const pDIs = smooth(plusDM).map((v, i) => (trS[i] ? (100 * v) / trS[i] : 0));
  const mDIs = smooth(minusDM).map((v, i) => (trS[i] ? (100 * v) / trS[i] : 0));
  const dx = pDIs.map((p, i) => {
    const sum = p + mDIs[i];
    return sum ? (100 * Math.abs(p - mDIs[i])) / sum : 0;
  });
  return smooth(dx);
}

/**
 * VWAP with a daily reset at 00:00 UTC — applies uniformly to BTC, ETH,
 * and GOLD since none of them have a natural single-session open.
 */
function vwapDailyReset(candles) {
  const out = new Array(candles.length).fill(null);
  let dayKey = null;
  let cumPV = 0;
  let cumV = 0;
  for (let i = 0; i < candles.length; i++) {
    const d = new Date(candles[i].t);
    const key = `${d.getUTCFullYear()}-${d.getUTCMonth()}-${d.getUTCDate()}`;
    if (key !== dayKey) {
      dayKey = key;
      cumPV = 0;
      cumV = 0;
    }
    const typicalPrice = (candles[i].h + candles[i].l + candles[i].c) / 3;
    const vol = Math.max(candles[i].v || 0, 1); // guard against zero/missing volume
    cumPV += typicalPrice * vol;
    cumV += vol;
    out[i] = cumV ? cumPV / cumV : null;
  }
  return out;
}

/** Pivot high/low — true at index i if it's the extreme of the [i-left, i+right] window. */
function pivotHigh(candles, left, right) {
  const out = new Array(candles.length).fill(false);
  for (let i = left; i < candles.length - right; i++) {
    let isMax = true;
    let dupCount = 0;
    for (let j = i - left; j <= i + right; j++) {
      if (candles[j].h > candles[i].h) { isMax = false; break; }
      if (candles[j].h === candles[i].h) dupCount++;
    }
    if (isMax && dupCount === 1) out[i] = true;
  }
  return out;
}

function pivotLow(candles, left, right) {
  const out = new Array(candles.length).fill(false);
  for (let i = left; i < candles.length - right; i++) {
    let isMin = true;
    let dupCount = 0;
    for (let j = i - left; j <= i + right; j++) {
      if (candles[j].l < candles[i].l) { isMin = false; break; }
      if (candles[j].l === candles[i].l) dupCount++;
    }
    if (isMin && dupCount === 1) out[i] = true;
  }
  return out;
}

/** Forward-fills the most recent pivot value (like Pine's ta.valuewhen + ffill pattern). */
function ffillOnFlag(values, flags) {
  const out = new Array(values.length).fill(null);
  let last = null;
  for (let i = 0; i < values.length; i++) {
    if (flags[i]) last = values[i];
    out[i] = last;
  }
  return out;
}

module.exports = { ema, atr, adx, vwapDailyReset, pivotHigh, pivotLow, ffillOnFlag, trueRange };
