/**
 * SMC (Smart Money Concepts) detection: Break of Structure, Change of
 * Character, and liquidity sweeps. Operates on confirmed bars only.
 */

function detectBOS(candles, swingHighSeries, swingLowSeries, i) {
  if (i < 1) return { bullBos: false, bearBos: false };
  const swingHigh = swingHighSeries[i];
  const swingLow = swingLowSeries[i];
  const bullBos = swingHigh != null && candles[i].c > swingHigh && candles[i - 1].c <= swingHigh;
  const bearBos = swingLow != null && candles[i].c < swingLow && candles[i - 1].c >= swingLow;
  return { bullBos, bearBos };
}

function detectCHoCH(bullBos, bearBos, stage) {
  const bullChoch = bullBos && (stage === 'DECLINING' || stage === 'DISTRIBUTION');
  const bearChoch = bearBos && (stage === 'ADVANCING' || stage === 'ACCUMULATION');
  return { bullChoch, bearChoch };
}

function detectLiquiditySweep(candles, i, lookback = 20) {
  if (i < lookback + 1) return { bullSweep: false, bearSweep: false };
  let highestHigh = -Infinity;
  let lowestLow = Infinity;
  for (let j = i - lookback; j < i; j++) {
    if (candles[j].h > highestHigh) highestHigh = candles[j].h;
    if (candles[j].l < lowestLow) lowestLow = candles[j].l;
  }
  const bullSweep = candles[i].l < lowestLow && candles[i].c > lowestLow;
  const bearSweep = candles[i].h > highestHigh && candles[i].c < highestHigh;
  return { bullSweep, bearSweep };
}

module.exports = { detectBOS, detectCHoCH, detectLiquiditySweep };
