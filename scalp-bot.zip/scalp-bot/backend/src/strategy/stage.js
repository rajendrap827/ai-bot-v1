/**
 * Market stage classification — Rayner Teo framework, driven by the 200 EMA.
 * i = index of the bar being classified (must have at least 10 prior bars
 * for the slope calculation).
 */
function classifyStage(closes, ema200, atrSeries, i) {
  if (i < 10 || ema200[i] == null || ema200[i - 10] == null || atrSeries[i] == null) {
    return 'UNCLEAR';
  }
  const slope = ema200[i] - ema200[i - 10];
  const rising = slope > 0;
  const flat = Math.abs(slope) < atrSeries[i] * 0.5;
  const above = closes[i] > ema200[i];

  if (above && rising && !flat) return 'ADVANCING';
  if (!above && flat) return 'ACCUMULATION';
  if (above && flat) return 'DISTRIBUTION';
  if (!above && !rising && !flat) return 'DECLINING';
  return 'UNCLEAR';
}

/**
 * Dubai (UTC+4) session windows, ported from the Pine v2 indicator.
 * All boundaries are expressed in UTC hours (fractional).
 */
function getSession(date) {
  const hour = date.getUTCHours() + date.getUTCMinutes() / 60;
  if (hour >= 0 && hour < 8.5) return { name: 'ASIAN', goldActive: false, cryptoActive: false };
  if (hour >= 8.5 && hour < 12.5) return { name: 'LONDON', goldActive: true, cryptoActive: false };
  if (hour >= 12.5 && hour < 16) return { name: 'OVERLAP', goldActive: true, cryptoActive: true };
  if (hour >= 16 && hour < 20) return { name: 'NY', goldActive: false, cryptoActive: true };
  return { name: 'NY_CLOSE', goldActive: false, cryptoActive: false };
}

module.exports = { classifyStage, getSession };
