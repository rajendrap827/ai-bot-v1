const { runAssetWorker } = require('./assetWorker');
const { startInternalGoldBridge } = require('../feeds/internalGoldBridge');
const Candle = require('../models/Candle');

const GOLD_BRIDGE_PORT = process.env.GOLD_BRIDGE_PORT ? parseInt(process.env.GOLD_BRIDGE_PORT, 10) : 4101;

/**
 * Gold has no free real-time WebSocket source, so the Python MT5 bridge
 * (running under Wine/Xvfb against the Exness demo account) connects to
 * this Node process over a local WebSocket and streams ticks + closed
 * 5m candles. Seeding uses whatever candles are already in the time-series
 * Candle collection (populated by the Python bridge on its own startup,
 * or by a prior run of this worker) rather than a REST call, since Gold
 * has no equivalent of Binance's public REST history endpoint here.
 */
async function startGoldWorker() {
  return runAssetWorker({
    asset: 'GOLD',
    timeframe: '5m',
    seedCandles: async () => {
      const docs = await Candle.find({ asset: 'GOLD', timeframe: '5m' }).sort({ t: -1 }).limit(320).lean();
      return docs.reverse().map((d) => ({ t: d.t, o: d.o, h: d.h, l: d.l, c: d.c, v: d.v }));
    },
    connectFeed: ({ onClosedCandle, onTick }) =>
      startInternalGoldBridge(GOLD_BRIDGE_PORT, { onClosedCandle, onTick }),
    // No free HTF source for Gold without a broker API — the HTF gate is
    // simply skipped (bull/bear stay null, which getMergedConfig/scoring
    // treats as "no HTF opinion, allow the trade") until a paid feed or a
    // second MT5 timeframe subscription is added in the bridge.
    getHtfTrend: async () => ({ bull: null, bear: null }),
  });
}

module.exports = { startGoldWorker, GOLD_BRIDGE_PORT };
