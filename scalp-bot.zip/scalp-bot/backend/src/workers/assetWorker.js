const { computeSignal } = require('../strategy/scoring');
const { atr } = require('../strategy/indicators');
const { getMergedConfig } = require('../config/configLoader');
const { getNewsContext } = require('../news/finnhubCalendar');
const { openTrade, manageOpenTrades, currentBalance } = require('../engine/paperEngine');
const Trade = require('../models/Trade');
const Candle = require('../models/Candle');

const MAX_BUFFER = 400;

/**
 * runAssetWorker wires together: a candle feed (closed 5m candles), a tick
 * feed (for real-time SL/TP/trailing), an HTF trend fetcher, and the
 * strategy + paper engine. BTC, ETH, and GOLD all run this same logic —
 * only the feed connectors differ (see cryptoWorker.js / goldWorker.js).
 */
async function runAssetWorker({
  asset,
  timeframe = '5m',
  seedCandles,         // async () => Candle[]   (REST backfill at startup)
  connectFeed,         // ({ onClosedCandle, onTick }) => { close() }
  getHtfTrend,         // async () => { bull, bear }
}) {
  let buffer = await seedCandles();
  if (!Array.isArray(buffer) || buffer.length < 50) {
    console.warn(`[${asset}] WARNING: seed buffer has only ${buffer ? buffer.length : 0} candles — signals will stay in warmup longer than expected.`);
    buffer = buffer || [];
  }
  console.log(`[${asset}] seeded with ${buffer.length} candles`);

  let lastAtr = null;
  let barIndex = buffer.length;
  let lastSignalBarIndex = -Infinity;

  async function persistCandle(candle) {
    try {
      await Candle.create({ asset, timeframe, t: candle.t, o: candle.o, h: candle.h, l: candle.l, c: candle.c, v: candle.v });
    } catch (err) {
      console.error(`[${asset}] failed to persist candle:`, err.message);
    }
  }

  async function onClosedCandle(candle) {
    buffer.push(candle);
    if (buffer.length > MAX_BUFFER) buffer = buffer.slice(buffer.length - MAX_BUFFER);
    barIndex += 1;

    const atrSeries = atr(buffer, 14);
    lastAtr = atrSeries[atrSeries.length - 1];

    await persistCandle(candle);

    try {
      const { cfg } = await getMergedConfig(asset);
      const htf = cfg.htfTimeframe ? await safeGetHtf(getHtfTrend) : { bull: null, bear: null };
      const signal = computeSignal(buffer, cfg, asset, htf);

      if (!signal.signal) return;

      if (barIndex - lastSignalBarIndex < (cfg.cooldownBars || 0)) {
        console.log(`[${asset}] signal suppressed by cooldown (${barIndex - lastSignalBarIndex} bars since last)`);
        return;
      }

      const openCount = await Trade.countDocuments({ asset, 'outcome.status': 'OPEN' });
      if (openCount >= (cfg.maxOpenPerAsset || 1)) {
        console.log(`[${asset}] signal skipped — max open positions (${cfg.maxOpenPerAsset}) reached`);
        return;
      }

      const entryTime = new Date(signal.time);
      const newsContext = cfg.useNewsBlackout
        ? await getNewsContext(entryTime, cfg.newsBlackoutMinutes || 30)
        : { highImpactEventNearby: false, events: [], blackoutActive: false, sentiment: { available: false, score: null, label: null, source: null } };

      if (cfg.useNewsBlackout && newsContext.blackoutActive) {
        console.log(`[${asset}] signal skipped — inside news blackout window`);
        return;
      }

      const trade = await openTrade({ asset, timeframe, signal, cfg, paramsVersion: cfg.paramsVersion, newsContext });
      if (trade) {
        lastSignalBarIndex = barIndex;
        console.log(`[${asset}] OPENED ${signal.signal} @ ${signal.entry} | score ${signal.score} vs opp ${signal.oppScore} | stage ${signal.stage} | session ${signal.session}`);
      }
    } catch (err) {
      console.error(`[${asset}] error processing closed candle:`, err.message);
    }
  }

  async function onTick(tick) {
    if (lastAtr == null) return; // not enough warmup yet
    try {
      const { cfg } = await getMergedConfig(asset);
      await manageOpenTrades(asset, tick.price, lastAtr, cfg);
    } catch (err) {
      console.error(`[${asset}] error managing open trades on tick:`, err.message);
    }
  }

  const handle = connectFeed({ onClosedCandle, onTick });
  console.log(`[${asset}] worker running (timeframe=${timeframe})`);
  return handle;
}

async function safeGetHtf(getHtfTrend) {
  try {
    return await getHtfTrend();
  } catch (err) {
    console.warn('[htf] fetch failed, proceeding without HTF gate this cycle:', err.message);
    return { bull: null, bear: null };
  }
}

module.exports = { runAssetWorker };
