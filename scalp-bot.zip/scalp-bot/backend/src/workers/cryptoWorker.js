const { runAssetWorker } = require('./assetWorker');
const { connectBinanceFeed, fetchRecentCandles } = require('../feeds/binanceFeed');
const { getHtfTrendBinance } = require('../feeds/htfTrend');

const ASSET_SYMBOL_MAP = { BTC: 'BTCUSDT', ETH: 'ETHUSDT' };

async function startCryptoWorker(asset) {
  const symbol = ASSET_SYMBOL_MAP[asset];
  if (!symbol) throw new Error('startCryptoWorker: unknown asset ' + asset);

  return runAssetWorker({
    asset: asset,
    timeframe: '5m',
    seedCandles: () => fetchRecentCandles(symbol, 320),
    connectFeed: ({ onClosedCandle, onTick }) =>
      connectBinanceFeed(symbol, {
        onClosedCandle: onClosedCandle,
        onTick: onTick,
        onError: (err) => console.error('[' + asset + '] feed error:', err.message),
      }),
    getHtfTrend: () => getHtfTrendBinance(symbol, '1h', 50),
  });
}

module.exports = { startCryptoWorker };
