const express = require('express');
const { BalanceLog } = require('../../models/Config');

const router = express.Router();

/** GET /api/equity — full equity curve (balance over time), for the dashboard chart. */
router.get('/', async (req, res) => {
  try {
    const { limit = 2000 } = req.query;
    const points = await BalanceLog.find({}).sort({ ts: 1 }).limit(Math.min(parseInt(limit, 10) || 2000, 5000)).lean();
    res.json({ count: points.length, points });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
