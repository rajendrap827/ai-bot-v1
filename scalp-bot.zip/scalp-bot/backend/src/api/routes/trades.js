const express = require('express');
const Trade = require('../../models/Trade');

const router = express.Router();

/** GET /api/trades — closed trade history with dashboard filters. */
router.get('/', async (req, res) => {
  try {
    const { asset, session, stage, minScore, exitReason, limit = 200 } = req.query;
    const query = { 'outcome.status': 'CLOSED' };
    if (asset) query.asset = asset;
    if (session) query['entryBasis.session'] = session;
    if (stage) query['entryBasis.marketStage'] = stage;
    if (exitReason) query['outcome.exitReason'] = exitReason;
    if (minScore) query['entryBasis.bullScore'] = { $gte: parseInt(minScore, 10) }; // approximate filter; refined client-side if needed

    const trades = await Trade.find(query).sort({ 'outcome.exitTime': -1 }).limit(Math.min(parseInt(limit, 10) || 200, 1000)).lean();
    res.json({ count: trades.length, trades });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/** GET /api/trades/open — live open positions across all assets (or filtered by asset). */
router.get('/open', async (req, res) => {
  try {
    const { asset } = req.query;
    const query = { 'outcome.status': 'OPEN' };
    if (asset) query.asset = asset;
    const trades = await Trade.find(query).sort({ 'execution.entryTime': -1 }).lean();
    res.json({ count: trades.length, trades });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/** GET /api/trades/:tradeId — full detail for a single trade. */
router.get('/:tradeId', async (req, res) => {
  try {
    const trade = await Trade.findOne({ tradeId: req.params.tradeId }).lean();
    if (!trade) return res.status(404).json({ error: 'not found' });
    res.json(trade);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
