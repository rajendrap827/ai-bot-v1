const express = require('express');
const TuningLog = require('../../models/TuningLog');

const router = express.Router();

/** GET /api/tuning-log — every self-tuning decision, with full explanation. */
router.get('/', async (req, res) => {
  try {
    const { asset, component, limit = 200 } = req.query;
    const query = {};
    if (asset) query.asset = asset;
    if (component) query.component = component;
    const logs = await TuningLog.find(query).sort({ ts: -1 }).limit(Math.min(parseInt(limit, 10) || 200, 1000)).lean();
    res.json({ count: logs.length, logs });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
