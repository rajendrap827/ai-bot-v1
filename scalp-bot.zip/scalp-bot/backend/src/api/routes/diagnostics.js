const express = require('express');
const { computeMetrics, computeParamCorrelationReport } = require('../../tuning/metrics');

const router = express.Router();

/** GET /api/diagnostics/metrics/:asset — expectancy, win-rate, Win Days %, drawdown, Sharpe. */
router.get('/metrics/:asset', async (req, res) => {
  try {
    const winDayTarget = req.query.winDayTarget ? parseFloat(req.query.winDayTarget) : 50;
    const metrics = await computeMetrics(req.params.asset, { winDayTarget });
    res.json(metrics);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/** GET /api/diagnostics/correlation/:asset — read-only parameter-correlation report (Section 9 of the spec). */
router.get('/correlation/:asset', async (req, res) => {
  try {
    const report = await computeParamCorrelationReport(req.params.asset);
    res.json(report);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
