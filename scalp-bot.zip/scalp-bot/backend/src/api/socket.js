const { Server } = require('socket.io');
const { bus, EVENTS } = require('../events/bus');
const env = require('../config/env');

/**
 * Attaches Socket.io to the given HTTP server and forwards internal bus
 * events to connected dashboard clients. The dashboard never talks to
 * MongoDB or Change Streams directly — only through this socket layer
 * (or the REST routes for initial page loads / history).
 */
function attachSocket(httpServer) {
  const io = new Server(httpServer, {
    cors: { origin: env.socketCorsOrigin },
  });

  bus.on(EVENTS.TRADE_OPENED, (trade) => io.emit('trade:opened', trade));
  bus.on(EVENTS.TRADE_UPDATED, (trade) => io.emit('trade:updated', trade));
  bus.on(EVENTS.TRADE_CLOSED, (trade) => io.emit('trade:closed', trade));
  bus.on(EVENTS.EQUITY_CHANGED, (point) => io.emit('equity:changed', point));
  bus.on(EVENTS.TUNING_DECISION, (decision) => io.emit('tuning:decision', decision));

  io.on('connection', (socket) => {
    console.log(`[socket] client connected: ${socket.id}`);
    socket.on('disconnect', () => console.log(`[socket] client disconnected: ${socket.id}`));
  });

  return io;
}

module.exports = { attachSocket };
