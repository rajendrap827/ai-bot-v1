const express = require('express');
const http = require('http');
const cors = require('cors');
const env = require('../config/env');
const { attachSocket } = require('./socket');

const tradesRouter = require('./routes/trades');
const equityRouter = require('./routes/equity');
const tuningLogRouter = require('./routes/tuningLog');
const diagnosticsRouter = require('./routes/diagnostics');

function createServer() {
  const app = express();
  app.use(cors({ origin: env.socketCorsOrigin }));
  app.use(express.json());

  app.get('/health', (req, res) => res.json({ status: 'ok', ts: new Date().toISOString() }));

  app.use('/api/trades', tradesRouter);
  app.use('/api/equity', equityRouter);
  app.use('/api/tuning-log', tuningLogRouter);
  app.use('/api/diagnostics', diagnosticsRouter);

  const httpServer = http.createServer(app);
  const io = attachSocket(httpServer);

  return { app, httpServer, io };
}

module.exports = { createServer };
