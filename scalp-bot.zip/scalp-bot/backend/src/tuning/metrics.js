const Trade = require('../models/Trade');

/**
 * Aggregates closed trades into daily PnL buckets (UTC date) and computes
 * the standard set of performance metrics, including Win Days % — the
 * percentage of trading days where PnL reached `winDayTarget`. This is a
 * reporting/diagnostic metric only; it does not feed the live tuner.
 */
async function computeMetrics(asset, { winDayTarget = 50, strategyId = 'default', accountId = 'paper-main' } = {}) {
  const trades = await Trade.find({ asset, strategyId, accountId, 'outcome.status': 'CLOSED' }).lean();
  if (trades.length === 0) {
    return {
      totalTrades: 0, winRate: 0, expectancy: 0, profitFactor: 0,
      winDaysPct: 0, totalDays: 0, daysAboveTarget: 0, maxDrawdown: 0, sharpe: 0,
      dailyPnl: {},
    };
  }

  const dailyPnl = {};
  let wins = 0, sumWinR = 0, sumLossR = 0, sumR = 0;
  for (const t of trades) {
    const day = (t.outcome.exitTime ? new Date(t.outcome.exitTime) : new Date(t.createdAt)).toISOString().slice(0, 10);
    dailyPnl[day] = (dailyPnl[day] || 0) + (t.outcome.pnlUsd || 0);
    const r = t.outcome.rMultiple || 0;
    sumR += r;
    if (r > 0) { wins++; sumWinR += r; } else { sumLossR += r; }
  }

  const days = Object.keys(dailyPnl).sort();
  const dailyValues = days.map((d) => dailyPnl[d]);
  const daysAboveTarget = dailyValues.filter((v) => v >= winDayTarget).length;
  const winDaysPct = days.length ? (100 * daysAboveTarget) / days.length : 0;

  const mean = dailyValues.reduce((s, v) => s + v, 0) / (dailyValues.length || 1);
  const variance = dailyValues.reduce((s, v) => s + (v - mean) ** 2, 0) / (dailyValues.length || 1);
  const std = Math.sqrt(variance);
  const sharpe = std > 0 ? (mean / std) * Math.sqrt(252) : 0;

  let cum = 0, peak = -Infinity, maxDd = 0;
  for (const v of dailyValues) {
    cum += v;
    if (cum > peak) peak = cum;
    maxDd = Math.min(maxDd, cum - peak);
  }

  return {
    totalTrades: trades.length,
    winRate: Math.round((10000 * wins) / trades.length) / 100,
    expectancy: Math.round((1000 * sumR) / trades.length) / 1000,
    profitFactor: sumLossR < 0 ? Math.round((100 * sumWinR) / Math.abs(sumLossR)) / 100 : (sumWinR > 0 ? Infinity : 0),
    winDaysPct: Math.round(winDaysPct * 100) / 100,
    totalDays: days.length,
    daysAboveTarget,
    maxDrawdown: Math.round(maxDd * 100) / 100,
    sharpe: Math.round(sharpe * 100) / 100,
    dailyPnl,
  };
}

/** Simple Pearson correlation coefficient between two equal-length numeric arrays. */
function pearson(x, y) {
  const n = x.length;
  if (n < 3) return null;
  const mx = x.reduce((s, v) => s + v, 0) / n;
  const my = y.reduce((s, v) => s + v, 0) / n;
  let num = 0, dx2 = 0, dy2 = 0;
  for (let i = 0; i < n; i++) {
    const dx = x[i] - mx, dy = y[i] - my;
    num += dx * dy; dx2 += dx * dx; dy2 += dy * dy;
  }
  const denom = Math.sqrt(dx2 * dy2);
  return denom > 0 ? num / denom : null;
}

/**
 * Parameter-Correlation Diagnostic (read-only, periodic report — see spec
 * Section 9). Correlates each numeric component weight active on a trade
 * against that trade's R-multiple outcome. This is descriptive only; any
 * parameter change implied by the result still goes through the tuner's
 * normal minimum-sample and shadow-mode safeguards, never applied automatically.
 */
async function computeParamCorrelationReport(asset, { strategyId = 'default', accountId = 'paper-main' } = {}) {
  const trades = await Trade.find({ asset, strategyId, accountId, 'outcome.status': 'CLOSED' }).lean();
  if (trades.length < 30) {
    return { skipped: true, reason: `only ${trades.length} closed trades, need at least 30 for a meaningful correlation read` };
  }

  const components = ['stage', 'aov', 'pattern', 'ema', 'smc', 'volume'];
  const rValues = trades.map((t) => t.outcome.rMultiple || 0);
  const report = {};

  for (const c of components) {
    const fired = trades.map((t) => (t.entryBasis && t.entryBasis.checks && t.entryBasis.checks[c] && t.entryBasis.checks[c].passed) ? 1 : 0);
    report[c] = { correlationWithR: roundOrNull(pearson(fired, rValues)), sampleSize: trades.length };
  }

  // Also correlate ADX value and net margin (numeric fields) against R-multiple
  const adxValues = trades.map((t) => t.entryBasis?.adx || 0);
  const netMarginValues = trades.map((t) => t.entryBasis?.netMargin || 0);
  report.adx = { correlationWithR: roundOrNull(pearson(adxValues, rValues)), sampleSize: trades.length };
  report.netMargin = { correlationWithR: roundOrNull(pearson(netMarginValues, rValues)), sampleSize: trades.length };

  return { skipped: false, asset, generatedAt: new Date(), report };
}

function roundOrNull(v) {
  return v == null ? null : Math.round(v * 1000) / 1000;
}

module.exports = { computeMetrics, computeParamCorrelationReport };
