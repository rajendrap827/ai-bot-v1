const Trade = require('../models/Trade');
const TuningLog = require('../models/TuningLog');
const { Config } = require('../models/Config');
const { invalidateConfigCache } = require('../config/configLoader');

const MIN_TRADES_TO_TUNE = 30;
const SHRINKAGE_K = 20; // higher = more aggressive pull toward the global average for small samples
const DECAY_STEP = 0.3; // how much a weight moves per cycle (1.0 -> 0.7 -> 0.4 -> 0.0)
const RESTORE_STEP = 0.3;
const RECENCY_HALFLIFE_DAYS = 35;
const COOLDOWN_CYCLES = 2; // a component's weight can't change again within this many cycles
const COMPONENTS = ['stage', 'aov', 'pattern', 'ema', 'smc', 'volume'];

/**
 * Recency weight: more recent trades count more. Exponential decay with a
 * configurable half-life, applied per-trade when computing expectancy.
 */
function recencyWeight(tradeDate, now) {
  const ageDays = (now - tradeDate) / 86400000;
  return Math.pow(0.5, ageDays / RECENCY_HALFLIFE_DAYS);
}

/**
 * Shrinks a small-sample expectancy estimate toward the global average.
 * Classic Bayesian-style shrinkage: weight = n / (n + k).
 */
function shrink(sampleExpectancy, n, globalExpectancy, k = SHRINKAGE_K) {
  const w = n / (n + k);
  return w * sampleExpectancy + (1 - w) * globalExpectancy;
}

/**
 * Recency-weighted average R-multiple for a set of trades.
 */
function weightedExpectancy(trades, now) {
  if (trades.length === 0) return 0;
  let wSum = 0, wTotal = 0;
  for (const t of trades) {
    const w = recencyWeight(t.outcome.exitTime || t.createdAt, now);
    wSum += (t.outcome.rMultiple || 0) * w;
    wTotal += w;
  }
  return wTotal > 0 ? wSum / wTotal : 0;
}

/**
 * Runs one tuning cycle for a given asset. Looks at each of the 6 components,
 * compares trades where it fired vs trades where it didn't, and gradually
 * decays or restores its weight based on shrunk, recency-weighted expectancy.
 * Every decision (including "no_change") is logged for full explainability.
 */
async function runTuningCycle(asset, strategyId = 'default', accountId = 'paper-main') {
  const now = new Date();
  const closedTrades = await Trade.find({ asset, strategyId, accountId, 'outcome.status': 'CLOSED' }).lean();

  if (closedTrades.length < MIN_TRADES_TO_TUNE) {
    return { skipped: true, reason: `only ${closedTrades.length} closed trades, need ${MIN_TRADES_TO_TUNE}` };
  }

  const configDoc = await Config.findOne({ strategyId, accountId });
  if (!configDoc) return { skipped: true, reason: 'no config document found' };

  const globalExpectancy = weightedExpectancy(closedTrades, now);
  const currentWeights = getCurrentWeights(configDoc, asset);
  const decisions = [];

  for (const component of COMPONENTS) {
    const fired = closedTrades.filter((t) => t.entryBasis && t.entryBasis.checks && t.entryBasis.checks[component] && t.entryBasis.checks[component].passed);
    const sampleSize = fired.length;

    if (sampleSize === 0) {
      decisions.push({ component, action: 'no_change', reason: 'no trades fired this component yet' });
      continue;
    }

    const rawExpectancy = weightedExpectancy(fired, now);
    const shrunkExpectancy = shrink(rawExpectancy, sampleSize, globalExpectancy);
    const weightBefore = currentWeights[component] != null ? currentWeights[component] : 1;

    const cooldownBlocked = await isInCooldown(asset, component, strategyId);

    if (sampleSize < MIN_TRADES_TO_TUNE) {
      decisions.push(await recordDecision({
        asset, strategyId, component, sampleSize, rawExpectancy, shrunkExpectancy,
        globalExpectancy, weightBefore, weightAfter: weightBefore,
        action: 'no_change', reason: 'sample size ' + sampleSize + ' below minimum (' + MIN_TRADES_TO_TUNE + ')',
        configVersion: configDoc.meta.version,
      }));
      continue;
    }

    if (cooldownBlocked) {
      decisions.push(await recordDecision({
        asset, strategyId, component, sampleSize, rawExpectancy, shrunkExpectancy,
        globalExpectancy, weightBefore, weightAfter: weightBefore,
        action: 'hold_cooldown', reason: 'weight changed within the last ' + COOLDOWN_CYCLES + ' cycles - holding to avoid flapping',
        configVersion: configDoc.meta.version,
      }));
      continue;
    }

    let weightAfter = weightBefore;
    let action = 'no_change';
    let reason = 'shrunk expectancy (' + shrunkExpectancy.toFixed(3) + 'R) is not meaningfully different from global (' + globalExpectancy.toFixed(3) + 'R)';

    if (shrunkExpectancy < globalExpectancy - 0.1 && weightBefore > 0) {
      weightAfter = Math.max(0, Math.round((weightBefore - DECAY_STEP) * 100) / 100);
      action = 'decay';
      reason = 'shrunk expectancy (' + shrunkExpectancy.toFixed(3) + 'R) underperforms global average (' + globalExpectancy.toFixed(3) + 'R) on ' + sampleSize + ' trades - reducing trust gradually';
    } else if (shrunkExpectancy > globalExpectancy + 0.1 && weightBefore < 1) {
      weightAfter = Math.min(1, Math.round((weightBefore + RESTORE_STEP) * 100) / 100);
      action = 'restore';
      reason = 'shrunk expectancy (' + shrunkExpectancy.toFixed(3) + 'R) outperforms global average (' + globalExpectancy.toFixed(3) + 'R) on ' + sampleSize + ' trades - restoring trust gradually';
    }

    decisions.push(await recordDecision({
      asset, strategyId, component, sampleSize, rawExpectancy, shrunkExpectancy,
      globalExpectancy, weightBefore, weightAfter, action, reason,
      configVersion: configDoc.meta.version,
    }));

    if (action !== 'no_change') {
      await applyWeightChange(configDoc, asset, component, weightAfter);
    }
  }

  return { skipped: false, decisions, totalClosedTrades: closedTrades.length, globalExpectancy };
}

function getCurrentWeights(configDoc, asset) {
  const perAssetEntry = configDoc.perAsset && configDoc.perAsset.get ? configDoc.perAsset.get(asset) : null;
  const override = perAssetEntry ? perAssetEntry.weights : null;
  const g = configDoc.global.weights || {};
  return Object.assign({}, g, override || {});
}

async function isInCooldown(asset, component, strategyId) {
  const recentChange = await TuningLog.findOne({
    asset: asset, component: component, strategyId: strategyId,
    action: { $in: ['decay', 'restore'] },
  }).sort({ ts: -1 }).lean();
  if (!recentChange) return false;

  const cyclesSince = await TuningLog.countDocuments({
    asset: asset, component: component, strategyId: strategyId,
    ts: { $gt: recentChange.ts },
  });
  return cyclesSince < COOLDOWN_CYCLES;
}

async function recordDecision(fields) {
  const log = await TuningLog.create({
    asset: fields.asset,
    strategyId: fields.strategyId,
    component: fields.component,
    sampleSize: fields.sampleSize,
    expectancyWithBefore: round3(fields.rawExpectancy),
    expectancyShrunk: round3(fields.shrunkExpectancy),
    globalExpectancy: round3(fields.globalExpectancy),
    weightBefore: fields.weightBefore,
    weightAfter: fields.weightAfter,
    action: fields.action,
    reason: fields.reason,
    configVersionBefore: fields.configVersion,
    configVersionAfter: (fields.action === 'no_change' || fields.action === 'hold_cooldown')
      ? fields.configVersion
      : fields.configVersion + 1,
  });
  return log.toObject();
}

async function applyWeightChange(configDoc, asset, component, newWeight) {
  if (!configDoc.perAsset) configDoc.perAsset = new Map();
  const existing = configDoc.perAsset.get(asset) || {};
  const baseWeights = existing.weights || configDoc.global.weights || {};
  const weights = Object.assign({}, baseWeights, { [component]: newWeight });
  configDoc.perAsset.set(asset, Object.assign({}, existing, { weights: weights }));
  configDoc.meta.version += 1;
  configDoc.meta.updatedAt = new Date();
  configDoc.meta.updatedBy = 'auto-tuner';
  await configDoc.save();
  invalidateConfigCache(asset, configDoc.strategyId, configDoc.accountId);
}

function round3(n) {
  return Math.round((n || 0) * 1000) / 1000;
}

module.exports = { runTuningCycle, MIN_TRADES_TO_TUNE };
