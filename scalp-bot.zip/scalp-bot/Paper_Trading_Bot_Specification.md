# Paper Trading Bot — Project Specification

**Prepared for:** Raj (Creo Webtech Solutions)
**Purpose:** A 6-month paper-trading scalping system for BTC, ETH, and Gold (XAUUSD) that logs every trade with full reasoning, analyzes its own performance, and adjusts its own parameters over time based on statistical evidence.

---

## 1. Project Goal

Build a bot that:

1. Analyzes the market using a defined, rule-based strategy (no guessing, no black-box AI).
2. Executes trades on a simulated ("paper") account — no real money at risk.
3. Logs every trade along with the exact reasoning behind it.
4. Periodically reviews its own trade history and adjusts which signals it trusts more or less, based on statistical evidence (not personal opinion).
5. Factors in scheduled high-impact news events.
6. Is fully configurable, so any number (risk %, balance, thresholds) can be changed without touching code.

**Important honest note:** This system does not "think" or "learn" the way a human or a large AI model does. It is a statistics-driven feedback loop — it tracks which conditions have historically worked and adjusts trust in those conditions accordingly. This is a proven, realistic approach. It is not the same as a self-aware trading AI, and no system can guarantee future profitability based on past data.

---

## 2. Scope

- **Assets:** BTC, ETH, GOLD (XAUUSD)
- **Style:** Scalping only
- **Account type:** Paper (simulated) trading only — Phase 1
- **Duration:** 6-month continuous run, with the final 1–2 months reserved as untouched validation data (to check whether tuning decisions actually hold up on unseen data, not just the data they were tuned on)

---

## 3. Technology Stack

| Component | Choice | Reason |
|---|---|---|
| Backend | Node.js | Main service: signal engine, paper trading engine, scheduler, API |
| Database | MongoDB (single-node replica set) | Flexible document storage for rich, nested trade logic; replica set enables real-time Change Streams |
| Gold data bridge | Python (MetaTrader5 official library) | MT5 has no native Node.js library; a small Python service reads ticks from MT5 and writes to MongoDB |
| Gold platform | MetaTrader 5 via Exness **demo account**, run under Wine + Xvfb | Exness does not offer a public trading API; MT5 is the only supported automation path. Demo account removes financial risk since this bridge is used for price data only, not real order execution |
| Crypto data | Binance public WebSocket (BTC, ETH) | Free, real-time, no API key required |
| Dashboard | React (view-only for now) | Live positions, trade history, equity curve, tuning log |
| Real-time push to dashboard | Socket.io | Pushes live updates from MongoDB Change Streams to the React frontend |
| Server | Hetzner Cloud, CX33 (4 vCPU / 8 GB RAM / 80 GB NVMe SSD), Ubuntu 24.04 LTS | Lowest cost for the required specs (~€6.49/month); 8 GB headroom needed mainly because Wine + MT5 + Xvfb is the heaviest component |
| News data | Finnhub (economic calendar) — Phase 1; sentiment scoring — Phase 2 | Free tier covers high-impact scheduled events (CPI, Fed, NFP, etc.) |

---

## 4. Strategy Logic

The strategy is a Python/Node port of the existing Pine Script "CRYPTO GOLD PRO v2" indicator, built around Rayner Teo's price-action rules, combined with SMC/ICT concepts. It is **not** a new theory — it is the same logic already tested on the indicator, now made fully automatic.

### 4.1 Market Stage (Rayner Teo, via 200 EMA)
Every candle is classified into one of: Advancing, Accumulation, Distribution, Declining.

### 4.2 Six Scoring Components (per signal, weighted)
1. **Stage** — is the market stage favorable for the trade direction?
2. **Area of Value (AOV)** — is price near support/resistance, EMA200, EMA21, or VWAP? (VWAP resets daily at 00:00 UTC for all three assets, since Gold and crypto trade 24 hours and have no natural session-open reset point. VWAP is folded into this single component rather than added as a separate 7th component, since it overlaps conceptually with both "value zone" and volume — keeping it separate would let one real setup get double-counted across two components and would distort the self-tuning logic later.)
3. **Pattern** — hammer, engulfing, pin bar, shooting star
4. **EMA alignment** — fast EMA vs slow EMA
5. **SMC** — Break of Structure (BOS), Change of Character (CHoCH), liquidity sweep
6. **Volume** — volume delta direction and surge (only used when volume data is reliable; Gold feeds often lack this, and the system detects and accounts for that)

A trade requires a minimum total score, a minimum margin over the opposing score, and (optionally) a confirmation candle and an Area-of-Value match. All thresholds are configurable.

### 4.3 Additional Filters
- **Session filter** — Dubai-time session windows (Asian / London / Overlap / NY / NY Close), tuned per asset (Gold favors London + Overlap; crypto favors Overlap + NY)
- **ADX filter** — avoids low-trend/choppy conditions
- **Higher-timeframe (HTF) trend filter** — only takes trades aligned with the 1H trend (configurable timeframe)
- **Cooldown** — minimum number of bars between signals, to avoid overtrading
- **News blackout** — no new entries within a configurable window of a high-impact scheduled event

### 4.4 Anti-Repaint Rule
All signals are generated only on a **confirmed, closed candle** — never on the still-forming live candle. This is a deliberate fix versus most retail indicators, which often "repaint" (show a signal live that disappears once the candle closes).

---

## 5. Exit Strategy — Hybrid

- Stop-loss: 1 ATR beyond the relevant support/resistance/EMA zone (Rayner rule)
- 50% of the position closes at TP1 (profit lock)
- The remaining 50% is held with the original fixed stop-loss **until price reaches 1R profit**
- Once 1R is reached, the stop-loss begins trailing behind price using an ATR-based distance (similar to a "chandelier exit")
- TP2 is shown as a soft reference target on the dashboard, but the actual exit for the trailing portion is determined by the trailing stop, not a hard target

This requires continuous (tick-level) price monitoring, not just candle-close checks — which is why real-time data feeds (WebSocket for crypto, MT5 tick stream for Gold) are required rather than periodic polling.

---

## 6. Risk Management & Configuration

Nothing related to money management or strategy thresholds is hard-coded. All of the following are stored in a MongoDB `config` collection and can be changed at runtime without a server restart:

- Paper account balance (starting value: $10,000)
- Risk per trade (starting value: 1%, can be set per asset)
- Maximum open positions per asset
- Minimum signal score, score margin, cooldown bars
- Stop-loss ATR multiplier, RR ratio (used for TP1/TP2 reference)
- Session filter, Area-of-Value requirement, confirmation-candle requirement on/off
- Area-of-Value distance thresholds (ATR multiples), including the VWAP proximity threshold
- Exit mode (fixed / pure-trail / hybrid) — currently set to hybrid, can vary per asset

Each configuration set is versioned. Every trade stores which configuration version was active when it was taken, so results can always be traced back to the exact rules that produced them. If the balance is manually adjusted, the change is logged and historical equity data remains untouched — future calculations simply continue from the new balance.

---

## 7. Trade Logging (Maximum Detail)

Every trade is stored as a single MongoDB document containing four sections:

1. **Entry Basis** — market stage, session, HTF trend, ADX value, all six component checks (pass/fail, weight, supporting value), score totals, confirmation candle status, and current scheduled news events nearby (event name, time, impact level, minutes from entry, blackout status)
2. **Prediction** — a "setup fingerprint" (which combination of components fired) and the historical win rate for that exact fingerprint, used to track whether the bot's own confidence estimate is reliable
3. **Execution** — entry time/price, stop-loss, TP1/TP2, position size, risk amount
4. **Outcome** — exit time/price/reason (SL, TP1, TP2, trailing stop), profit/loss in USD and percentage, R-multiple, bars held, whether a news event occurred during the trade, and whether the original prediction direction was correct

This gives a complete record: what the bot saw, what it predicted, what it did, and what actually happened — for every single trade.

---

## 8. Self-Tuning Logic

The bot does not use machine learning. It uses a transparent, rule-based statistical tuner, run periodically (e.g. weekly or monthly):

- **Expectancy-based, not win-rate-based** — components are judged on average R-multiple (since the strategy's risk:reward is asymmetric), not raw win percentage
- **Small-sample shrinkage** — a component that only fired a handful of times is not trusted as strongly as one with a large sample size, even if its raw results look good or bad
- **Per-asset granularity** — a component's usefulness is judged separately for BTC, ETH, and Gold, since what works on one may not work on another
- **Gradual weight decay** — a component's influence is reduced gradually over several tuning cycles rather than switched off instantly after one bad period
- **Recency weighting** — more recent trades carry more influence than older ones, since market conditions (regimes) shift over time
- **Tuning cooldown** — a component's weight cannot flip on/off repeatedly within a short window, to avoid chasing noise
- **Full explainability log** — every tuning decision (which component, sample size, expectancy before/after, action taken) is logged in a separate `tuningLog` collection, so every adjustment the bot makes to itself is fully visible and auditable

A minimum of 30 trades per condition is required before any tuning decision is made on it, to avoid drawing conclusions from too small a sample.

**Reserved for Phase 2 (after a few months of live data):** a "shadow mode" where a new tuned configuration runs in parallel with the current one for a trial period, and is only promoted to production if it proves better on new, unseen trades — not just on the historical data it was tuned from.

---

## 9. Performance Metrics & Diagnostics

In addition to the core tuning metrics in Section 8 (expectancy, R-multiple), two reporting-level metrics are tracked. These are diagnostic and explanatory — they do not feed into the live self-tuning loop directly, to avoid the overfitting risk described in Section 8.

- **Win Days %** — the percentage of trading days where total PnL reached a configurable daily target (e.g. a simple, easy-to-read consistency indicator, shown on the dashboard alongside the more technical expectancy-based metrics). A high Win Days % combined with low expectancy can reveal a strategy that wins often but barely, which is a useful sanity check expectancy alone does not always surface.
- **Parameter-Correlation Diagnostic** — a periodic (e.g. monthly) offline report showing the statistical correlation between each tunable parameter (score thresholds, ATR multipliers, session settings, etc.) and each outcome metric (expectancy, win rate, drawdown). This identifies which parameters are actually moving outcomes versus which ones show no real relationship. It is read-only output for the user to review — it does not automatically change any configuration. Any parameter change suggested by this report still goes through the same minimum-sample and shadow-mode safeguards as the rest of the self-tuning system.

---

## 10. News & Events

- **Phase 1:** Finnhub's economic calendar is checked for scheduled high-impact events (CPI, Fed announcements, NFP, etc.). Each trade logs nearby events, and a configurable blackout window can block new entries around these events.
- **Phase 2:** Live news sentiment scoring will be added once the calendar-based system is stable.

---

## 11. Scalability Considerations

The following decisions were made specifically so the system can grow later without requiring a redesign:

- MongoDB runs as a replica set from day one (required for Change Streams; also the foundation for future scaling)
- Raw price ticks are **not** written to the database — only trade open/close events. Tick-level data is handled in memory per asset, preventing a write-volume bottleneck as the system grows
- Each asset (BTC, ETH, GOLD) runs as an isolated worker process, so adding a new asset later does not require touching existing code
- The `config` schema already includes `strategyId` and `accountId` fields, even though only one strategy/account is in use now — this avoids a schema migration if multiple strategies or accounts (e.g. demo + live in parallel) are tested later
- Business logic communicates through an internal event interface rather than directly coupling to MongoDB Change Streams, so the underlying message system (e.g. moving to Redis or Kafka later) could be swapped without rewriting strategy code
- Historical candle data uses MongoDB's native time-series collection type for efficient storage and querying

---

## 12. Server Requirements

- **Provider:** Hetzner Cloud
- **Plan:** CX33 — 4 vCPU, 8 GB RAM, 80 GB NVMe SSD
- **OS:** Ubuntu 24.04 LTS
- **Approximate cost:** €6.49/month (~$7–8/month) at current Hetzner pricing, plus an optional backup add-on (~20% extra)
- **Why this spec:** The heaviest component is the Wine + Xvfb + MT5 terminal needed for the Gold data feed (roughly 1.5–2.5 GB RAM on its own). Node.js, MongoDB, and the Python bridge are lightweight at this trade volume (a few thousand trades over 6 months, no raw tick storage)

---

## 13. Dashboard (React)

View-only for Phase 1:

- Live open positions (current price, floating R, current trailing stop level)
- Trade history with filters (asset, session, market stage, score, exit reason)
- Equity curve chart
- Win Days % — percentage of trading days where PnL reached a configurable daily target (e.g. a simple, intuitive consistency number alongside the more technical expectancy metrics)
- Tuning log viewer (what changed, when, and why)

Configuration editing through the dashboard is deferred to Phase 2; for now, configuration changes are made directly via a script or MongoDB.

---

## 14. Required Inputs (to be provided when ready)

- Exness MT5 demo account credentials (account number, password, server name) — stored only in environment variables/secrets, never hard-coded
- Finnhub API key (free tier)
- SSH access to the provisioned Hetzner server

---

## 15. Phased Roadmap

**Phase 1 (current scope):**
Paper trading across BTC/ETH/Gold, full trade logging, rule-based self-tuning, calendar-based news awareness, view-only dashboard, 6-month run with the final 1–2 months held out for validation.

**Phase 2 (after Phase 1 data is reviewed):**
News sentiment scoring, shadow-mode tuning validation (champion vs. challenger configs), configuration editing from the dashboard, and — only if Phase 1 results are genuinely profitable on the held-out validation period — consideration of live trading with real capital.

---

## 16. Key Risks & Honest Limitations

- This is a statistical feedback system, not a self-aware AI. It identifies which historical conditions correlated with better outcomes and adjusts trust accordingly — it does not "understand" the market.
- Past performance on paper, even over 6 months, does not guarantee future or live results. Market regimes change, and paper fills do not account for slippage, latency, or real execution risk.
- The MT5/Wine/Xvfb bridge for Gold is the least stable part of the stack and will need a supervised, auto-restarting process (e.g. systemd) to maintain uptime.
- No part of this system, now or in Phase 2, removes the need for the user's own judgment before risking real capital.
