/**
 * Adds MFE / MAE (maximum favourable / adverse excursion) logging.
 *
 * LOGGING ONLY. Entries, stops, targets and trailing are untouched. Each open
 * trade simply records the best and worst R it reached, so we can later answer:
 * "how many trades that hit the stop had been +1R in profit first?" — the
 * evidence needed before ever changing targets.
 *
 * Usage:  node patch_mfe.js [path-to-backend]
 * Default path: /root/ai-bot-v1/scalp-bot/backend
 */
const fs = require('fs');
const path = require('path');

const backend = process.argv[2] || '/root/ai-bot-v1/scalp-bot/backend';
const tradeFile = path.join(backend, 'src/models/Trade.js');
const engineFile = path.join(backend, 'src/engine/paperEngine.js');

function patch(file, anchor, insertion, marker) {
  let s = fs.readFileSync(file, 'utf8');
  if (s.includes(marker)) {
    console.log(`SKIP ${path.basename(file)} — already patched`);
    return;
  }
  const count = s.split(anchor).length - 1;
  if (count !== 1) {
    console.error(`FAIL ${path.basename(file)} — anchor found ${count} times (need exactly 1). Nothing changed.`);
    process.exit(1);
  }
  fs.writeFileSync(file + '.bak-mfe', s);
  s = s.replace(anchor, anchor + insertion);
  fs.writeFileSync(file, s);
  console.log(`OK   ${path.basename(file)} (backup: ${path.basename(file)}.bak-mfe)`);
}

// 1) Schema: add the two fields to outcome. Default 0 so Mongo's $min/$max
//    behave correctly from the first tick (entry is 0R by definition).
patch(
  tradeFile,
  '    currentTrailStop: { type: Number, default: null },',
  '\n    mfeR: { type: Number, default: 0 }, // best R reached while open (logging only)' +
  '\n    maeR: { type: Number, default: 0 }, // worst R reached while open (logging only)',
  'mfeR:'
);

// 2) Engine: record excursions on each tick. Uses an atomic $max/$min update
//    rather than trade.save(), so it can never overwrite exit fields written
//    concurrently by the reconciler. Writes only when the extreme moves by
//    0.05R, which keeps DB traffic small.
patch(
  engineFile,
  '    const positionId = trade.broker && trade.broker.positionId;',
  '\n\n' +
  '    // Excursion logging (does not affect exits). Tick-based, so a spike\n' +
  '    // between ticks can be missed — treat values as close approximations.\n' +
  '    const mfePrev = trade.outcome.mfeR == null ? 0 : trade.outcome.mfeR;\n' +
  '    const maePrev = trade.outcome.maeR == null ? 0 : trade.outcome.maeR;\n' +
  '    if (rNow > mfePrev + 0.05 || rNow < maePrev - 0.05) {\n' +
  '      const rr = Math.round(rNow * 100) / 100;\n' +
  "      await Trade.updateOne({ _id: trade._id }, { $max: { 'outcome.mfeR': rr }, $min: { 'outcome.maeR': rr } });\n" +
  '    }',
  'outcome.mfeR'
);

console.log('Done. Restart with: systemctl restart scalpbot');
