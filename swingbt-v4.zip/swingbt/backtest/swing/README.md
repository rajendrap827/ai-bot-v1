# Swing MTF Zones backtester (sw5 / sw15 / sw30 / sw1h)

JS port of the Pine indicator "Swing MTF Zones v4" (rules frozen 2026-10-08, v4 stop/target fix 2026-10-09).
READ-ONLY: never touches the bot, its database or its MetaApi streaming connection.

| strategy | entry TF | bias TF |
|---|---|---|
| sw5  | 5m  | 15m |
| sw15 | 15m | 1h  |
| sw30 | 30m | 4h  |
| sw1h | 1h  | 1d  |

## Install (from ~/ai-bot-v1)

    git pull && unzip -o swingbt.zip && cp -r swingbt/backtest/swing scalp-bot/backend/backtest/

## 1. Download history (once; re-run continues / tops up)

    cd ~/ai-bot-v1/scalp-bot/backend
    nohup node backtest/swing/fetch_tf.js --tf=1h,30m,15m,5m > /root/fetch_swing.log 2>&1 &
    tail -5 /root/fetch_swing.log

1h finishes in a few minutes, 5m takes the longest. Files: backtest/data/swing/<ASSET>_<tf>.json

## 2. Diagnostics first (counts and stop/target sizes only, NO win/loss shown)

    node backtest/swing/run.js --strategy=all --diag

## 3. Full result (only after max stop / min T1 are frozen)

    node backtest/swing/run.js --strategy=sw1h --log

Costs: spread charged once per trade (GOLD 0.25, BTC 8, ETH 1.2 price units) and long swap per
night (GOLD 0.5222, BTC 18.336, ETH 0.565; Gold triple Wednesday, crypto triple Friday; shorts 0).
Override with --spread=... / --swap=... . `--set=key:value` overrides frozen rules and prints a WARNING.

Pass bar (agreed before results): net >= +0.10R per trade, every asset positive, most years
positive, 2020-2023 (unseen) positive, >= 30 trades per asset.

`--log` writes every trade with its events (T1, T2, SL moves, exit reason), zone, bias values and the
trend state of every higher timeframe to backtest/data/swing/trades_<strategy>.jsonl
