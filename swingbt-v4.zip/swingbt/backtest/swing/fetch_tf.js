#!/usr/bin/env node
/**
 * Downloads long candle history from MetaApi (same Exness feed as the bot) for the
 * swing strategies into backtest/data/swing/<ASSET>_<tf>.json
 * Format: [[timeMs, open, high, low, close, tickVolume], ...] sorted by time.
 *
 * READ-ONLY: does not touch the bot, its database or its connection.
 * Re-running only downloads what is missing (newer bars, and older bars back to --from).
 *
 * Usage (from ~/ai-bot-v1/scalp-bot/backend):
 *   node backtest/swing/fetch_tf.js --tf=1h
 *   node backtest/swing/fetch_tf.js --tf=30m,15m,5m --from=2020-01-01 --assets=GOLD,BTC,ETH
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..', '..');
const OUT_DIR = path.join(__dirname, '..', 'data', 'swing');
const TF_MS = { '5m': 300000, '15m': 900000, '30m': 1800000, '1h': 3600000 };

function loadEnv() {
  const p = path.join(ROOT, '.env');
  const env = {};
  if (fs.existsSync(p)) {
    for (const line of fs.readFileSync(p, 'utf8').split('\n')) {
      const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
      if (m) env[m[1]] = m[2].replace(/^['"]|['"]$/g, '');
    }
  }
  return env;
}

function parseArgs(argv) {
  const a = {};
  for (const s of argv) {
    const m = s.match(/^--([^=]+)(?:=(.*))?$/);
    if (m) a[m[1]] = m[2] === undefined ? true : m[2];
  }
  return a;
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function withRetry(fn, tries = 5) {
  let last;
  for (let k = 0; k < tries; k++) {
    try { return await fn(); } catch (err) { last = err; await sleep(3000 * (k + 1)); }
  }
  throw last;
}

// Pull candles backwards from `startMs` (null = now) until `stopMs` or the broker has no more.
async function pullBack(account, symbol, tf, startMs, stopMs, byT, tag) {
  let start = startMs ? new Date(startMs) : undefined;
  let calls = 0;
  for (;;) {
    const batch = await withRetry(() => account.getHistoricalCandles(symbol, tf, start, 1000));
    calls++;
    if (!batch || !batch.length) { console.log(`${tag} broker has no older data`); return 'end'; }
    let minT = Infinity;
    for (const x of batch) {
      const t = new Date(x.time).getTime();
      if (t < minT) minT = t;
      byT.set(t, [t, x.open, x.high, x.low, x.close, x.tickVolume || 0]);
    }
    if (calls % 10 === 0) console.log(`${tag} back to ${new Date(minT).toISOString().slice(0, 10)}  bars ${byT.size}`);
    if (minT <= stopMs) return 'reached';
    const next = minT - 1000;
    if (start && next >= start.getTime()) { console.log(`${tag} broker returned no older data`); return 'end'; }
    start = new Date(next);
    await sleep(250);
  }
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const env = loadEnv();
  const tfs = String(args.tf || '1h').split(',').map((s) => s.trim());
  for (const tf of tfs) if (!TF_MS[tf]) { console.error(`unknown --tf=${tf} (use 5m,15m,30m,1h)`); process.exit(1); }
  const assets = args.assets ? String(args.assets).toUpperCase().split(',') : ['GOLD', 'BTC', 'ETH'];
  const fromMs = new Date((args.from || '2020-01-01') + 'T00:00:00Z').getTime();
  const symbols = { BTC: env.SYMBOL_BTC || 'BTCUSDm', ETH: env.SYMBOL_ETH || 'ETHUSDm', GOLD: env.SYMBOL_GOLD || 'XAUUSDm' };
  if (!env.METAAPI_TOKEN || !env.METAAPI_ACCOUNT_ID) {
    console.error('METAAPI_TOKEN / METAAPI_ACCOUNT_ID missing in .env');
    process.exit(1);
  }
  fs.mkdirSync(OUT_DIR, { recursive: true });

  const MetaApi = require('metaapi.cloud-sdk').default;
  const api = new MetaApi(env.METAAPI_TOKEN);
  const account = await api.metatraderAccountApi.getAccount(env.METAAPI_ACCOUNT_ID);

  for (const tf of tfs) {
    for (const asset of assets) {
      const tag = `[${asset} ${tf}]`;
      const file = path.join(OUT_DIR, `${asset}_${tf}.json`);
      const byT = new Map();
      let oldMin = null, oldMax = null;
      if (fs.existsSync(file)) {
        for (const r of JSON.parse(fs.readFileSync(file, 'utf8'))) {
          byT.set(r[0], r);
          if (oldMin === null || r[0] < oldMin) oldMin = r[0];
          if (oldMax === null || r[0] > oldMax) oldMax = r[0];
        }
      }
      console.log(`\n${tag} ${symbols[asset]}  saved: ${byT.size} bars${oldMin ? ` ${new Date(oldMin).toISOString().slice(0, 10)} -> ${new Date(oldMax).toISOString().slice(0, 10)}` : ''}`);
      try {
        if (oldMax == null) {
          // first download: newest -> --from. A partial result is contiguous, the next run continues below it.
          await pullBack(account, symbols[asset], tf, null, fromMs, byT, tag);
        } else {
          // 1) newest bars down to what we already have. Kept only if this step completes,
          //    otherwise a later run could leave a hole between old and new data.
          const fresh = new Map();
          try {
            await pullBack(account, symbols[asset], tf, null, oldMax, fresh, tag);
            for (const [k, v] of fresh) byT.set(k, v);
          } catch (err) {
            console.error(`${tag} newest bars not added (${err.message}) - re-run later`);
          }
          // 2) older bars below what we had, down to --from (contiguous, safe to keep partially)
          if (oldMin > fromMs + TF_MS[tf]) await pullBack(account, symbols[asset], tf, oldMin - 1000, fromMs, byT, tag);
        }
      } catch (err) {
        console.error(`${tag} stopped: ${err.message} (partial data kept, re-run to continue)`);
      }
      const nowMs = Date.now();
      // drop the bar that is still forming
      const rows = [...byT.values()].filter((r) => r[0] >= fromMs && r[0] + TF_MS[tf] <= nowMs).sort((a, b) => a[0] - b[0]);
      fs.writeFileSync(file, JSON.stringify(rows));
      const f = rows.length ? new Date(rows[0][0]).toISOString().slice(0, 10) : '-';
      const l = rows.length ? new Date(rows[rows.length - 1][0]).toISOString().slice(0, 10) : '-';
      console.log(`${tag} saved ${rows.length} bars  ${f} -> ${l}`);
    }
  }
  process.exit(0);
}

main().catch((err) => {
  console.error('fetch failed:', err.message);
  process.exit(1);
});
