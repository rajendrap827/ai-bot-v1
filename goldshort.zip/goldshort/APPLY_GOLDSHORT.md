# Gold-SHORT forward test (gstpb, gssmc, gsorb)

Rules frozen 2026-10-07: tpb, smc and orb exactly as backtested, GOLD only, SHORT only.
default, babalu and mmt are unchanged.

Install (from ~/ai-bot-v1):
  git pull && unzip -o goldshort.zip && cp -r goldshort/src/strategy/goldshort scalp-bot/backend/src/strategy/ && node goldshort/patch_goldshort.js && systemctl restart scalpbot

Verify:
  sleep 30 && journalctl -u scalpbot -n 80 --no-pager | grep -E "gstpb|gssmc|gsorb|started"
Expect: GOLD/gstpb seeded with 6000, GOLD/gssmc 2400, GOLD/gsorb 400,
BTC/ETH lines "not used ... skipped", and the ids in "strategies: ...".

Start date for analysis = this restart. Review after 3 months, net of spread:
pass = combined avg >= +0.10R and positive in at least 2 of the 3 months.
