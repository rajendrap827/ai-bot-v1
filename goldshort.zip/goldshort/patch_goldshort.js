/**
 * Adds the frozen Gold-SHORT forward test (gstpb, gssmc, gsorb) to the live bot.
 *
 * Rules frozen 2026-10-07 (tpb, smc, orb exactly as backtested), restricted to
 * GOLD and SHORT only. Results count from the restart after this patch.
 *
 *   registry.js        3 entries + 2 requires
 *   strategyWorker.js  - a strategy may declare `assets`; other assets are skipped
 *                      - a strategy may declare `window` (5m bars); it then gets that
 *                        much history from the DB and a buffer that large
 *                      Strategies without these fields behave exactly as before.
 *
 * Idempotent, writes .bak-goldshort backups, refuses if any anchor is missing.
 * Usage: node patch_goldshort.js [path-to-backend]
 */
const fs = require('fs');
const path = require('path');

const backend = process.argv[2] || '/root/ai-bot-v1/scalp-bot/backend';
const regFile = path.join(backend, 'src/strategy/registry.js');
const wrkFile = path.join(backend, 'src/workers/strategyWorker.js');

function count(s, a) { return s.split(a).length - 1; }

function patchFile(file, marker, edits) {
  let s = fs.readFileSync(file, 'utf8');
  if (s.includes(marker)) { console.log(`SKIP ${path.basename(file)} - already patched`); return; }
  for (const [a] of edits) {
    if (count(s, a) !== 1) {
      console.error(`FAIL ${path.basename(file)} - anchor found ${count(s, a)} times, need 1:\n  ${a.split('\n')[0]}\nNothing changed.`);
      process.exit(1);
    }
  }
  fs.writeFileSync(file + '.bak-goldshort', s);
  for (const [a, b] of edits) s = s.replace(a, b);
  fs.writeFileSync(file, s);
  console.log(`OK   ${path.basename(file)} (backup: ${path.basename(file)}.bak-goldshort)`);
}

// ── registry.js ──
const reqAnchor = "const { computeBabaluSignal } = require('./babaluScoring');";
const endAnchor = '\n};\n\nfunction getStrategy';
const regEntries = `

  // ── Gold-SHORT forward test, rules frozen 2026-10-07 ──
  gstpb: goldShort('gstpb', 'Gold SHORT: 1H Trend Pullback', gsTpb),
  gssmc: goldShort('gssmc', 'Gold SHORT: SMC sweep+BOS+OB', gsSmc),
  gsorb: goldShort('gsorb', 'Gold SHORT: US Open Range', gsOrb),`;
const regHelpers = `
const gsTpb = require('./goldshort/tpb');
const gsSmc = require('./goldshort/smc');
const gsOrb = require('./goldshort/orb');
const { getSession: gsSession } = require('./stage');

// Wraps a frozen strategy so it only ever trades GOLD, and only SHORT.
function goldShort(id, name, mod) {
  return {
    id,
    name,
    usesHtf: false,
    assets: ['GOLD'],
    window: mod.window,
    compute: (candles, cfg, asset) => {
      if (asset !== 'GOLD') return { signal: null, reason: 'gold_only' };
      const s = mod.compute(candles, cfg);
      if (!s || s.signal !== 'SHORT') return { signal: null, reason: s && s.signal ? 'long_ignored' : (s && s.reason) || 'no_setup' };
      s.session = gsSession(new Date(s.time)).name;
      return s;
    },
    defaults: { cooldownBars: 0, useSessionFilter: false },
  };
}`;

patchFile(regFile, 'gstpb:', [
  [reqAnchor, reqAnchor + regHelpers],
  [endAnchor, regEntries + endAnchor],
]);

// ── strategyWorker.js ──
const wTag = "  const tag = `${asset}/${strategyId}`;";
const wSeed = '  if (!Array.isArray(buffer)) buffer = [];';
const wSlice = '    if (buffer.length > MAX_BUFFER) buffer = buffer.slice(buffer.length - MAX_BUFFER);';

patchFile(wrkFile, 'strategy.assets', [
  [wTag, wTag + `
  // Strategy limited to some assets (e.g. Gold-only): don't run it elsewhere.
  if (Array.isArray(strategy.assets) && !strategy.assets.includes(asset)) {
    console.log(\`[\${tag}] not used for \${asset} - skipped\`);
    return null;
  }
  // Strategies that need long history (e.g. 1H EMA200) declare a window in 5m bars.
  const maxBuf = Math.max(MAX_BUFFER, strategy.window || 0);`],
  [wSeed, wSeed + `
  if (strategy.window && buffer.length < strategy.window) {
    try {
      const docs = await Candle.find({ asset, timeframe: '5m' }).sort({ t: -1 }).limit(strategy.window).lean();
      const byT = new Map();
      for (const d of docs) byT.set(new Date(d.t).getTime(), { t: d.t, o: d.o, h: d.h, l: d.l, c: d.c, v: d.v });
      // keep feed-seeded bars only if already closed (a forming bar must not enter the buffer)
      for (const b of buffer) {
        const tt = new Date(b.t).getTime();
        if (tt + 5 * 60000 <= Date.now()) byT.set(tt, b);
      }
      buffer = [...byT.entries()].sort((x, y) => x[0] - y[0]).map(([, v]) => v).slice(-maxBuf);
    } catch (err) {
      console.error(\`[\${tag}] extended seed failed: \${err.message}\`);
    }
  }`],
  [wSlice, '    if (buffer.length > maxBuf) buffer = buffer.slice(buffer.length - maxBuf);'],
]);

console.log('Done. Restart: systemctl restart scalpbot');
