/**
 * Fix: broker lots were never saved (trade.broker.lots = null on every trade), so the TP1 50% partial
 * close was never sent to the broker - the broker kept the full position while the paper engine booked
 * half. Cause: placeOrder() returned MetaApi's order result, which has no `volume` field.
 *
 *  1. brokerExecution.js: placeOrder returns the result plus the lots it sent (volume)
 *  2. MongoDB: OPEN trades with a broker position and lots null get the real volume from the broker
 *
 * Idempotent, backup brokerExecution.js.bak-lots. Restart scalpbot afterwards (best with no open trades).
 * Usage (from ~/ai-bot-v1): node lotsfix/patch_lots.js
 */
const fs = require('fs');
const path = require('path');

const backend = process.argv[2] || '/root/ai-bot-v1/scalp-bot/backend';
const file = path.join(backend, 'src/execution/brokerExecution.js');
let s = fs.readFileSync(file, 'utf8');
const anchor = "placed — positionId ${result.positionId}`);\n    return result;";
if (s.includes('volume: lots }')) console.log('SKIP brokerExecution.js - already patched');
else if (s.split(anchor).length - 1 !== 1) { console.error('FAIL brokerExecution.js - anchor not found exactly once. Nothing changed.'); process.exit(1); }
else {
  fs.writeFileSync(file + '.bak-lots', s);
  s = s.replace(anchor, "placed — positionId ${result.positionId}`);\n    return { ...result, volume: lots };");
  fs.writeFileSync(file, s);
  console.log('OK   brokerExecution.js (backup: brokerExecution.js.bak-lots)');
}

// ── fill lots for OPEN trades from the broker ──
function loadEnv() {
  const e = {};
  for (const l of fs.readFileSync(path.join(backend, '.env'), 'utf8').split('\n')) {
    const m = l.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (m) e[m[1]] = m[2].replace(/^['"]|['"]$/g, '');
  }
  return e;
}
(async () => {
  const env = loadEnv();
  const mongoose = require(path.join(backend, 'node_modules', 'mongoose'));
  await mongoose.connect(env.MONGO_URI);
  const col = mongoose.connection.db.collection('trades');
  const open = await col.find({ 'outcome.status': 'OPEN', 'broker.positionId': { $exists: true }, 'broker.lots': null }).toArray();
  if (!open.length) { console.log('no OPEN trades with missing lots'); process.exit(0); }
  const MetaApi = require(path.join(backend, 'node_modules', 'metaapi.cloud-sdk')).default;
  const account = await new MetaApi(env.METAAPI_TOKEN).metatraderAccountApi.getAccount(env.METAAPI_ACCOUNT_ID);
  const rpc = account.getRPCConnection();
  await rpc.connect(); await rpc.waitSynchronized();
  const pos = await rpc.getPositions();
  for (const t of open) {
    const p = pos.find((x) => String(x.id) === String(t.broker.positionId));
    if (!p) { console.log(`  ${t.strategyId} ${t.asset} position ${t.broker.positionId}: not open at broker - left as is`); continue; }
    await col.updateOne({ _id: t._id }, { $set: { 'broker.lots': p.volume } });
    console.log(`  ${t.strategyId} ${t.asset} position ${t.broker.positionId}: lots set to ${p.volume}`);
  }
  process.exit(0);
})().catch((e) => { console.error('DB fix failed:', e.message); process.exit(1); });
