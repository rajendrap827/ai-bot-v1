# Measured Move Trend (strategyId: mmt)

New, separate strategy. default and babalu are untouched.

Apply (one line):
  cd ~/ai-bot-v1 && git pull && unzip -o mmt.zip && cp mmt/backend/src/strategy/measuredMove.js scalp-bot/backend/src/strategy/ && node mmt/patch_registry.js && systemctl restart scalpbot

Expect: "OK registry.js", then in the log [BTC/mmt], [ETH/mmt], [GOLD/mmt] workers.
If ACTIVE_STRATEGIES is set in .env it must include mmt.

Start date for all mmt analysis = the restart time.
