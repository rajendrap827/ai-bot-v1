/**
 * Registers the Measured Move strategy ('mmt') in registry.js.
 * Adds a require line and one registry entry. Babalu and default are untouched.
 *
 * Usage: node patch_registry.js [path-to-backend]
 */
const fs = require('fs');
const path = require('path');

const backend = process.argv[2] || '/root/ai-bot-v1/scalp-bot/backend';
const file = path.join(backend, 'src/strategy/registry.js');
let s = fs.readFileSync(file, 'utf8');

if (s.includes("mmt: {")) {
  console.log('SKIP registry.js - mmt already registered');
  process.exit(0);
}

const reqAnchor = "const { computeBabaluSignal } = require('./babaluScoring');";
const endAnchor = '\n};\n\nfunction getStrategy';

const countOf = (a) => s.split(a).length - 1;
if (countOf(reqAnchor) !== 1 || countOf(endAnchor) !== 1) {
  console.error('FAIL registry.js - anchors not found exactly once. Nothing changed.');
  process.exit(1);
}

const entry = `

  mmt: {
    id: 'mmt',
    name: 'Measured Move Trend (15m trendline breakout)',
    compute: (candles, cfg, asset, htf) => computeMeasuredMoveSignal(candles, cfg, asset, htf),
    usesHtf: true,
    defaults: {
      // mmt-prefixed so the global Mongo config can never override them
      mmtPivLen: 5,
      mmtMaxBars: 30,
      mmtMinBody: 0.5,
      mmtSlBuf: 0.2,
      mmtMinStop: 0.5,
      mmtTpMode: 'swing',
      mmtFixedRR: 3,
      mmtMinRR: 2,
      cooldownBars: 3,
      useSessionFilter: false,
      hybridLockPct: 0.5,
      hybridTrailStartR: 1.0,
      trailAtrMult: 1.25,
    },
  },`;

fs.writeFileSync(file + '.bak-mmt', s);
s = s.replace(reqAnchor, reqAnchor + "\nconst { computeMeasuredMoveSignal } = require('./measuredMove');");
s = s.replace(endAnchor, entry + endAnchor);
fs.writeFileSync(file, s);
console.log('OK   registry.js (backup: registry.js.bak-mmt)');
