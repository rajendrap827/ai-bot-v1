const { atr } = require('./indicators');
const { getSession } = require('./stage');

/**
 * Measured Move Trend (strategyId: 'mmt') — port of the "Measured Move Trend [Raj]"
 * Pine indicator.
 *
 * The bot feeds closed 5m candles; this strategy is designed for 15m. It resamples
 * the 5m buffer into 15m bars and only evaluates when a 15m bar has just
 * completed, so it fires at most once per 15 minutes.
 *
 * It is stateless: every call replays the 15m history to rebuild swings, market
 * structure and which trendlines were already used. That keeps it identical to the
 * Pine logic without hidden state that would be lost on a restart.
 *
 * Rules (same as Pine):
 *   trend      up after a close above the last swing high, down after a close
 *              below the last swing low
 *   trendline  pullback line: two lower swing highs (uptrend) / two higher swing
 *              lows (downtrend)
 *   entry      close crosses that line on a strong candle in the trend direction,
 *              within maxBars of the 2nd swing, with the 1H trend agreeing
 *   stop       beyond the pullback extreme + ATR buffer, never closer than minStop ATR
 *   target     previous swing (default), measured move, or fixed RR;
 *              trade skipped if RR < minRR
 *
 * Not ported: the retest option and the volume/ADX filters (all off by default in
 * Pine; volume is unreliable on the MT5 tick-volume feed).
 */

const BAR_MS = 15 * 60 * 1000;

function resample15m(candles5m) {
  const out = [];
  let cur = null;
  for (const c of candles5m) {
    const t = new Date(c.t).getTime();
    const key = Math.floor(t / BAR_MS) * BAR_MS;
    if (!cur || cur.key !== key) {
      if (cur) out.push(cur);
      cur = { key, t: new Date(key), o: c.o, h: c.h, l: c.l, c: c.c, v: c.v || 0 };
    } else {
      cur.h = Math.max(cur.h, c.h);
      cur.l = Math.min(cur.l, c.l);
      cur.c = c.c;
      cur.v += c.v || 0;
    }
  }
  if (cur) out.push(cur);
  return out;
}

function isPivotHigh(bars, i, len) {
  if (i - len < 0 || i + len >= bars.length) return false;
  const h = bars[i].h;
  for (let k = i - len; k <= i + len; k++) {
    if (k === i) continue;
    if (k < i ? bars[k].h >= h : bars[k].h > h) return false;
  }
  return true;
}

function isPivotLow(bars, i, len) {
  if (i - len < 0 || i + len >= bars.length) return false;
  const l = bars[i].l;
  for (let k = i - len; k <= i + len; k++) {
    if (k === i) continue;
    if (k < i ? bars[k].l <= l : bars[k].l < l) return false;
  }
  return true;
}

function computeMeasuredMoveSignal(candles5m, cfg, asset, htf) {
  const pivLen = cfg.mmtPivLen || 5;
  const maxBars = cfg.mmtMaxBars || 30;
  const minBody = cfg.mmtMinBody || 0.5;
  const slBuf = cfg.mmtSlBuf != null ? cfg.mmtSlBuf : 0.2;
  const minStop = cfg.mmtMinStop != null ? cfg.mmtMinStop : 0.5;
  const tpMode = cfg.mmtTpMode || 'swing'; // 'swing' | 'measured' | 'fixed'
  const fixedRR = cfg.mmtFixedRR || 3;
  const minRR = cfg.mmtMinRR || 2;

  if (!candles5m || candles5m.length < 3) return { signal: null, reason: 'warmup' };

  // Only act on the 5m candle that completes a 15m bar (open time at :10, :25, :40, :55)
  const last5 = candles5m[candles5m.length - 1];
  const lastT = new Date(last5.t).getTime();
  if (lastT % BAR_MS !== 10 * 60 * 1000) return { signal: null, reason: 'not_15m_close' };

  const bars = resample15m(candles5m);
  const n = bars.length;
  if (n < pivLen * 2 + 30) return { signal: null, reason: 'warmup' };

  const atrSeries = atr(bars, 14);

  // Replay state
  let ph1 = null, ph2 = null, phb1 = null, phb2 = null;
  let pl1 = null, pl2 = null, plb1 = null, plb2 = null;
  let usedL = true, usedS = true;
  let trend = 0;
  let result = null;

  for (let i = 0; i < n; i++) {
    const b = bars[i];

    // Swings confirmed pivLen bars later (as ta.pivothigh)
    const c = i - pivLen;
    if (c >= 0 && isPivotHigh(bars, c, pivLen)) {
      ph1 = ph2; phb1 = phb2; ph2 = bars[c].h; phb2 = c; usedL = false;
    }
    if (c >= 0 && isPivotLow(bars, c, pivLen)) {
      pl1 = pl2; plb1 = plb2; pl2 = bars[c].l; plb2 = c; usedS = false;
    }

    const a = atrSeries[i];
    const rng = b.h - b.l;
    const bullC = rng > 0 && b.c > b.o && (b.c - b.o) >= minBody * rng;
    const bearC = rng > 0 && b.c < b.o && (b.o - b.c) >= minBody * rng;
    const isLast = i === n - 1;

    // ── LONG: descending pullback line in an uptrend ──
    const lineL = ph1 != null && ph2 != null && ph2 < ph1 && phb2 > phb1;
    if (lineL && i > 0 && trend === 1 && !usedL && (i - phb2) <= maxBars && a) {
      const slope = (ph2 - ph1) / (phb2 - phb1);
      const tl = ph2 + slope * (i - phb2);
      const tlPrev = ph2 + slope * (i - 1 - phb2);
      if (b.c > tl && bars[i - 1].c <= tlPrev && bullC) {
        usedL = true;
        let lowSince = Infinity;
        for (let k = phb1; k <= i; k++) lowSince = Math.min(lowSince, bars[k].l);
        const sl = Math.min(lowSince - slBuf * a, b.c - minStop * a);
        const risk = b.c - sl;
        let legStart = null;
        if (plb2 != null && plb2 < phb1) legStart = pl2;
        else if (plb1 != null && plb1 < phb1) legStart = pl1;
        const tp = tpMode === 'swing' ? ph1
          : tpMode === 'measured' ? (legStart == null ? null : lowSince + (ph1 - legStart))
          : b.c + fixedRR * risk;
        const rr = tp == null || risk <= 0 ? null : (tp - b.c) / risk;
        if (isLast && rr != null && rr >= minRR) {
          result = { dir: 'LONG', entry: b.c, sl, tp, rr, a };
        }
      }
    }

    // ── SHORT: ascending pullback line in a downtrend ──
    const lineS = pl1 != null && pl2 != null && pl2 > pl1 && plb2 > plb1;
    if (lineS && i > 0 && trend === -1 && !usedS && (i - plb2) <= maxBars && a) {
      const slope = (pl2 - pl1) / (plb2 - plb1);
      const tl = pl2 + slope * (i - plb2);
      const tlPrev = pl2 + slope * (i - 1 - plb2);
      if (b.c < tl && bars[i - 1].c >= tlPrev && bearC) {
        usedS = true;
        let highSince = -Infinity;
        for (let k = plb1; k <= i; k++) highSince = Math.max(highSince, bars[k].h);
        const sl = Math.max(highSince + slBuf * a, b.c + minStop * a);
        const risk = sl - b.c;
        let legStart = null;
        if (phb2 != null && phb2 < plb1) legStart = ph2;
        else if (phb1 != null && phb1 < plb1) legStart = ph1;
        const tp = tpMode === 'swing' ? pl1
          : tpMode === 'measured' ? (legStart == null ? null : highSince - (legStart - pl1))
          : b.c - fixedRR * risk;
        const rr = tp == null || risk <= 0 ? null : (b.c - tp) / risk;
        if (isLast && rr != null && rr >= minRR) {
          result = { dir: 'SHORT', entry: b.c, sl, tp, rr, a };
        }
      }
    }

    // Market structure updates last (setups on this bar used the prior state)
    if (ph2 != null && b.c > ph2) trend = 1;
    if (pl2 != null && b.c < pl2) trend = -1;
  }

  if (!result) return { signal: null, reason: 'no_setup' };

  // 1H trend filter (same as Pine default). No HTF data -> no trade.
  const htfOk = result.dir === 'LONG' ? htf && htf.bull === true : htf && htf.bear === true;
  if (!htfOk) return { signal: null, reason: 'htf_against' };

  const rrBucket = result.rr >= 4 ? 'RR4+' : result.rr >= 3 ? 'RR3-4' : 'RR2-3';
  const sessionInfo = getSession(new Date(last5.t));
  const checks = {
    stage: { passed: true, weight: 1, value: result.dir === 'LONG' ? 'structure_up' : 'structure_down' },
    aov: { passed: false, weight: 0, value: 'not_used' },
    pattern: { passed: true, weight: 1, value: 'strong_confirm_candle' },
    ema: { passed: true, weight: 1, value: 'htf_1h_aligned' },
    smc: { passed: true, weight: 1, value: 'trendline_break' },
    volume: { passed: false, weight: 0, value: 'not_used' },
  };

  return {
    signal: result.dir,
    time: last5.t,
    entry: result.entry,
    sl: result.sl,
    // Pine exits the whole trade at the target. TP1 = TP2 = target reproduces that:
    // the engine's 50% lock and the broker TP both fire at the same price.
    tp1: result.tp,
    tp2: result.tp,
    atr: result.a,
    stage: result.dir === 'LONG' ? 'ADVANCING' : 'DECLINING',
    session: sessionInfo.name,
    htfTrend: result.dir === 'LONG' ? 'UP' : 'DOWN',
    adx: 0,
    bullScore: result.dir === 'LONG' ? 4 : 0,
    bearScore: result.dir === 'SHORT' ? 4 : 0,
    score: 4,
    oppScore: 0,
    netMargin: 4,
    confirmationCandle: true,
    checks,
    setupFingerprint: `MMT-${tpMode.toUpperCase()}-${rrBucket}`,
    plannedRR: Math.round(result.rr * 100) / 100,
  };
}

module.exports = { computeMeasuredMoveSignal, resample15m };
