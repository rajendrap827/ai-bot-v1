#!/usr/bin/env node
/**
 * Babalu on 6 years of 5m data + variants that add the swing-strategy rules one at a time.
 * Read-only backtest. The live babalu strategy is not touched.
 *
 * PRE-REGISTERED 2026-10-12, before any result was seen. Variants are cumulative, decided in advance:
 *   B0  babalu as in the bot: close vs EMA200 + EMA9>21 trend; entry = EMA9/21 cross OR pullback
 *       (prev close below EMA9, this close above) + volume spike (tick vol > 1.5 x 20-bar avg);
 *       SL 1.5 ATR; TP1 2R closes 50%; after +1R the stop trails 1.5 ATR behind the best price;
 *       5-bar cooldown after an exit. One position at a time per asset.
 *   B1  B0 + HTF bias: previous completed 15m bar EMA9>EMA15, EMA9 slope >= 0.135 ATR/bar (3 bars),
 *       close > EMA15 (short: mirror)  - same bias as sw5p
 *   B2  B1 + rejection candle: signal bar must be STRONG (body >= 60% range and >= 0.5 ATR) or
 *       ENGULF (body >= 0.5 ATR) or PIN (touched EMA9 + 0.25 ATR, wick >= 2x body), and close beyond
 *       both EMA9 and EMA21
 *   B3  B2 + swing stop and swing exits: SL = lowest low of the last 5 bars - 0.2 ATR (min 0.5, skip > 3 ATR);
 *       targets = 10-bar swing points (reaction >= 1.5 ATR, last 1440 bars), levels < 1R skipped,
 *       fallback 2R/4R; 25% at T1 + SL to entry, 25% at T2 + SL to T1, step trail, then 3-bar structure trail
 * Decision: a variant counts as better only if it beats the previous one in BOTH 2020-23 and 2024+ on GOLD,
 * and does not get worse on BTC and ETH.
 *
 * Usage (from ~/ai-bot-v1/scalp-bot/backend):
 *   node backtest/swing/babalu_bt.js                      # GOLD,BTC,ETH  2020-01-01 -> 2025-09-30
 *   node backtest/swing/babalu_bt.js --assets=GOLD --by=year
 */
const fs = require('fs');
const path = require('path');
const { loadBars, ema, atr, pivots, rolling, biasSeries, TF_MS } = require('./lib');

const args = Object.fromEntries(process.argv.slice(2).map((s) => s.match(/^--([^=]+)(?:=(.*))?$/)).filter(Boolean).map((m) => [m[1], m[2] ?? true]));
const ASSETS = String(args.assets || 'GOLD,BTC,ETH').toUpperCase().split(',');
const FROM = Date.parse((args.from || '2020-01-01') + 'T00:00:00Z');
const TO = Date.parse((args.to || '2025-09-30') + 'T23:59:59Z');
const SPLIT = Date.parse('2024-01-01T00:00:00Z');
const DAY = 86400000;

// costs: same sources as run.js (defaults < config.json)
const SPREAD = { GOLD: 0.25, BTC: 8, ETH: 1.2 }, SWAP = { GOLD: 0.5222, BTC: 18.336, ETH: 0.565 };
try {
  const cfg = JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8'));
  for (const [a, c] of Object.entries(cfg.costs || {})) SPREAD[a] = (Number(c.spread) || 0) + (Number(c.commissionPerLotSide) || 0) * 2 / (Number(c.contractSize) || 1);
  Object.assign(SWAP, cfg.swapLong || {});
} catch {}
const SWAP_MULT = { GOLD: [0, 1, 1, 3, 1, 1, 0], BTC: [0, 1, 1, 1, 1, 3, 0], ETH: [0, 1, 1, 1, 1, 3, 0] };

// bot-style EMA (seeded with the first value)
function emaBot(src, len) { const k = 2 / (len + 1), out = new Float64Array(src.length); let p = null; for (let i = 0; i < src.length; i++) { p = p == null ? src[i] : src[i] * k + p * (1 - k); out[i] = p; } return out; }
function atrBot(b, len = 14) { const out = new Float64Array(b.n); let p = null; for (let i = 0; i < b.n; i++) { const tr = i ? Math.max(b.h[i] - b.l[i], Math.abs(b.h[i] - b.c[i - 1]), Math.abs(b.l[i] - b.c[i - 1])) : b.h[i] - b.l[i]; p = p == null ? tr : tr / len + p * (1 - 1 / len); out[i] = p; } return out; }

// same session windows as the bot (stage.js getSession, UTC hours)
function session(ms) { const d = new Date(ms), hr = d.getUTCHours() + d.getUTCMinutes() / 60; return hr < 8.5 ? 'ASIAN' : hr < 12.5 ? 'LONDON' : hr < 16 ? 'OVERLAP' : hr < 20 ? 'NY' : 'NY_CLOSE'; }

function runVariant(b, asset, V) {
  const { n, t, o, h, l, c, v } = b;
  const E9 = emaBot(c, 9), E21 = emaBot(c, 21), E200 = emaBot(c, 200), A = atrBot(b, 14);
  const bias = V >= 1 ? biasSeries(b, TF_MS['15m'], 3, 0.135).state : null;
  const PH = pivots(h, 10, true), PL = pivots(l, 10, false), PH3 = pivots(h, 3, true), PL3 = pivots(l, 3, false);
  const lowAfter = rolling(l, 10, true), highAfter = rolling(h, 10, false), low5 = rolling(l, 5, true), high5 = rolling(h, 5, false);
  const spread = SPREAD[asset] || 0, swapLong = SWAP[asset] || 0, mult = SWAP_MULT[asset];
  const phP = [], phB = [], plP = [], plB = [];
  const trades = [];
  let pos = null, cool = -1;

  const close = (i, px, reason) => {
    const part = pos.remain * pos.dir * (px - pos.entry) / pos.risk;
    const gross = pos.booked + part, spreadR = spread / pos.risk;
    trades.push({ t: pos.t, dir: pos.dir, reason, grossR: gross, netR: gross - spreadR - pos.swapR, kind: pos.kind, ses: session(pos.t) });
    pos = null; cool = i + 5;
  };

  for (let i = 1; i < n; i++) {
    const a = A[i];
    if (Number.isFinite(PH[i]) && PH[i] - lowAfter[i] >= 1.5 * a) { phP.push(PH[i]); phB.push(i - 10); }
    if (Number.isFinite(PL[i]) && highAfter[i] - PL[i] >= 1.5 * a) { plP.push(PL[i]); plB.push(i - 10); }
    while (phB.length && phB[0] < i - 1440) { phB.shift(); phP.shift(); }
    while (plB.length && plB[0] < i - 1440) { plB.shift(); plP.shift(); }

    // ---- manage
    if (pos && i > pos.bar) {
      const d = pos.dir;
      if (d === 1 && swapLong > 0) for (let k = Math.floor(t[i - 1] / DAY); k < Math.floor(t[i] / DAY); k++) pos.swapR += swapLong * mult[new Date(k * DAY).getUTCDay()] * pos.remain / pos.risk;
      const hit = d === 1 ? l[i] <= pos.sl : h[i] >= pos.sl;
      if (hit) { close(i, d === 1 ? Math.min(o[i], pos.sl) : Math.max(o[i], pos.sl), pos.slReason); continue; }
      if (V < 3) {
        // babalu hybrid exit
        if (!pos.tp1Hit && (d === 1 ? h[i] >= pos.tp1 : l[i] <= pos.tp1)) { pos.booked += 0.5 * 2; pos.remain = 0.5; pos.tp1Hit = true; }
        pos.best = d === 1 ? Math.max(pos.best, h[i]) : Math.min(pos.best, l[i]);
        if (d * (pos.best - pos.entry) / pos.risk >= 1) {
          const tr = pos.best - d * 1.5 * a;
          if (d === 1 ? tr > pos.sl : tr < pos.sl) { pos.sl = tr; pos.slReason = 'trail'; }
        }
      } else {
        // swing exits (same order as the swing engine)
        const lv = pos.levels, buf = 0.2 * a;
        let ns = pos.sl, why = null;
        const better = (x) => (d === 1 ? x > ns : x < ns);
        if (pos.stage === 0 && (d === 1 ? h[i] >= lv[0] : l[i] <= lv[0])) { pos.booked += 0.25 * d * (lv[0] - pos.entry) / pos.risk; pos.stage = 1; pos.remain = 0.75; if (better(pos.entry)) { ns = pos.entry; why = 'breakeven'; } }
        if (pos.stage === 1 && (d === 1 ? h[i] >= lv[1] : l[i] <= lv[1])) { pos.booked += 0.25 * d * (lv[1] - pos.entry) / pos.risk; pos.stage = 2; pos.remain = 0.5; const x = lv[0] - d * buf; if (better(x)) { ns = x; why = 'step'; } }
        if (pos.stage === 2) {
          while (pos.next < lv.length && (d === 1 ? h[i] >= lv[pos.next] : l[i] <= lv[pos.next])) { const x = lv[pos.next - 1] - d * buf; if (better(x)) { ns = x; why = 'step'; } pos.next++; }
          if (pos.next >= lv.length) { const pv = d === 1 ? PL3[i] : PH3[i]; if (Number.isFinite(pv)) { const x = pv - d * buf; if (better(x)) { ns = x; why = 'structure'; } } }
        }
        if (why) { pos.sl = ns; pos.slReason = why; }
      }
    }

    // ---- signal
    if (pos || i <= cool || t[i] < FROM || t[i] > TO || !(a > 0) || i < 250) continue;
    const bull = c[i] > E200[i] && E9[i] > E21[i], bear = c[i] < E200[i] && E9[i] < E21[i];
    let avg = 0; for (let j = i - 20; j < i; j++) avg += v[j]; avg /= 20;
    const vol = v[i] > 0 && v[i] > 1.5 * avg;
    if (!vol) continue;
    const xUp = E9[i - 1] <= E21[i - 1] && E9[i] > E21[i], xDn = E9[i - 1] >= E21[i - 1] && E9[i] < E21[i];
    const pbL = bull && c[i] > E9[i] && c[i - 1] < E9[i - 1], pbS = bear && c[i] < E9[i] && c[i - 1] > E9[i - 1];
    const dir = bull && (xUp || pbL) ? 1 : bear && (xDn || pbS) ? -1 : 0;
    if (!dir) continue;
    const kind = (dir === 1 ? xUp : xDn) ? 'cross' : 'pullback';
    if (V >= 1 && bias[i] !== dir) continue;
    if (V >= 2) {
      const rng = h[i] - l[i], body = Math.abs(c[i] - o[i]);
      const upW = h[i] - Math.max(o[i], c[i]), loW = Math.min(o[i], c[i]) - l[i];
      const bu = c[i] > o[i], be = c[i] < o[i];
      const strong = (dir === 1 ? bu : be) && rng > 0 && body >= 0.6 * rng && body >= 0.5 * a;
      const eng = dir === 1 ? bu && c[i - 1] < o[i - 1] && c[i] >= o[i - 1] && o[i] <= c[i - 1] && body >= 0.5 * a
        : be && c[i - 1] > o[i - 1] && c[i] <= o[i - 1] && o[i] >= c[i - 1] && body >= 0.5 * a;
      const pin = (dir === 1 ? l[i] <= E9[i] + 0.25 * a : h[i] >= E9[i] - 0.25 * a) && rng > 0 && (dir === 1
        ? loW >= 2 * body && loW >= 0.6 * rng && c[i] >= l[i] + rng * 2 / 3
        : upW >= 2 * body && upW >= 0.6 * rng && c[i] <= h[i] - rng * 2 / 3);
      const beyond = dir === 1 ? c[i] > E9[i] && c[i] > E21[i] : c[i] < E9[i] && c[i] < E21[i];
      if (!(strong || eng || pin) || !beyond) continue;
    }
    let sl, risk;
    if (V < 3) { risk = 1.5 * a; sl = c[i] - dir * risk; }
    else {
      sl = dir === 1 ? low5[i] - 0.2 * a : high5[i] + 0.2 * a;
      risk = dir * (c[i] - sl);
      if (risk < 0.5 * a) { risk = 0.5 * a; sl = c[i] - dir * risk; }
      if (risk > 3 * a) continue;
    }
    pos = { dir, bar: i, t: t[i], entry: c[i], sl, risk, slReason: 'initial', booked: 0, remain: 1, swapR: 0, kind,
      tp1: c[i] + dir * 2 * risk, tp1Hit: false, best: c[i], stage: 0, next: 2 };
    if (V >= 3) {
      const raw = (dir === 1 ? phP.filter((p) => p > c[i]).sort((x, y) => x - y) : plP.filter((p) => p < c[i]).sort((x, y) => y - x));
      const merged = [];
      for (const p of raw) if (!merged.length || (dir === 1 ? p > merged[merged.length - 1] + 0.5 * a : p < merged[merged.length - 1] - 0.5 * a)) merged.push(p);
      const lv = merged.filter((p) => Math.abs(p - c[i]) >= risk);
      if (!lv.length) lv.push(c[i] + dir * 2 * risk, c[i] + dir * 4 * risk);
      else if (lv.length === 1) lv.push(lv[0] + (lv[0] - c[i]));
      pos.levels = lv;
    }
  }
  return trades;
}

function stats(a) {
  let eq = 0, pk = 0, dd = 0;
  for (const x of a) { eq += x.netR; pk = Math.max(pk, eq); dd = Math.min(dd, eq - pk); }
  const w = a.filter((x) => x.netR > 0).length;
  return { n: a.length, win: a.length ? 100 * w / a.length : 0, avg: a.length ? eq / a.length : NaN, total: eq, dd };
}
const f = (x, d = 3) => (Number.isFinite(x) ? (x >= 0 ? '+' : '') + x.toFixed(d) : '   -  ');
const NAMES = ['B0 babalu as is', 'B1 + HTF bias', 'B2 + rejection candle', 'B3 + swing SL/exits'];

for (const asset of ASSETS) {
  const b = loadBars(asset, '5m');
  if (!b) { console.log(`${asset}: no 5m data`); continue; }
  console.log(`\n== ${asset} 5m  ${new Date(FROM).toISOString().slice(0, 10)} -> ${new Date(TO).toISOString().slice(0, 10)}  cost ${SPREAD[asset]} / trade, swap ${SWAP[asset]}`);
  console.log('   variant                   trades  /month  win    avgR    total     maxDD   | 2020-23   2024+');
  const months = (TO - FROM) / (30.44 * DAY);
  for (let V = 0; V <= 3; V++) {
    if (args.variants && !String(args.variants).split(',').includes(String(V))) continue;
    const tr = runVariant(b, asset, V);
    const s = stats(tr), s1 = stats(tr.filter((x) => x.t < SPLIT)), s2 = stats(tr.filter((x) => x.t >= SPLIT));
    console.log(`   ${NAMES[V].padEnd(25)} ${String(s.n).padStart(6)}  ${(s.n / months).toFixed(1).padStart(6)}  ${s.win.toFixed(0).padStart(3)}%  ${f(s.avg)}  ${f(s.total, 1).padStart(7)}R  ${f(s.dd, 1).padStart(7)}R  | ${f(s1.avg)}  ${f(s2.avg)}`);
    if (args.by === 'session' || args.by === 'dir') {
      const key = args.by === 'session' ? (x) => x.ses : (x) => (x.dir === 1 ? 'LONG' : 'SHORT');
      const y = {};
      for (const x of tr) (y[key(x)] ||= []).push(x);
      for (const k of Object.keys(y).sort()) {
        const a = y[k], p1 = stats(a.filter((x) => x.t < SPLIT)), p2 = stats(a.filter((x) => x.t >= SPLIT));
        console.log(`        ${k.padEnd(9)} n ${String(a.length).padStart(5)}  avgR ${f(stats(a).avg)}  | 2020-23 ${f(p1.avg)}  2024+ ${f(p2.avg)}`);
      }
    }
    if (args.by === 'year') {
      const y = {};
      for (const x of tr) (y[new Date(x.t).getUTCFullYear()] ||= []).push(x);
      console.log('        ' + Object.keys(y).sort().map((k) => `${k} ${f(stats(y[k]).avg, 2)} (${y[k].length})`).join('  '));
    }
  }
}
