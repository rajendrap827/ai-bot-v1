#!/usr/bin/env node
/**
 * Spread logger — samples bid/ask for the bot's symbols once a minute and appends
 * them to backtest/data/spreads.jsonl. Runs as its own process (systemd service
 * "spreadlog"); it opens a separate read-only MetaApi RPC connection and never
 * touches the bot, its database or its orders.
 *
 * Run (from ~/ai-bot-v1/scalp-bot/backend):  node backtest/spread_logger.js
 * Report:                                    node backtest/spread_report.js
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const OUT = path.join(__dirname, 'data', 'spreads.jsonl');
const EVERY_MS = 60 * 1000;
const STALE_MS = 10 * 60 * 1000; // ignore quotes older than this (market closed)

function loadEnv() {
  const p = path.join(ROOT, '.env');
  const env = {};
  if (fs.existsSync(p)) {
    for (const line of fs.readFileSync(p, 'utf8').split('\n')) {
      const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
      if (m) env[m[1]] = m[2].replace(/^['"]|['"]$/g, '');
    }
  }
  return env;
}

async function main() {
  const env = loadEnv();
  if (!env.METAAPI_TOKEN || !env.METAAPI_ACCOUNT_ID) {
    console.error('METAAPI_TOKEN / METAAPI_ACCOUNT_ID missing in .env');
    process.exit(1);
  }
  const symbols = {
    BTC: env.SYMBOL_BTC || 'BTCUSDm',
    ETH: env.SYMBOL_ETH || 'ETHUSDm',
    GOLD: env.SYMBOL_GOLD || 'XAUUSDm',
  };
  fs.mkdirSync(path.dirname(OUT), { recursive: true });

  const MetaApi = require('metaapi.cloud-sdk').default;
  const api = new MetaApi(env.METAAPI_TOKEN);
  const account = await api.metatraderAccountApi.getAccount(env.METAAPI_ACCOUNT_ID);
  const conn = account.getRPCConnection();
  await conn.connect();
  await conn.waitSynchronized();
  console.log(`[spreadlog] connected, sampling every ${EVERY_MS / 1000}s -> ${OUT}`);

  let failures = 0;
  const sample = async () => {
    let ok = 0;
    for (const [asset, symbol] of Object.entries(symbols)) {
      try {
        const p = await conn.getSymbolPrice(symbol);
        if (!p || !(p.ask > 0) || !(p.bid > 0)) continue;
        const qt = p.time ? new Date(p.time).getTime() : Date.now();
        if (Date.now() - qt > STALE_MS) continue; // market closed, quote not moving
        const row = { t: new Date().toISOString(), asset, bid: p.bid, ask: p.ask, spread: +(p.ask - p.bid).toFixed(6) };
        fs.appendFileSync(OUT, JSON.stringify(row) + '\n');
        ok++;
      } catch (err) {
        console.error(`[spreadlog] ${asset}: ${err.message}`);
      }
    }
    failures = ok === 0 ? failures + 1 : 0;
    // 15 minutes with nothing recorded and no market closure reason: let systemd restart us
    const wd = new Date().getUTCDay();
    if (failures >= 15 && wd !== 0 && wd !== 6) {
      console.error('[spreadlog] no samples for 15 minutes - exiting for restart');
      process.exit(1);
    }
  };

  await sample();
  setInterval(() => { sample().catch((e) => console.error('[spreadlog]', e.message)); }, EVERY_MS);
}

main().catch((err) => {
  console.error('[spreadlog] fatal:', err.message);
  process.exit(1);
});
