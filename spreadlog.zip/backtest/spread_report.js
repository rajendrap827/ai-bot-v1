#!/usr/bin/env node
/**
 * Summarises backtest/data/spreads.jsonl by asset and session (UTC windows, same as
 * the bot) and suggests a --spread value for backtests.
 *
 * Usage: node backtest/spread_report.js [--days=7]
 */
const fs = require('fs');
const path = require('path');

const FILE = path.join(__dirname, 'data', 'spreads.jsonl');
const SESSIONS = ['ASIAN', 'LONDON', 'OVERLAP', 'NY', 'NY_CLOSE'];

function sessionOf(d) {
  const h = d.getUTCHours() + d.getUTCMinutes() / 60;
  if (h < 8.5) return 'ASIAN';
  if (h < 12.5) return 'LONDON';
  if (h < 16) return 'OVERLAP';
  if (h < 20) return 'NY';
  return 'NY_CLOSE';
}

function stats(a) {
  if (!a.length) return null;
  const s = [...a].sort((x, y) => x - y);
  const q = (p) => s[Math.min(s.length - 1, Math.floor(p * s.length))];
  return { n: a.length, mean: a.reduce((t, x) => t + x, 0) / a.length, median: q(0.5), p90: q(0.9), max: s[s.length - 1] };
}

function fmt(x, asset) {
  const d = asset === 'GOLD' ? 3 : 2;
  return x.toFixed(d).padStart(8);
}

function main() {
  const m = process.argv.join(' ').match(/--days=(\d+)/);
  const since = m ? Date.now() - parseInt(m[1], 10) * 86400000 : 0;
  if (!fs.existsSync(FILE)) { console.log('no data yet: ' + FILE); return; }

  const by = {};
  let first = null, last = null;
  for (const line of fs.readFileSync(FILE, 'utf8').split('\n')) {
    if (!line.trim()) continue;
    let r;
    try { r = JSON.parse(line); } catch { continue; }
    const d = new Date(r.t);
    if (d.getTime() < since || !(r.spread >= 0)) continue;
    first = first && first < d ? first : d;
    last = last && last > d ? last : d;
    const s = sessionOf(d);
    by[r.asset] = by[r.asset] || { ALL: [] };
    (by[r.asset][s] = by[r.asset][s] || []).push(r.spread);
    by[r.asset].ALL.push(r.spread);
  }
  if (!first) { console.log('no samples in range'); return; }
  console.log(`spreads ${first.toISOString().slice(0, 16)} -> ${last.toISOString().slice(0, 16)} UTC\n`);

  const suggest = [];
  for (const asset of ['GOLD', 'BTC', 'ETH']) {
    const g = by[asset];
    if (!g) continue;
    console.log(`== ${asset}        n      mean   median      p90      max`);
    for (const s of [...SESSIONS, 'ALL']) {
      const st = stats(g[s] || []);
      if (!st) continue;
      console.log(`  ${s.padEnd(9)} ${String(st.n).padStart(6)} ${fmt(st.mean, asset)} ${fmt(st.median, asset)} ${fmt(st.p90, asset)} ${fmt(st.max, asset)}`);
    }
    suggest.push(`${asset}:${stats(g.ALL).mean.toFixed(asset === 'GOLD' ? 3 : 2)}`);
    console.log('');
  }
  console.log('Use the overall mean in backtests (conservative enough, sessions differ):');
  console.log(`  --spread=${suggest.join(',')}`);
}

main();
