# Tuner persistence fix

Weights were copied with Object.assign on Mongoose subdocuments, which copies
internal properties, not the fields. Reads saw every weight as 1.0; writes
wiped every other component back to 1. Result: the tuner repeated the same
1.0 -> 1.3 step forever, and at most one change per asset survived.

Apply:
  cd ~/ai-bot-v1 && cp tuner-fix2/backend/src/tuning/tuner.js scalp-bot/backend/src/tuning/ && systemctl restart scalpbot

Verify after the next daily cycle — weightBefore should now show the stored
value (e.g. 1.3), not 1:
  docker exec mongo mongosh scalpbot --quiet --eval "db.tuninglogs.find({action:{\$in:['decay','restore']}},{ts:1,asset:1,component:1,weightBefore:1,weightAfter:1,_id:0}).sort({ts:-1}).limit(5).toArray()"
