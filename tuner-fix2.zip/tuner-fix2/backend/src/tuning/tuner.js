const Trade = require('../models/Trade');
const TuningLog = require('../models/TuningLog');
const { Config } = require('../models/Config');
const { invalidateConfigCache } = require('../config/configLoader');

const MIN_TRADES_TO_TUNE = 30;
const SHRINKAGE_K = 20;
const DECAY_STEP = 0.3;
const RESTORE_STEP = 0.3;
const RECENCY_HALFLIFE_DAYS = 35;
const COOLDOWN_CYCLES = 2;
const COMPONENTS = ['stage', 'aov', 'pattern', 'ema', 'smc', 'volume'];
const DEFAULT_WEIGHTS = { stage: 1, aov: 1, pattern: 1, ema: 1, smc: 1, volume: 1 };

const MAX_WEIGHT = 1.5;
const MIN_WEIGHT = 0;
const DIFF_THRESHOLD = 0.1;

/**
 * Convert a Mongoose subdocument (or anything) into a plain object.
 *
 * THE BUG THIS FIXES: weights were copied with Object.assign({}, subdoc).
 * On a Mongoose subdocument that copies internal bookkeeping properties, not
 * the schema fields — so `aov`, `volume` etc. came back undefined.
 *   - On READ, every weight looked like 1.0, so the tuner never saw its own
 *     earlier changes and kept re-applying 1.0 -> 1.3 instead of progressing.
 *   - On WRITE, the new weights object lost every other field, the schema
 *     refilled them with default 1, and each change wiped out the previous one.
 * Net effect: at most one adjustment per asset ever survived.
 */
function plain(x) {
  if (!x) return {};
  if (typeof x.toObject === 'function') return x.toObject();
  return Object.assign({}, x);
}

function recencyWeight(tradeDate, now) {
  const ageDays = (now - tradeDate) / 86400000;
  return Math.pow(0.5, ageDays / RECENCY_HALFLIFE_DAYS);
}

function shrink(sampleExpectancy, n, globalExpectancy, k = SHRINKAGE_K) {
  const w = n / (n + k);
  return w * sampleExpectancy + (1 - w) * globalExpectancy;
}

function weightedExpectancy(trades, now) {
  if (trades.length === 0) return 0;
  let wSum = 0, wTotal = 0;
  for (const t of trades) {
    const w = recencyWeight(t.outcome.exitTime || t.createdAt, now);
    wSum += (t.outcome.rMultiple || 0) * w;
    wTotal += w;
  }
  return wTotal > 0 ? wSum / wTotal : 0;
}

function getCurrentWeights(configDoc, asset) {
  const entry = configDoc.perAsset && configDoc.perAsset.get ? plain(configDoc.perAsset.get(asset)) : {};
  return Object.assign({}, DEFAULT_WEIGHTS, plain(entry.weights));
}

async function runTuningCycle(asset, strategyId = 'default', accountId = 'paper-main') {
  const now = new Date();
  const closedTrades = await Trade.find({ asset, strategyId, accountId, 'outcome.status': 'CLOSED' }).lean();

  if (closedTrades.length < MIN_TRADES_TO_TUNE) {
    return { skipped: true, reason: `only ${closedTrades.length} closed trades, need ${MIN_TRADES_TO_TUNE}` };
  }

  const configDoc = await Config.findOne({ strategyId, accountId });
  if (!configDoc) return { skipped: true, reason: 'no config document found' };

  const globalExpectancy = weightedExpectancy(closedTrades, now);
  const currentWeights = getCurrentWeights(configDoc, asset);
  const decisions = [];

  for (const component of COMPONENTS) {
    const fired = closedTrades.filter((t) => t.entryBasis && t.entryBasis.checks && t.entryBasis.checks[component] && t.entryBasis.checks[component].passed);
    const sampleSize = fired.length;

    if (sampleSize === 0) {
      decisions.push({ component, action: 'no_change', reason: 'no trades fired this component yet' });
      continue;
    }

    const rawExpectancy = weightedExpectancy(fired, now);
    const shrunkExpectancy = shrink(rawExpectancy, sampleSize, globalExpectancy);
    const weightBefore = currentWeights[component] != null ? currentWeights[component] : 1;
    const diff = shrunkExpectancy - globalExpectancy;

    const base = {
      asset, strategyId, component, sampleSize, rawExpectancy, shrunkExpectancy,
      globalExpectancy, weightBefore, configVersion: configDoc.meta.version,
    };

    if (sampleSize < MIN_TRADES_TO_TUNE) {
      decisions.push(await recordDecision(Object.assign({}, base, {
        weightAfter: weightBefore, action: 'no_change',
        reason: `sample size ${sampleSize} below minimum (${MIN_TRADES_TO_TUNE})`,
      })));
      continue;
    }

    if (await isInCooldown(asset, component, strategyId)) {
      decisions.push(await recordDecision(Object.assign({}, base, {
        weightAfter: weightBefore, action: 'hold_cooldown',
        reason: `weight changed within the last ${COOLDOWN_CYCLES} cycles - holding to avoid flapping`,
      })));
      continue;
    }

    const firedShare = sampleSize / closedTrades.length;
    if (firedShare > 0.95 && Math.abs(diff) < 0.001) {
      decisions.push(await recordDecision(Object.assign({}, base, {
        weightAfter: weightBefore, action: 'no_change',
        reason: `fires on ${Math.round(firedShare * 100)}% of trades, so its expectancy equals the global by construction - nothing to compare`,
      })));
      continue;
    }

    let weightAfter = weightBefore;
    let action = 'no_change';
    let reason = `shrunk expectancy (${shrunkExpectancy.toFixed(3)}R) is within ${DIFF_THRESHOLD}R of global (${globalExpectancy.toFixed(3)}R)`;

    if (diff < -DIFF_THRESHOLD) {
      if (weightBefore > MIN_WEIGHT) {
        weightAfter = Math.max(MIN_WEIGHT, Math.round((weightBefore - DECAY_STEP) * 100) / 100);
        action = 'decay';
        reason = `shrunk expectancy (${shrunkExpectancy.toFixed(3)}R) underperforms global (${globalExpectancy.toFixed(3)}R) by ${Math.abs(diff).toFixed(3)}R on ${sampleSize} trades - reducing trust`;
      } else {
        reason = `underperforms global by ${Math.abs(diff).toFixed(3)}R but weight is already at the floor (${MIN_WEIGHT})`;
      }
    } else if (diff > DIFF_THRESHOLD) {
      if (weightBefore < MAX_WEIGHT) {
        weightAfter = Math.min(MAX_WEIGHT, Math.round((weightBefore + RESTORE_STEP) * 100) / 100);
        action = 'restore';
        reason = `shrunk expectancy (${shrunkExpectancy.toFixed(3)}R) outperforms global (${globalExpectancy.toFixed(3)}R) by ${diff.toFixed(3)}R on ${sampleSize} trades - increasing trust`;
      } else {
        reason = `outperforms global by ${diff.toFixed(3)}R but weight is already at the ceiling (${MAX_WEIGHT})`;
      }
    }

    decisions.push(await recordDecision(Object.assign({}, base, { weightAfter, action, reason })));

    if (action !== 'no_change') {
      await applyWeightChange(configDoc, asset, component, weightAfter);
      currentWeights[component] = weightAfter; // keep in-cycle view consistent
    }
  }

  return { skipped: false, decisions, totalClosedTrades: closedTrades.length, globalExpectancy };
}

async function isInCooldown(asset, component, strategyId) {
  const recentChange = await TuningLog.findOne({
    asset, component, strategyId,
    action: { $in: ['decay', 'restore'] },
  }).sort({ ts: -1 }).lean();
  if (!recentChange) return false;

  const cyclesSince = await TuningLog.countDocuments({
    asset, component, strategyId,
    ts: { $gt: recentChange.ts },
  });
  return cyclesSince < COOLDOWN_CYCLES;
}

async function recordDecision(fields) {
  const log = await TuningLog.create({
    asset: fields.asset,
    strategyId: fields.strategyId,
    component: fields.component,
    sampleSize: fields.sampleSize,
    expectancyWithBefore: round3(fields.rawExpectancy),
    expectancyShrunk: round3(fields.shrunkExpectancy),
    globalExpectancy: round3(fields.globalExpectancy),
    weightBefore: fields.weightBefore,
    weightAfter: fields.weightAfter,
    action: fields.action,
    reason: fields.reason,
    configVersionBefore: fields.configVersion,
    configVersionAfter: (fields.action === 'no_change' || fields.action === 'hold_cooldown')
      ? fields.configVersion
      : fields.configVersion + 1,
  });
  return log.toObject();
}

async function applyWeightChange(configDoc, asset, component, newWeight) {
  if (!configDoc.perAsset) configDoc.perAsset = new Map();
  const existing = plain(configDoc.perAsset.get(asset));
  // Start from the FULL current set so other components keep their values.
  const weights = Object.assign({}, DEFAULT_WEIGHTS, plain(existing.weights), { [component]: newWeight });
  configDoc.perAsset.set(asset, Object.assign({}, existing, { weights }));
  configDoc.markModified('perAsset');
  configDoc.meta.version += 1;
  configDoc.meta.updatedAt = new Date();
  configDoc.meta.updatedBy = 'auto-tuner';
  await configDoc.save();
  invalidateConfigCache(asset, configDoc.strategyId, configDoc.accountId);
  console.log(`[tuner] ${configDoc.strategyId}/${asset}/${component}: weight -> ${newWeight} (all: ${JSON.stringify(weights)})`);
}

function round3(n) {
  return Math.round((n || 0) * 1000) / 1000;
}

module.exports = { runTuningCycle, MIN_TRADES_TO_TUNE, MAX_WEIGHT };
