const env = require('./config/env');
const { connectDB } = require('./config/db');
const { seedInitialBalance } = require('./config/bootstrap');
const { startChangeStreamWatchers } = require('./events/changeStreamWatcher');
const { createServer } = require('./api/server');
const { startMetaApiFeed } = require('./feeds/metaApiFeed');
const { createFeedMultiplexer } = require('./feeds/feedMultiplexer');
const { runStrategyWorker } = require('./workers/strategyWorker');
const { allStrategyIds } = require('./strategy/registry');
const { runTuningCycle } = require('./tuning/tuner');
const { initBrokerExecution } = require('./execution/brokerExecution');
const { attachBroker } = require('./engine/paperEngine');
const { ema } = require('./strategy/indicators');
const Candle = require('./models/Candle');

const TUNING_INTERVAL_MS = 24 * 60 * 60 * 1000;
const ASSETS = ['BTC', 'ETH', 'GOLD'];

const SYMBOLS = {
  BTC: process.env.SYMBOL_BTC || 'BTCUSDm',
  ETH: process.env.SYMBOL_ETH || 'ETHUSDm',
  GOLD: process.env.SYMBOL_GOLD || 'XAUUSDm',
};

// Which strategies to run. Defaults to every strategy in the registry;
// set ACTIVE_STRATEGIES=default,babalu in .env to control it explicitly.
const ACTIVE = (process.env.ACTIVE_STRATEGIES || allStrategyIds().join(','))
  .split(',').map((s) => s.trim()).filter(Boolean);

async function main() {
  await connectDB();
  await seedInitialBalance();
  startChangeStreamWatchers();

  const { httpServer } = createServer();
  httpServer.listen(env.port, () => console.log(`[api] listening on port ${env.port}`));

  if (!process.env.METAAPI_TOKEN || !process.env.METAAPI_ACCOUNT_ID) {
    console.error('[main] METAAPI_TOKEN and METAAPI_ACCOUNT_ID must be set — cannot start feeds.');
    return;
  }

  const feed = await startMetaApiFeed({
    token: process.env.METAAPI_TOKEN,
    accountId: process.env.METAAPI_ACCOUNT_ID,
    symbols: SYMBOLS,
  });

  const brokerReady = await initBrokerExecution(feed.connection);
  if (brokerReady) attachBroker(feed.connection, SYMBOLS);

  // One feed, many strategy workers per asset.
  const mux = createFeedMultiplexer(feed);

  for (const asset of ASSETS) {
    for (const strategyId of ACTIVE) {
      await runStrategyWorker({
        asset,
        strategyId,
        timeframe: '5m',
        seedCandles: async () => {
          const hist = await feed.getHistory(asset, 320);
          if (hist && hist.length > 50) return hist;
          const docs = await Candle.find({ asset, timeframe: '5m' }).sort({ t: -1 }).limit(320).lean();
          return docs.reverse().map((d) => ({ t: d.t, o: d.o, h: d.h, l: d.l, c: d.c, v: d.v }));
        },
        registerFeed: (handlers) => mux.subscribe(asset, handlers),
        getHtfTrend: () => htfTrendFromCandles(asset, '5m', 60, 50),
      });
    }
  }

  setInterval(async () => {
    for (const asset of ASSETS) {
      for (const strategyId of ACTIVE) {
        try {
          const result = await runTuningCycle(asset, strategyId);
          console.log(result.skipped
            ? `[tuner:${asset}/${strategyId}] skipped — ${result.reason}`
            : `[tuner:${asset}/${strategyId}] reviewed ${result.decisions.length} component(s)`);
        } catch (err) {
          console.error(`[tuner:${asset}/${strategyId}] error:`, err.message);
        }
      }
    }
  }, TUNING_INTERVAL_MS);

  console.log(`[main] started — assets: ${ASSETS.join(', ')} | strategies: ${ACTIVE.join(', ')} | broker orders: ${brokerReady ? 'ENABLED (demo)' : 'disabled'}`);
}

async function htfTrendFromCandles(asset, timeframe, htfMinutes, htfLen) {
  const need = (htfLen + 5) * (htfMinutes / 5) + 5;
  const docs = await Candle.find({ asset, timeframe }).sort({ t: -1 }).limit(Math.ceil(need)).lean();
  if (docs.length < (htfMinutes / 5) * 3) return { bull: null, bear: null };
  const rows = docs.reverse();

  const bucketMs = htfMinutes * 60 * 1000;
  const buckets = new Map();
  for (const d of rows) {
    const key = Math.floor(new Date(d.t).getTime() / bucketMs) * bucketMs;
    const b = buckets.get(key);
    if (!b) buckets.set(key, { c: d.c });
    else b.c = d.c;
  }
  const closes = [...buckets.entries()].sort((a, b) => a[0] - b[0]).map(([, v]) => v.c);
  if (closes.length < 3) return { bull: null, bear: null };

  const emaSeries = ema(closes, Math.min(htfLen, closes.length - 1));
  const i = closes.length - 2;
  if (i < 1 || emaSeries[i] == null) return { bull: null, bear: null };
  return { bull: closes[i] > emaSeries[i], bear: closes[i] < emaSeries[i] };
}

main().catch((err) => {
  console.error('[main] fatal startup error:', err);
  process.exit(1);
});
