const { atr } = require('../strategy/indicators');
const { getStrategy } = require('../strategy/registry');
const { getMergedConfig } = require('../config/configLoader');
const { getNewsContext } = require('../news/finnhubCalendar');
const { openTrade, manageOpenTrades } = require('../engine/paperEngine');
const Trade = require('../models/Trade');
const Candle = require('../models/Candle');

const MAX_BUFFER = 400;

/**
 * Runs ONE strategy on ONE asset. Multiple strategies share the same candle
 * feed — each worker keeps its own buffer and cooldown, and everything it
 * writes is tagged with its strategyId so paper trades, tuning and dashboard
 * views stay cleanly separated per strategy.
 */
async function runStrategyWorker({
  asset,
  strategyId,
  timeframe = '5m',
  seedCandles,
  registerFeed,      // (handlers) => void  — subscribe to the shared feed
  getHtfTrend,
}) {
  const strategy = getStrategy(strategyId);
  const tag = `${asset}/${strategyId}`;

  let buffer = await seedCandles();
  if (!Array.isArray(buffer)) buffer = [];
  console.log(`[${tag}] seeded with ${buffer.length} candles (${strategy.name})`);

  let lastAtr = null;
  let barIndex = buffer.length;
  let lastSignalBarIndex = -Infinity;
  let persistedThisAsset = false; // only ONE worker per asset persists candles

  async function onClosedCandle(candle, { persist = false } = {}) {
    buffer.push(candle);
    if (buffer.length > MAX_BUFFER) buffer = buffer.slice(buffer.length - MAX_BUFFER);
    barIndex += 1;

    const atrSeries = atr(buffer, 14);
    lastAtr = atrSeries[atrSeries.length - 1];

    // Candles are shared data, not strategy data — only one worker writes them
    // to avoid duplicate rows in the time-series collection.
    if (persist) {
      try {
        await Candle.create({ asset, timeframe, t: candle.t, o: candle.o, h: candle.h, l: candle.l, c: candle.c, v: candle.v });
      } catch (err) {
        console.error(`[${tag}] failed to persist candle:`, err.message);
      }
    }

    try {
      const { cfg } = await getMergedConfig(asset, strategyId);
      const merged = { ...strategy.defaults, ...cfg };

      const htf = strategy.usesHtf && getHtfTrend ? await safeGetHtf(getHtfTrend) : { bull: null, bear: null };
      const signal = strategy.compute(buffer, merged, asset, htf);

      if (!signal || !signal.signal) return;

      if (barIndex - lastSignalBarIndex < (merged.cooldownBars || 0)) return;

      const openCount = await Trade.countDocuments({ asset, strategyId, 'outcome.status': 'OPEN' });
      if (openCount >= (merged.maxOpenPerAsset || 1)) return;

      const entryTime = new Date(signal.time);
      const newsContext = merged.useNewsBlackout
        ? await getNewsContext(entryTime, merged.newsBlackoutMinutes || 30)
        : { highImpactEventNearby: false, events: [], blackoutActive: false, sentiment: { available: false, score: null, label: null, source: null } };

      if (merged.useNewsBlackout && newsContext.blackoutActive) {
        console.log(`[${tag}] signal skipped — news blackout`);
        return;
      }

      const trade = await openTrade({
        asset,
        timeframe,
        signal,
        cfg: merged,
        paramsVersion: merged.paramsVersion || 1,
        newsContext,
        strategyId,
      });

      if (trade) {
        lastSignalBarIndex = barIndex;
        console.log(`[${tag}] OPENED ${signal.signal} @ ${signal.entry} | score ${signal.score} | ${signal.setupFingerprint}`);
      }
    } catch (err) {
      console.error(`[${tag}] error processing candle:`, err.message);
    }
  }

  async function onTick(tick) {
    if (lastAtr == null) return;
    try {
      const { cfg } = await getMergedConfig(asset, strategyId);
      const merged = { ...strategy.defaults, ...cfg };
      await manageOpenTrades(asset, tick.price, lastAtr, merged, strategyId);
    } catch (err) {
      console.error(`[${tag}] error managing trades:`, err.message);
    }
  }

  registerFeed({ onClosedCandle, onTick });
  console.log(`[${tag}] worker running`);
  return { onClosedCandle, onTick };
}

async function safeGetHtf(getHtfTrend) {
  try {
    return await getHtfTrend();
  } catch (err) {
    return { bull: null, bear: null };
  }
}

module.exports = { runStrategyWorker };
