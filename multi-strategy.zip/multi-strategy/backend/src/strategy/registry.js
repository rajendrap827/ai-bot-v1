const { computeSignal } = require('./scoring');
const { computeBabaluSignal } = require('./babaluScoring');

/**
 * Strategy registry.
 *
 * Each entry pairs a strategyId with its signal function and the config
 * defaults it needs. Adding a strategy here is all that's required — the
 * worker, paper engine, tuner, API and dashboard all key off strategyId
 * and work unchanged.
 *
 * 'default'  — the strict Rayner/SMC strategy (6 weighted components,
 *              ADX + HTF + AOV + confirmation gates).
 * 'babalu'   — the loose EMA crossover/pullback scalper. Fewer filters on
 *              purpose, to test whether the strict gating helps or hurts.
 */
const STRATEGIES = {
  default: {
    id: 'default',
    name: 'Rayner SMC (strict)',
    compute: (candles, cfg, asset, htf) => computeSignal(candles, cfg, asset, htf),
    usesHtf: true,
    defaults: {
      emaFast: 9,
      emaSlow: 21,
      emaLen200: 200,
      atrLen: 14,
      adxLen: 14,
      adxMin: 18,
      srLookback: 20,
      structLen: 5,
      minScore: 4,
      netMargin: 1,
      cooldownBars: 5,
      slAtrMult: 1.5,
      rrRatio: 2.0,
      useSessionFilter: true,
      requireAreaOfValue: true,
      requireConfirmCandle: true,
      hybridLockPct: 0.5,
      hybridTrailStartR: 1.0,
      trailAtrMult: 1.25,
    },
  },

  babalu: {
    id: 'babalu',
    name: 'Babalu Universal Scalper (loose)',
    compute: (candles, cfg, asset) => computeBabaluSignal(candles, cfg, asset),
    usesHtf: false,
    defaults: {
      emaFast: 9,
      emaSlow: 21,
      ema200Len: 200,
      atrLen: 14,
      volMult: 1.5,
      rrRatio: 2.0,
      trailAtrMult: 1.5,
      cooldownBars: 5,
      useSessionFilter: false, // Pine default was Kill Zone off
      hybridLockPct: 0.5,
      hybridTrailStartR: 1.0,
    },
  },
};

function getStrategy(strategyId) {
  return STRATEGIES[strategyId] || STRATEGIES.default;
}

function allStrategyIds() {
  return Object.keys(STRATEGIES);
}

module.exports = { STRATEGIES, getStrategy, allStrategyIds };
