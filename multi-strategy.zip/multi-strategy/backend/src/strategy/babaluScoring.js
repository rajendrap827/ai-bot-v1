const { ema, atr } = require('./indicators');
const { getSession } = require('./stage');

/**
 * Babalu Universal Scalper — ported from the Pine indicator.
 *
 * Deliberately much looser than the main Rayner/SMC strategy: it has no
 * market-stage classification, no S/R zones, no SMC structure, no ADX or HTF
 * gate, and no minimum-score system. Entry is an EMA crossover (or an EMA
 * pullback) in the direction of the 200 EMA trend, confirmed by a volume spike.
 *
 * Running this alongside the strict strategy is the point: it answers
 * "do more filters actually help, or are they filtering out good trades?"
 * Both write to the same collections tagged by strategyId, so the tuner and
 * dashboard treat them separately.
 */
function computeBabaluSignal(candles, cfg, asset) {
  const n = candles.length;
  const ema200Len = cfg.ema200Len || 200;
  if (n < ema200Len + 5) return { signal: null, reason: 'warmup' };

  const closes = candles.map((c) => c.c);
  const emaFast = ema(closes, cfg.emaFast || 9);
  const emaSlow = ema(closes, cfg.emaSlow || 21);
  const ema200 = ema(closes, ema200Len);
  const atrSeries = atr(candles, cfg.atrLen || 14);

  const i = n - 2; // last CONFIRMED bar — same anti-repaint rule as the main strategy
  const row = candles[i];
  const prev = candles[i - 1];
  const a = atrSeries[i];
  if (a == null || a === 0) return { signal: null, reason: 'no_atr' };

  // ── Trend ──
  const bullTrend = row.c > ema200[i] && emaFast[i] > emaSlow[i];
  const bearTrend = row.c < ema200[i] && emaFast[i] < emaSlow[i];

  // ── Volume spike ──
  const volOk = row.v != null && row.v > 0;
  let avgVol = null;
  if (i >= 20) {
    let sum = 0;
    for (let j = i - 20; j < i; j++) sum += candles[j].v || 0;
    avgVol = sum / 20;
  }
  const volSpike = volOk && avgVol != null && row.v > avgVol * (cfg.volMult || 1.5);

  // ── Session (reuses the shared Dubai session windows) ──
  const sessionInfo = getSession(new Date(row.t));
  const sessionActive = cfg.useSessionFilter
    ? (asset === 'GOLD' ? sessionInfo.goldActive : sessionInfo.cryptoActive)
    : true;

  // ── Entries: crossover OR pullback ──
  const crossUp = emaFast[i - 1] <= emaSlow[i - 1] && emaFast[i] > emaSlow[i];
  const crossDown = emaFast[i - 1] >= emaSlow[i - 1] && emaFast[i] < emaSlow[i];

  const pullbackLong = bullTrend && row.c > emaFast[i] && prev.c < emaFast[i - 1];
  const pullbackShort = bearTrend && row.c < emaFast[i] && prev.c > emaFast[i - 1];

  const longSignal = bullTrend && crossUp && volSpike && sessionActive;
  const shortSignal = bearTrend && crossDown && volSpike && sessionActive;
  const longPB = pullbackLong && volSpike && sessionActive;
  const shortPB = pullbackShort && volSpike && sessionActive;

  const isLong = longSignal || longPB;
  const isShort = shortSignal || shortPB;
  const signal = isLong ? 'LONG' : isShort ? 'SHORT' : null;

  if (!signal) return { signal: null, reason: 'no_setup' };

  // ── SL / TP: pure ATR trail basis (matches the Pine trailing engine) ──
  const trailAmt = a * (cfg.trailAtrMult || 1.5);
  const entry = row.c;
  const sl = signal === 'LONG' ? entry - trailAmt : entry + trailAmt;
  const risk = Math.abs(entry - sl);
  const rr = cfg.rrRatio || 2.0;
  const tp1 = signal === 'LONG' ? entry + risk * rr : entry - risk * rr;
  const tp2 = signal === 'LONG' ? entry + risk * (rr + 1) : entry - risk * (rr + 1);

  const entryType = (longSignal || shortSignal) ? 'crossover' : 'pullback';

  // Checks are recorded in the same shape as the main strategy so the tuner,
  // fingerprinting and dashboard work identically for both.
  const checks = {
    stage: { passed: signal === 'LONG' ? bullTrend : bearTrend, weight: 1, value: signal === 'LONG' ? 'above_ema200' : 'below_ema200' },
    aov: { passed: entryType === 'pullback', weight: 1, value: entryType === 'pullback' ? 'ema_pullback' : 'none' },
    pattern: { passed: false, weight: 0, value: 'not_used' },
    ema: { passed: true, weight: 1, value: entryType === 'crossover' ? 'ema_crossover' : 'ema_aligned' },
    smc: { passed: false, weight: 0, value: 'not_used' },
    volume: { passed: volSpike, weight: 1, value: volSpike ? 'spike' : 'normal' },
  };

  const score = Object.values(checks).reduce((s, c) => s + (c.passed ? c.weight : 0), 0);
  const fingerprint = 'BAB-' + entryType.toUpperCase() + (volSpike ? '-VOL' : '');

  return {
    signal,
    time: row.t,
    entry,
    sl,
    tp1,
    tp2,
    atr: a,
    stage: signal === 'LONG' ? 'ADVANCING' : 'DECLINING', // simplified — Babalu has no stage model
    session: sessionInfo.name,
    htfTrend: 'NA', // Babalu deliberately has no HTF filter
    adx: 0,
    bullScore: signal === 'LONG' ? score : 0,
    bearScore: signal === 'SHORT' ? score : 0,
    score,
    oppScore: 0,
    netMargin: score,
    confirmationCandle: false,
    checks,
    setupFingerprint: fingerprint,
    entryType,
  };
}

module.exports = { computeBabaluSignal };
