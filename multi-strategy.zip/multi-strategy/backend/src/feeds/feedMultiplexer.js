/**
 * Fan-out layer between the single MetaApi feed and multiple strategy workers.
 *
 * The feed delivers one tick/candle stream per asset. With several strategies
 * running on the same asset, each needs its own copy of every event. This
 * multiplexer registers ONE handler with the feed per asset and forwards to
 * all subscribed strategy workers.
 *
 * Candle persistence is done by exactly one subscriber per asset (the first
 * to register), so multiple strategies don't write duplicate candle rows.
 */
function createFeedMultiplexer(feed) {
  const subscribers = {}; // asset -> [{ onClosedCandle, onTick }]
  const registered = {};  // asset -> bool

  function subscribe(asset, handlers) {
    if (!subscribers[asset]) subscribers[asset] = [];
    const isFirst = subscribers[asset].length === 0;
    subscribers[asset].push({ ...handlers, persistCandles: isFirst });

    if (!registered[asset]) {
      registered[asset] = true;
      feed.register(asset, {
        onClosedCandle: async (candle) => {
          for (const sub of subscribers[asset]) {
            try {
              await sub.onClosedCandle(candle, { persist: sub.persistCandles });
            } catch (err) {
              console.error(`[mux:${asset}] subscriber candle error:`, err.message);
            }
          }
        },
        onTick: async (tick) => {
          for (const sub of subscribers[asset]) {
            try {
              await sub.onTick(tick);
            } catch (err) {
              console.error(`[mux:${asset}] subscriber tick error:`, err.message);
            }
          }
        },
      });
    }
  }

  return { subscribe };
}

module.exports = { createFeedMultiplexer };
