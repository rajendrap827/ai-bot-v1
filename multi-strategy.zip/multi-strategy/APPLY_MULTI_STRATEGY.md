# Multi-Strategy Update — adds Babalu alongside the strict strategy

Both strategies now run in parallel on all three assets, sharing one MetaApi
feed. Everything is tagged with `strategyId`, so trades, tuning and dashboard
views stay cleanly separated.

| Strategy | id | Character |
|---|---|---|
| Rayner SMC | `default` | Strict — 6 weighted components, ADX + HTF + AOV + confirmation gates |
| Babalu Universal Scalper | `babalu` | Loose — EMA crossover/pullback + volume spike, no ADX/HTF/AOV gates |

Running both answers the real question: **do the extra filters help, or are
they filtering out good trades?**

## Files

| File | Action |
|---|---|
| `backend/src/strategy/babaluScoring.js` | **New.** Babalu signal logic (anti-repaint, same as main strategy). |
| `backend/src/strategy/registry.js` | **New.** Strategy registry — add future strategies here only. |
| `backend/src/feeds/feedMultiplexer.js` | **New.** Fans one asset feed out to multiple strategy workers. |
| `backend/src/workers/strategyWorker.js` | **New.** Generic per-(asset × strategy) worker. |
| `backend/src/engine/paperEngine.js` | **Replace.** Threads strategyId through open/manage/close. |
| `backend/src/index.js` | **Replace.** Starts every active strategy on every asset. |

`workers/metaApiWorker.js` is no longer used (superseded by strategyWorker).

## One manual patch

`backend/src/tuning/tuner.js` — the tuner already accepts a strategyId
parameter, but the config lookup needs it too. No change needed if your
`runTuningCycle(asset, strategyId)` signature already matches; the new
index.js calls it that way.

## .env (optional)

```
ACTIVE_STRATEGIES=default,babalu
```

Omit it and all registered strategies run. Set it to `default` alone to go
back to single-strategy mode.

## Restart

```
systemctl restart scalpbot
journalctl -u scalpbot -f
```

Expect six workers: `[BTC/default]`, `[BTC/babalu]`, `[ETH/default]`, and so on.

## Important: two strategies, two positions

Both strategies can hold a position on the same asset at once. On the demo
account that means two real orders — double exposure versus before. It's a
demo, so there's no money at risk, but the balance will move faster than a
single strategy would explain.

Babalu will almost certainly trade far more often than the strict strategy.
That's expected and is the entire point of the comparison. Judge them on
expectancy (average R), not on trade count.
