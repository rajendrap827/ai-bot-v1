# Demo Broker Orders — Update

Adds real order placement on your Exness **demo** account, alongside the
existing paper engine. Paper logging is unchanged — the self-tuner still
learns from the full reasoning recorded per trade. Broker orders are an
addition, so you can see actual fills, spread and slippage in the MT5 app.

## Files

| File | Action |
|---|---|
| `backend/src/execution/brokerExecution.js` | **New.** Order placement, lot sizing, demo-only safety checks. |
| `backend/src/engine/paperEngine.js` | **Replace.** Now mirrors open/partial-close/trail/close onto the broker. |
| `backend/src/index.js` | **Replace.** Wires broker execution in at startup. |

## Two small manual patches on the server

**1. Expose the connection from the feed** — in
`backend/src/feeds/metaApiFeed.js`, find the `return {` block near the end and
add one line inside it:

```js
  return {
    connection,          // <-- ADD THIS LINE
    register(asset, ...
```

**2. Add the broker field to the Trade model** — in
`backend/src/models/Trade.js`, add this just before `postMortem:`:

```js
  broker: {
    positionId: { type: String, default: null },
    symbol: { type: String, default: null },
    lots: { type: Number, default: null },
  },
```

## .env

Add:

```
BROKER_ORDERS_ENABLED=true
```

If this is missing or not exactly `true`, the bot runs paper-only and places
no broker orders.

## Safety behaviour

At startup the bot checks the connected account's type. If it is **not** a
demo account, broker execution stays disabled and a loud warning is logged,
regardless of `BROKER_ORDERS_ENABLED`. Trading a live account would have to
be a separate, deliberate change — it will not happen by accident.

A broker rejection (bad lot size, market closed, insufficient margin) is
logged and ignored; the paper trade continues normally either way.

## Lot sizing

The paper engine sizes by risk (1% of paper balance per trade). For the
broker, that risk is converted to lots using each symbol's contract size,
then snapped to the symbol's volume step and clamped to its min/max volume.
On small SL distances the broker minimum lot may represent more risk than 1%
of the paper balance — that's a broker constraint, not a bug, and it's one of
the useful things demo execution reveals.

## Restart

```
systemctl restart scalpbot
journalctl -u scalpbot -f
```

Look for: `[broker] execution ENABLED on DEMO account (balance: ...)` and
`broker orders: ENABLED (demo)` in the startup line.
