const { v4: uuidv4 } = require('uuid');
const Trade = require('../models/Trade');
const { BalanceLog } = require('../models/Config');
const broker = require('../execution/brokerExecution');

/**
 * Paper trading engine, now with optional broker mirroring.
 *
 * The paper side is unchanged and remains the source of truth for analysis:
 * every trade still records its full reasoning, and the self-tuner learns
 * from paper P&L. When broker execution is enabled (demo account only), the
 * same trades are additionally placed on the broker so real fills, spread
 * and slippage become visible in the MT5 app.
 *
 * A broker failure never affects the paper trade — they are independent.
 */

let brokerConn = null;   // MetaApi streaming connection, set at startup
let symbolMap = {};      // asset -> broker symbol

function attachBroker(connection, symbols) {
  brokerConn = connection;
  symbolMap = symbols || {};
}

function positionSize(entry, sl, balance, riskPerTrade) {
  const riskUsd = balance * riskPerTrade;
  const perUnit = Math.abs(entry - sl);
  if (perUnit <= 0) return { size: 0, riskUsd: 0 };
  return { size: riskUsd / perUnit, riskUsd };
}

async function currentBalance() {
  const latest = await BalanceLog.findOne({}).sort({ ts: -1 }).lean();
  return latest ? latest.balance : null;
}

async function adjustBalance(delta, reason, changedBy = 'engine') {
  const bal = (await currentBalance()) ?? 0;
  const newBal = bal + delta;
  await BalanceLog.create({ balance: newBal, changeReason: reason, changedBy });
  return newBal;
}

async function openTrade({ asset, timeframe, signal, cfg, paramsVersion, newsContext }) {
  const balance = (await currentBalance()) ?? cfg.paperBalance ?? 10000;
  const riskPerTrade = cfg.riskPerTrade ?? 0.01;
  const { size, riskUsd } = positionSize(signal.entry, signal.sl, balance, riskPerTrade);
  if (size <= 0) return null;

  const trade = await Trade.create({
    tradeId: uuidv4(),
    asset,
    timeframe,
    direction: signal.signal,
    paramsVersion,
    entryBasis: {
      marketStage: signal.stage,
      session: signal.session,
      htfTrend: signal.htfTrend,
      adx: signal.adx,
      checks: signal.checks,
      bullScore: signal.bullScore,
      bearScore: signal.bearScore,
      netMargin: signal.netMargin,
      confirmationCandle: signal.confirmationCandle,
      newsContext: newsContext || { highImpactEventNearby: false, events: [], blackoutActive: false },
    },
    prediction: {
      setupFingerprint: signal.setupFingerprint,
      predictedSuccessRate: null,
      expectedR: cfg.rrRatio || 2.0,
    },
    execution: {
      entryTime: new Date(signal.time),
      entryPrice: signal.entry,
      sl: signal.sl,
      tp1: signal.tp1,
      tp2: signal.tp2,
      size,
      riskUsd,
    },
    outcome: { status: 'OPEN' },
  });

  // ── Mirror onto the broker (demo only; failures are non-fatal) ──
  if (broker.isExecutionAllowed() && brokerConn && symbolMap[asset]) {
    const res = await broker.placeOrder(brokerConn, {
      symbol: symbolMap[asset],
      direction: signal.signal,
      entryPrice: signal.entry,
      sl: signal.sl,
      tp: signal.tp2, // broker-side safety net; our engine manages the real exit
      riskUsd,
      comment: `sb-${asset}-${signal.setupFingerprint || ''}`,
    });
    if (res && res.positionId) {
      trade.broker = { positionId: res.positionId, symbol: symbolMap[asset], lots: res.volume || null };
      await trade.save();
    }
  }

  return trade;
}

async function manageOpenTrades(asset, tickPrice, currentAtr, cfg) {
  const openTrades = await Trade.find({ asset, 'outcome.status': 'OPEN' });
  const lockPct = cfg.hybridLockPct ?? 0.5;
  const trailStartR = cfg.hybridTrailStartR ?? 1.0;
  const trailMult = cfg.trailAtrMult ?? 1.25;

  for (const trade of openTrades) {
    const { direction, execution, outcome } = trade;
    const entry = execution.entryPrice;
    const initialRisk = direction === 'LONG' ? entry - execution.sl : execution.sl - entry;
    if (initialRisk <= 0) continue;

    const favorableMove = direction === 'LONG' ? tickPrice - entry : entry - tickPrice;
    const rNow = favorableMove / initialRisk;
    const positionId = trade.broker && trade.broker.positionId;

    // ── Step 1: before TP1 ──
    if (!outcome.tp1Hit) {
      const tp1Hit = direction === 'LONG' ? tickPrice >= execution.tp1 : tickPrice <= execution.tp1;
      const slHit = direction === 'LONG' ? tickPrice <= execution.sl : tickPrice >= execution.sl;

      if (slHit) {
        await closeTrade(trade, tickPrice, 'SL', execution.size);
        if (positionId) await broker.closePosition(brokerConn, positionId);
        continue;
      }
      if (tp1Hit) {
        const closedSize = execution.size * lockPct;
        const pnl = direction === 'LONG'
          ? (tickPrice - entry) * closedSize
          : (entry - tickPrice) * closedSize;
        trade.outcome.tp1Hit = true;
        trade.outcome.tp1ClosedSize = closedSize;
        await adjustBalance(pnl, `trade:${trade.tradeId}:tp1_partial`);
        await trade.save();

        // Mirror the partial close on the broker
        if (positionId && trade.broker.lots) {
          const partialLots = parseFloat((trade.broker.lots * lockPct).toFixed(3));
          await broker.closePositionPartially(brokerConn, positionId, partialLots);
        }
      }
      continue;
    }

    // ── Step 2: post-TP1 remainder ──
    const remainingSize = execution.size - outcome.tp1ClosedSize;
    if (remainingSize <= 0) {
      await closeTradeFinal(trade, tickPrice, 'TP1_PARTIAL');
      if (positionId) await broker.closePosition(brokerConn, positionId);
      continue;
    }

    if (!outcome.trailingActive) {
      if (rNow >= trailStartR) {
        trade.outcome.trailingActive = true;
        trade.outcome.currentTrailStop = direction === 'LONG'
          ? tickPrice - currentAtr * trailMult
          : tickPrice + currentAtr * trailMult;
        await trade.save();
        if (positionId) await broker.modifyStopLoss(brokerConn, positionId, trade.outcome.currentTrailStop, execution.tp2);
      } else {
        const slHit = direction === 'LONG' ? tickPrice <= execution.sl : tickPrice >= execution.sl;
        if (slHit) {
          await closeTrade(trade, tickPrice, 'SL', remainingSize, true);
          if (positionId) await broker.closePosition(brokerConn, positionId);
        }
        continue;
      }
    }

    // ── Step 3: trailing stop (only ever tightens) ──
    const proposedStop = direction === 'LONG'
      ? tickPrice - currentAtr * trailMult
      : tickPrice + currentAtr * trailMult;

    let moved = false;
    if (direction === 'LONG' && proposedStop > trade.outcome.currentTrailStop) {
      trade.outcome.currentTrailStop = proposedStop;
      moved = true;
    } else if (direction === 'SHORT' && proposedStop < trade.outcome.currentTrailStop) {
      trade.outcome.currentTrailStop = proposedStop;
      moved = true;
    }
    if (moved) {
      await trade.save();
      if (positionId) await broker.modifyStopLoss(brokerConn, positionId, trade.outcome.currentTrailStop, execution.tp2);
    }

    const trailHit = direction === 'LONG'
      ? tickPrice <= trade.outcome.currentTrailStop
      : tickPrice >= trade.outcome.currentTrailStop;
    if (trailHit) {
      await closeTrade(trade, tickPrice, 'TRAIL_STOP', remainingSize, true);
      if (positionId) await broker.closePosition(brokerConn, positionId);
    }
  }
}

async function closeTrade(trade, exitPrice, reason, sizeClosed) {
  const { direction, execution } = trade;
  const entry = execution.entryPrice;
  const pnlOnThisPortion = direction === 'LONG'
    ? (exitPrice - entry) * sizeClosed
    : (entry - exitPrice) * sizeClosed;

  await adjustBalance(pnlOnThisPortion, `trade:${trade.tradeId}:${reason.toLowerCase()}`);

  const tp1Pnl = trade.outcome.tp1Hit
    ? (direction === 'LONG'
        ? (execution.tp1 - entry) * trade.outcome.tp1ClosedSize
        : (entry - execution.tp1) * trade.outcome.tp1ClosedSize)
    : 0;
  const totalPnl = tp1Pnl + pnlOnThisPortion;
  const initialRisk = Math.abs(entry - execution.sl) * execution.size;
  const rMultiple = initialRisk ? totalPnl / initialRisk : 0;
  const notional = entry * execution.size;

  trade.outcome.status = 'CLOSED';
  trade.outcome.exitTime = new Date();
  trade.outcome.exitPrice = exitPrice;
  trade.outcome.exitReason = reason;
  trade.outcome.pnlUsd = Math.round(totalPnl * 100) / 100;
  trade.outcome.pnlPct = notional > 0 ? Math.round((totalPnl / notional) * 10000) / 100 : 0;
  trade.outcome.rMultiple = Math.round(rMultiple * 100) / 100;
  trade.outcome.predictionCorrect = totalPnl > 0;
  await trade.save();
}

async function closeTradeFinal(trade, exitPrice, reason) {
  trade.outcome.status = 'CLOSED';
  trade.outcome.exitTime = new Date();
  trade.outcome.exitPrice = exitPrice;
  trade.outcome.exitReason = reason;
  await trade.save();
}

module.exports = {
  positionSize,
  currentBalance,
  adjustBalance,
  openTrade,
  manageOpenTrades,
  attachBroker,
};
