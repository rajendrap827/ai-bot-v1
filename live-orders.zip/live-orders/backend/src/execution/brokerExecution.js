/**
 * Broker order execution via MetaApi.
 *
 * This places REAL orders on the connected MetaTrader account. It runs
 * alongside the paper engine — the paper engine still records the full
 * reasoning for every trade (that's what the self-tuner learns from);
 * this module additionally mirrors those trades onto the broker so you
 * can see actual fills, spread and slippage in the MT5 app.
 *
 * SAFETY: orders are placed ONLY when both are true:
 *   1. BROKER_ORDERS_ENABLED=true in .env
 *   2. the connected account reports itself as a DEMO account
 * If the account is not demo, execution is disabled and a loud warning is
 * logged. This is deliberate — the same code path would otherwise trade
 * real money if live credentials ever ended up in .env.
 */

let executionAllowed = false;
let accountInfo = null;

/**
 * Validates the account is demo and execution is enabled. Call once at startup.
 */
async function initBrokerExecution(connection) {
  const enabled = String(process.env.BROKER_ORDERS_ENABLED || '').toLowerCase() === 'true';
  if (!enabled) {
    console.log('[broker] BROKER_ORDERS_ENABLED is not true — running in paper-only mode (no broker orders).');
    executionAllowed = false;
    return false;
  }

  try {
    accountInfo = connection.terminalState.accountInformation;
    // MetaApi exposes account type; treat anything not explicitly demo as unsafe.
    const type = (accountInfo && accountInfo.type) || '';
    const isDemo = /demo/i.test(type);

    if (!isDemo) {
      console.error('='.repeat(70));
      console.error('[broker] REFUSING TO PLACE ORDERS: account type is "' + type + '", not DEMO.');
      console.error('[broker] Broker execution stays disabled. If you intend to trade a live');
      console.error('[broker] account, that must be a deliberate, separate decision.');
      console.error('='.repeat(70));
      executionAllowed = false;
      return false;
    }

    console.log(`[broker] execution ENABLED on DEMO account (balance: ${accountInfo.balance} ${accountInfo.currency})`);
    executionAllowed = true;
    return true;
  } catch (err) {
    console.error('[broker] could not verify account type — execution disabled:', err.message);
    executionAllowed = false;
    return false;
  }
}

/**
 * Converts the paper engine's risk-based unit size into broker lots.
 *
 * The paper engine sizes so that hitting SL loses exactly riskUsd. Brokers
 * trade in lots with per-symbol contract sizes and step/min constraints, so
 * we compute lots from risk and then clamp to what the symbol allows.
 */
async function computeLots(connection, symbol, entryPrice, slPrice, riskUsd) {
  let spec;
  try {
    spec = connection.terminalState.specification(symbol);
  } catch (err) {
    spec = null;
  }

  const contractSize = (spec && spec.contractSize) || 1;
  const minVolume = (spec && spec.minVolume) || 0.01;
  const maxVolume = (spec && spec.maxVolume) || 100;
  const volumeStep = (spec && spec.volumeStep) || 0.01;

  const priceDistance = Math.abs(entryPrice - slPrice);
  if (priceDistance <= 0) return null;

  // Loss for 1 lot if SL is hit = priceDistance * contractSize
  const lossPerLot = priceDistance * contractSize;
  if (lossPerLot <= 0) return null;

  let lots = riskUsd / lossPerLot;

  // Snap to the symbol's volume step, then clamp to min/max
  lots = Math.floor(lots / volumeStep) * volumeStep;
  lots = Math.max(minVolume, Math.min(maxVolume, lots));
  lots = parseFloat(lots.toFixed(3));

  return { lots, minVolume, volumeStep, contractSize };
}

/**
 * Places a market order mirroring a paper trade. Returns the broker order
 * result (with positionId) or null if execution is disabled/failed.
 */
async function placeOrder(connection, { symbol, direction, entryPrice, sl, tp, riskUsd, comment }) {
  if (!executionAllowed) return null;

  try {
    const sizing = await computeLots(connection, symbol, entryPrice, sl, riskUsd);
    if (!sizing) {
      console.error(`[broker] could not compute lots for ${symbol} — skipping broker order`);
      return null;
    }

    const { lots } = sizing;
    const opts = { comment: (comment || 'scalpbot').slice(0, 26) };

    const result = direction === 'LONG'
      ? await connection.createMarketBuyOrder(symbol, lots, sl, tp, opts)
      : await connection.createMarketSellOrder(symbol, lots, sl, tp, opts);

    console.log(`[broker] ${direction} ${lots} lots ${symbol} placed — positionId ${result.positionId}`);
    return result;
  } catch (err) {
    // A broker rejection must never take down the paper engine.
    console.error(`[broker] order failed for ${symbol}:`, err.message);
    return null;
  }
}

/** Closes a broker position (used when the paper engine exits a trade). */
async function closePosition(connection, positionId) {
  if (!executionAllowed || !positionId) return null;
  try {
    const result = await connection.closePosition(positionId, {});
    console.log(`[broker] closed position ${positionId}`);
    return result;
  } catch (err) {
    console.error(`[broker] failed to close position ${positionId}:`, err.message);
    return null;
  }
}

/** Partially closes a broker position (used for the 50% TP1 profit lock). */
async function closePositionPartially(connection, positionId, lots) {
  if (!executionAllowed || !positionId) return null;
  try {
    const result = await connection.closePositionPartially(positionId, lots, {});
    console.log(`[broker] partially closed ${lots} lots of position ${positionId}`);
    return result;
  } catch (err) {
    console.error(`[broker] partial close failed for ${positionId}:`, err.message);
    return null;
  }
}

/** Moves the stop-loss on an open broker position (used by the trailing stop). */
async function modifyStopLoss(connection, positionId, newSl, tp) {
  if (!executionAllowed || !positionId) return null;
  try {
    const result = await connection.modifyPosition(positionId, newSl, tp);
    return result;
  } catch (err) {
    console.error(`[broker] failed to modify SL on ${positionId}:`, err.message);
    return null;
  }
}

function isExecutionAllowed() {
  return executionAllowed;
}

module.exports = {
  initBrokerExecution,
  placeOrder,
  closePosition,
  closePositionPartially,
  modifyStopLoss,
  computeLots,
  isExecutionAllowed,
};
