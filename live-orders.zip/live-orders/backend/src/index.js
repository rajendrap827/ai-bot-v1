const env = require('./config/env');
const { connectDB } = require('./config/db');
const { seedInitialBalance } = require('./config/bootstrap');
const { startChangeStreamWatchers } = require('./events/changeStreamWatcher');
const { createServer } = require('./api/server');
const { startMetaApiFeed } = require('./feeds/metaApiFeed');
const { startMetaApiWorker } = require('./workers/metaApiWorker');
const { runTuningCycle } = require('./tuning/tuner');
const { initBrokerExecution } = require('./execution/brokerExecution');
const { attachBroker } = require('./engine/paperEngine');

const TUNING_INTERVAL_MS = 24 * 60 * 60 * 1000;

const SYMBOLS = {
  BTC: process.env.SYMBOL_BTC || 'BTCUSDm',
  ETH: process.env.SYMBOL_ETH || 'ETHUSDm',
  GOLD: process.env.SYMBOL_GOLD || 'XAUUSDm',
};

async function main() {
  await connectDB();
  await seedInitialBalance();
  startChangeStreamWatchers();

  const { httpServer } = createServer();
  httpServer.listen(env.port, () => console.log(`[api] listening on port ${env.port}`));

  if (!process.env.METAAPI_TOKEN || !process.env.METAAPI_ACCOUNT_ID) {
    console.error('[main] METAAPI_TOKEN and METAAPI_ACCOUNT_ID must be set in .env — cannot start feeds.');
    return;
  }

  const feed = await startMetaApiFeed({
    token: process.env.METAAPI_TOKEN,
    accountId: process.env.METAAPI_ACCOUNT_ID,
    symbols: SYMBOLS,
  });

  // Broker execution: mirrors paper trades onto the DEMO account so real
  // fills, spread and slippage show up in the MT5 app. Refuses to run on a
  // non-demo account regardless of configuration.
  const brokerReady = await initBrokerExecution(feed.connection);
  if (brokerReady) {
    attachBroker(feed.connection, SYMBOLS);
  }

  await startMetaApiWorker('BTC', feed);
  await startMetaApiWorker('ETH', feed);
  await startMetaApiWorker('GOLD', feed);

  setInterval(async () => {
    for (const asset of ['BTC', 'ETH', 'GOLD']) {
      try {
        const result = await runTuningCycle(asset);
        console.log(result.skipped ? `[tuner:${asset}] skipped — ${result.reason}` : `[tuner:${asset}] reviewed ${result.decisions.length} component(s)`);
      } catch (err) {
        console.error(`[tuner:${asset}] error:`, err.message);
      }
    }
  }, TUNING_INTERVAL_MS);

  console.log(`[main] all systems started (Exness via MetaApi) — broker orders: ${brokerReady ? 'ENABLED (demo)' : 'disabled (paper only)'}`);
}

main().catch((err) => {
  console.error('[main] fatal startup error:', err);
  process.exit(1);
});
