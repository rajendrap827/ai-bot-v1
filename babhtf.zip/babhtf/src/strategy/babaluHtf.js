const { computeBabaluSignal } = require('./babaluScoring');

/**
 * Babalu + HTF bias (strategyId 'babhtf') - BTC only.
 *
 * Exactly Babalu (same entries, SL 1.5 ATR, hybrid exits) plus one filter: the previous completed
 * 15m bar must agree with the trade: EMA9 > EMA15, EMA9 slope over 3 bars >= 0.135 x ATR(14) per bar,
 * close > EMA15 (short: mirror). Same bias as the swing strategies.
 *
 * Backtest 5m 2020-01 -> 2025-09 (variant B1): BTC +0.223R, 2020-23 +0.316, 2024+ +0.138.
 * Pre-registered holdout 2025-10-01 -> 2026-10-08: BTC +0.238R, 106 trades, max DD -9.1R -> passed.
 * Rules frozen 2026-10-12. Gold and ETH failed the same test, so they are not traded.
 */
const TF15 = 15 * 60000;

// Pine-like EMA (SMA seed) and ATR (RMA, SMA seed), same as the backtester
function emaSma(src, len) {
  const out = new Array(src.length).fill(null); const a = 2 / (len + 1); let sum = 0;
  for (let i = 0; i < src.length; i++) {
    if (i < len) { sum += src[i]; if (i === len - 1) out[i] = sum / len; } else out[i] = a * src[i] + (1 - a) * out[i - 1];
  }
  return out;
}
function atrRma(h, l, c, len) {
  const out = new Array(c.length).fill(null); let sum = 0;
  for (let i = 0; i < c.length; i++) {
    const tr = i === 0 ? h[i] - l[i] : Math.max(h[i] - l[i], Math.abs(h[i] - c[i - 1]), Math.abs(l[i] - c[i - 1]));
    if (i < len) { sum += tr; if (i === len - 1) out[i] = sum / len; } else out[i] = (out[i - 1] * (len - 1) + tr) / len;
  }
  return out;
}

// bias of the previous completed 15m bar for 5m bar i: 1 up, -1 down, 0 none
function bias15(candles, i, thr = 0.135, lb = 3) {
  const keyOf = (c) => Math.floor(new Date(c.t).getTime() / TF15) * TF15;
  const curKey = keyOf(candles[i]);
  const H = [], L = [], C = [];
  let key = null;
  for (let j = 0; j <= i; j++) {
    const k = keyOf(candles[j]);
    if (k >= curKey) break; // only completed 15m bars
    if (k !== key) { key = k; H.push(candles[j].h); L.push(candles[j].l); C.push(candles[j].c); }
    else { const n = H.length - 1; if (candles[j].h > H[n]) H[n] = candles[j].h; if (candles[j].l < L[n]) L[n] = candles[j].l; C[n] = candles[j].c; }
  }
  // the first bucket may be partial (window start) - drop it
  H.shift(); L.shift(); C.shift();
  const k = C.length - 1;
  if (k < 30) return 0;
  const e9 = emaSma(C, 9), e15 = emaSma(C, 15), a = atrRma(H, L, C, 14);
  if (e9[k] == null || e9[k - lb] == null || !(a[k] > 0)) return 0;
  const s = (e9[k] - e9[k - lb]) / (lb * a[k]);
  if (e9[k] > e15[k] && s >= thr && C[k] > e15[k]) return 1;
  if (e9[k] < e15[k] && s <= -thr && C[k] < e15[k]) return -1;
  return 0;
}

function computeBabaluHtfSignal(candles, cfg, asset) {
  if (asset !== 'BTC') return { signal: null, reason: 'btc_only' };
  const s = computeBabaluSignal(candles, cfg, asset);
  if (!s || !s.signal) return s;
  const b = bias15(candles, candles.length - 2); // same confirmed bar as Babalu
  const dir = s.signal === 'LONG' ? 1 : -1;
  if (b !== dir) return { signal: null, reason: 'htf15_against' };
  s.htfTrend = dir === 1 ? 'UP' : 'DOWN';
  s.setupFingerprint = 'BABH-' + String(s.entryType || '').toUpperCase();
  return s;
}

module.exports = { computeBabaluHtfSignal, bias15 };
