/**
 * Registers 'babhtf' (Babalu + 15m HTF bias, BTC only) in registry.js. babalu itself is untouched.
 * Idempotent, writes registry.js.bak-babhtf, refuses if an anchor is missing.
 * Usage: node babhtf/patch_babhtf.js [path-to-backend]
 */
const fs = require('fs');
const path = require('path');

const backend = process.argv[2] || '/root/ai-bot-v1/scalp-bot/backend';
const file = path.join(backend, 'src/strategy/registry.js');
let s = fs.readFileSync(file, 'utf8');
if (s.includes('babhtf:')) { console.log('SKIP registry.js - babhtf already registered'); process.exit(0); }

const reqAnchor = "const { computeBabaluSignal } = require('./babaluScoring');";
const endAnchor = '\n};\n\nfunction getStrategy';
const count = (a) => s.split(a).length - 1;
if (count(reqAnchor) !== 1 || count(endAnchor) !== 1) { console.error('FAIL registry.js - anchors not found exactly once. Nothing changed.'); process.exit(1); }

const entry = `

  // ── Babalu + 15m HTF bias, BTC only. Rules frozen 2026-10-12 (backtest B1 + holdout passed) ──
  babhtf: {
    id: 'babhtf',
    name: 'Babalu + 15m HTF bias (BTC)',
    compute: (candles, cfg, asset) => computeBabaluHtfSignal(candles, cfg, asset),
    usesHtf: false,
    assets: ['BTC'],
    window: 1000,
    defaults: {
      emaFast: 9,
      emaSlow: 21,
      ema200Len: 200,
      atrLen: 14,
      volMult: 1.5,
      rrRatio: 2.0,
      trailAtrMult: 1.5,
      cooldownBars: 5,
      useSessionFilter: false,
      hybridLockPct: 0.5,
      hybridTrailStartR: 1.0,
    },
  },`;

fs.writeFileSync(file + '.bak-babhtf', s);
s = s.replace(reqAnchor, reqAnchor + "\nconst { computeBabaluHtfSignal } = require('./babaluHtf');");
s = s.replace(endAnchor, entry + endAnchor);
fs.writeFileSync(file, s);
console.log('OK   registry.js (backup: registry.js.bak-babhtf)');
console.log('Done. Restart: systemctl restart scalpbot');
