# Babalu + 15m HTF bias (strategyId: babhtf) - BTC only

New, separate strategy. babalu, default, mmt and the Gold-short tests are untouched.

Rules frozen 2026-10-12: Babalu exactly (entries, SL 1.5 ATR, 50% at 2R, ATR trail after 1R),
plus the previous completed 15m bar must agree (EMA9 vs EMA15, slope >= 0.135, close vs EMA15).
Backtest 2020-01 -> 2025-09: +0.223R; pre-registered holdout 2025-10 -> 2026-10: +0.238R (106 trades).

Install (from ~/ai-bot-v1, after uploading babhtf.zip):
  git pull && unzip -o babhtf.zip && cp babhtf/src/strategy/babaluHtf.js scalp-bot/backend/src/strategy/ && node babhtf/patch_babhtf.js && systemctl restart scalpbot

If ACTIVE_STRATEGIES is set in .env it must include babhtf.
Verify: sleep 30 && journalctl -u scalpbot -n 80 --no-pager | grep -E "babhtf|strategies"
Expect a [BTC/babhtf] worker, and GOLD/ETH "not used ... skipped".

Review after 3 months (start = this restart), net of spread: pass = avg >= +0.10R and positive in 2 of 3 months.
