# Tuner Fix — the tuner could only ever move weights DOWN

## The bug

After 8 days and 229 closed trades the tuner had made **zero** weight changes.
Looking at the log showed why:

```
ETH aov: shrunk -0.082 vs global -0.285 -> "not meaningfully different"
```

That gap is 0.203R, and the threshold is 0.1R. It *was* meaningfully
different — this should have been a `restore`.

The restore branch read:

```js
} else if (shrunkExpectancy > globalExpectancy + 0.1 && weightBefore < 1) {
```

Every weight starts at 1.0, so `weightBefore < 1` was never true. A component
that genuinely helped could never be rewarded — the tuner could only ever
punish. And when that branch fell through, it logged "not meaningfully
different", which was flatly untrue and made the log actively misleading.

## What changed

- **Weights may now rise above 1.0**, up to a ceiling of 1.5. Useful
  components can actually be trusted more, not just less.
- **Reasons now state the real cause.** "Already at the ceiling" and "already
  at the floor" are reported as such rather than disguised as "no difference".
- **Components that fire on nearly every trade are called out explicitly.**
  `stage` and `ema` fire on 100% of Babalu trades, so their expectancy equals
  the global by construction — there is nothing to compare. The log now says
  that instead of pretending a comparison happened.

## Files

| File | Action |
|---|---|
| `backend/src/tuning/tuner.js` | **Replace.** |

## Apply

```
cd ~/ai-bot-v1 && cp tuner-fix/backend/src/tuning/tuner.js scalp-bot/backend/src/tuning/
systemctl restart scalpbot
```

## Check the weights schema

If `models/Config.js` constrains weights (e.g. `max: 1`), 1.5 will not save.
Verify with:

```
grep -A3 "WeightsSchema" ~/ai-bot-v1/scalp-bot/backend/src/models/Config.js
```

Plain `{ type: Number, default: 1 }` is fine — no change needed.

## What to expect

The tuner runs daily. On its next cycle ETH's `aov` should move 1.0 -> 1.3
with a clear reason. `stage` and `ema` will keep reporting that they can't be
evaluated — that is a property of the strategy, not a fault.

Verify a few days later:

```
docker exec mongo mongosh scalpbot --quiet --eval "db.tuninglogs.find({action:{\$in:['decay','restore']}},{asset:1,component:1,action:1,weightBefore:1,weightAfter:1,reason:1,_id:0}).toArray()"
```
