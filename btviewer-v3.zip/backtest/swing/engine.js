/**
 * Swing MTF Zones strategy (sw5 / sw15 / sw30 / sw1h) - JS port of the Pine indicator v4.
 * v4 (2026-10-09, decided from diagnostics only): breakout SL beyond the broken zone / line;
 * target levels closer than 1R are skipped instead of skipping the trade.
 * Rules frozen 2026-10-08. Same bar-by-bar order as the Pine script:
 *   swing points -> zones -> trendlines -> trendline break -> manage open trade -> new signal
 * Entry at the signal bar close; exits checked from the next bar, SL first.
 */
const { TF_MS, ema, atr: atrFn, pivots, rolling, biasSeries } = require('./lib');

const DEFAULTS = {
  slopeLb: 3, slopeThr: 0.135,
  pivLen: 10, lookback: 1440, zoneAtr: 0.5, minTouch: 3, reactAtr: 1.5, touchGap: 20,
  maxZones: 6, maxCross: 2, armBars: 5, tlTolAtr: 0.3, tlPivots: 6,
  slPiv: 3, slBufAtr: 0.2, minStop: 0.5, maxStop: 3.0, minT1R: 1.0,
  // v5 pullback entry (entryMode 'pullback'): wait up to pbBars for low <= EMA9 + pbTouchAtr x ATR
  // within the last pbLook bars, then a rejection candle closing beyond both EMAs
  entryMode: 'direct', pbBars: 20, pbTouchAtr: 0.25, pbLook: 3,
};

const DAY = 86400000;
// swap multipliers by UTC weekday of the day that ends at the rollover (0=Sun..6=Sat)
const SWAP_MULT = {
  GOLD: [0, 1, 1, 3, 1, 1, 0],
  BTC: [0, 1, 1, 1, 1, 3, 0],
  ETH: [0, 1, 1, 1, 1, 3, 0],
};

function run(b, opts) {
  const P = { ...DEFAULTS, ...(opts.params || {}) };
  const { tf, htf, asset, fromMs = -Infinity, toMs = Infinity } = opts;
  const spread = opts.spread || 0;
  const swapLong = opts.swapLong || 0;
  const swapMult = SWAP_MULT[asset] || [0, 1, 1, 1, 1, 1, 0];
  const n = b.n;
  const { t, o, h, l, c } = b;

  // ---- series
  const A = atrFn(b, 14);
  const E9 = ema(c, 9), E15 = ema(c, 15);
  const PH = pivots(h, P.pivLen, true), PL = pivots(l, P.pivLen, false);
  const PH3 = pivots(h, P.slPiv, true), PL3 = pivots(l, P.slPiv, false);
  const lowAfter = rolling(l, P.pivLen, true), highAfter = rolling(h, P.pivLen, false);
  const lowArm = rolling(l, P.armBars, true), highArm = rolling(h, P.armBars, false);
  const low3 = rolling(l, 3, true), high3 = rolling(h, 3, false);
  const bias = biasSeries(b, TF_MS[htf], P.slopeLb, P.slopeThr);
  // trend context on every higher timeframe (for the trade log: was the trade against a bigger trend?)
  const ctxTfs = ['15m', '1h', '4h', '1d'].filter((x) => TF_MS[x] > TF_MS[tf]);
  const ctx = {};
  for (const x of ctxTfs) ctx[x] = x === htf ? bias : biasSeries(b, TF_MS[x], P.slopeLb, P.slopeThr);
  const ctxAt = (i) => {
    const r = {};
    for (const x of ctxTfs) r[x] = { state: ctx[x].state[i], slope: round(ctx[x].slope[i], 3) };
    return r;
  };

  // ---- state
  let lastPL3 = NaN, lastPH3 = NaN;
  const phP = [], phB = [], plP = [], plB = [];
  let zones = [];
  let tlDn = null, tlUp = null;              // {x, y, m, t}
  let brUp = { bar: -1e9 }, brDn = { bar: -1e9 };
  let pos = null;
  let armed = null;                           // v5: setup waiting for a pullback
  const trades = [];
  const setups = [];                          // every setup with a confirmation candle (diagnostics)
  const diag = { bars: 0, biasUp: 0, biasDn: 0, zoneSum: 0, tlBreaks: 0, cSet: 0, cBig: 0, cNear: 0,
    armed: 0, pbCancelBias: 0, pbCancelSL: 0, pbExpired: 0 };

  for (let i = 0; i < n; i++) {
    const a = A[i];
    const atrOk = a > 0;
    if (Number.isFinite(PL3[i])) lastPL3 = PL3[i];
    if (Number.isFinite(PH3[i])) lastPH3 = PH3[i];

    // ---- swing points that really rejected
    let changed = false;
    if (Number.isFinite(PH[i]) && atrOk && PH[i] - lowAfter[i] >= P.reactAtr * a) { phP.push(PH[i]); phB.push(i - P.pivLen); changed = true; }
    if (Number.isFinite(PL[i]) && atrOk && highAfter[i] - PL[i] >= P.reactAtr * a) { plP.push(PL[i]); plB.push(i - P.pivLen); changed = true; }
    while (phB.length && phB[0] < i - P.lookback) { phB.shift(); phP.shift(); changed = true; }
    while (plB.length && plB[0] < i - P.lookback) { plB.shift(); plP.shift(); changed = true; }
    const recalc = changed && atrOk;

    // ---- zones
    if (recalc) {
      const tol = P.zoneAtr * a;
      const Pp = phP.concat(plP), Bb = phB.concat(plB);
      const nP = Pp.length;
      const built = [];
      if (nP >= P.minTouch) {
        const idx = [...Pp.keys()].sort((x, y) => Pp[x] - Pp[y] || x - y);
        let ii = 0;
        while (ii < nP) {
          let j = ii;
          while (j + 1 < nP && Pp[idx[j + 1]] - Pp[idx[ii]] <= 2 * tol) j++;
          if (j - ii + 1 >= P.minTouch) {
            const bars = [];
            for (let k = ii; k <= j; k++) bars.push(Bb[idx[k]]);
            bars.sort((x, y) => x - y);
            let cnt = 1, prevB = bars[0];
            for (let k = 1; k < bars.length; k++) if (bars[k] - prevB >= P.touchGap) { cnt++; prevB = bars[k]; }
            if (cnt >= P.minTouch) {
              const cen = (Pp[idx[ii]] + Pp[idx[j]]) / 2;
              const zn = { top: cen + tol, bottom: cen - tol, touches: cnt, firstBar: bars[0], lastBar: bars[bars.length - 1] };
              const pz = built[built.length - 1];
              if (pz && zn.bottom <= pz.top) {
                if (zn.touches > pz.touches || (zn.touches === pz.touches && zn.lastBar > pz.lastBar)) built[built.length - 1] = zn;
              } else built.push(zn);
              ii = j + 1;
            } else ii++;
          } else ii++;
        }
      }
      const valid = [];
      for (const zk of built) {
        let sd = 0, crosses = 0;
        for (let j = zk.firstBar; j <= i; j++) {
          const ns = c[j] > zk.top ? 1 : c[j] < zk.bottom ? -1 : 0;
          if (ns !== 0) { if (sd !== 0 && ns !== sd) crosses++; sd = ns; }
        }
        if (crosses <= P.maxCross) valid.push(zk);
      }
      valid.sort((x, y) => (y.touches * 1e7 + y.lastBar) - (x.touches * 1e7 + x.lastBar));
      zones = valid.slice(0, P.maxZones);
    }

    // ---- trendlines
    if (recalc) {
      const tol2 = P.tlTolAtr * a;
      tlDn = findLine(P, c, i, phP, phB, true, tol2);
      tlUp = findLine(P, c, i, plP, plB, false, tol2);
    }
    // ---- trendline break (each line breaks once)
    const tolNow = P.tlTolAtr * a;
    if (tlDn) {
      const v = tlDn.y + tlDn.m * (i - tlDn.x);
      if (c[i] > v + tolNow) { brUp = { bar: i, ...tlDn }; tlDn = null; diag.tlBreaks++; }
    }
    if (tlUp) {
      const v = tlUp.y + tlUp.m * (i - tlUp.x);
      if (c[i] < v - tolNow) { brDn = { bar: i, ...tlUp }; tlUp = null; diag.tlBreaks++; }
    }

    // ---- manage open trade
    if (pos && i > pos.bar) {
      // swap for every rollover (00:00 UTC) between the previous bar and this one, longs only
      if (pos.dir === 1 && swapLong > 0) {
        const d0 = Math.floor(t[i - 1] / DAY), d1 = Math.floor(t[i] / DAY);
        for (let d = d0; d < d1; d++) {
          const wd = new Date(d * DAY).getUTCDay();
          pos.swapR += (swapLong * swapMult[wd] * pos.remain) / pos.risk;
        }
      }
      const buf = P.slBufAtr * a;
      const dir = pos.dir;
      pos.mfe = Math.max(pos.mfe, dir === 1 ? (h[i] - pos.entry) / pos.risk : (pos.entry - l[i]) / pos.risk);
      pos.mae = Math.min(pos.mae, dir === 1 ? (l[i] - pos.entry) / pos.risk : (pos.entry - h[i]) / pos.risk);
      const hitSL = dir === 1 ? l[i] <= pos.sl : h[i] >= pos.sl;
      if (hitSL) {
        const px = dir === 1 ? Math.min(o[i], pos.sl) : Math.max(o[i], pos.sl);
        const part = pos.remain * (dir === 1 ? px - pos.entry : pos.entry - px) / pos.risk;
        pos.events.push({ type: 'EXIT', t: t[i], price: px, frac: pos.remain, r: round(part, 3), reason: pos.slReason });
        closeTrade(pos, i, px, part, pos.slReason);
        pos = null;
      } else {
        let newSL = pos.sl, reason = null;
        const better = (x) => (dir === 1 ? x > newSL : x < newSL);
        const lv = pos.levels;
        if (pos.stage === 0 && (dir === 1 ? h[i] >= lv[0] : l[i] <= lv[0])) {
          const r = 0.25 * (dir === 1 ? lv[0] - pos.entry : pos.entry - lv[0]) / pos.risk;
          pos.booked += r; pos.stage = 1; pos.remain = 0.75;
          pos.events.push({ type: 'T1', t: t[i], price: lv[0], frac: 0.25, r: round(r, 3) });
          if (better(pos.entry)) { newSL = pos.entry; reason = 'breakeven'; }
        }
        if (pos.stage === 1 && (dir === 1 ? h[i] >= lv[1] : l[i] <= lv[1])) {
          const r = 0.25 * (dir === 1 ? lv[1] - pos.entry : pos.entry - lv[1]) / pos.risk;
          pos.booked += r; pos.stage = 2; pos.remain = 0.5;
          pos.events.push({ type: 'T2', t: t[i], price: lv[1], frac: 0.25, r: round(r, 3) });
          const x = dir === 1 ? lv[0] - buf : lv[0] + buf;
          if (better(x)) { newSL = x; reason = 'step'; }
        }
        if (pos.stage === 2) {
          while (pos.next < lv.length && (dir === 1 ? h[i] >= lv[pos.next] : l[i] <= lv[pos.next])) {
            const x = dir === 1 ? lv[pos.next - 1] - buf : lv[pos.next - 1] + buf;
            if (better(x)) { newSL = x; reason = 'step'; }
            pos.next++;
          }
          if (pos.next >= lv.length) {
            const pv = dir === 1 ? PL3[i] : PH3[i];
            if (Number.isFinite(pv)) {
              const x = dir === 1 ? pv - buf : pv + buf;
              if (better(x)) { newSL = x; reason = 'structure'; }
            }
          }
        }
        if (reason) {
          pos.events.push({ type: 'SL_MOVE', t: t[i], from: pos.sl, to: newSL, reason });
          pos.sl = newSL; pos.slReason = reason;
        }
      }
    }

    // ---- diagnostics of the environment (inside the trading window)
    const inWindow = t[i] >= fromMs && t[i] <= toMs;
    if (inWindow) {
      diag.bars++;
      if (bias.state[i] === 1) diag.biasUp++;
      else if (bias.state[i] === -1) diag.biasDn++;
      diag.zoneSum += zones.length;
    }

    // ---- new signal
    if (!pos && inWindow && atrOk && i > 0) {
      if (P.entryMode === 'pullback' && armed) pos = pullbackEntry(i);
      // a new setup (re)arms; in direct mode it enters immediately
      if (!pos) {
        const s = bias.state[i] === 1 ? signal(i, 1) : bias.state[i] === -1 ? signal(i, -1) : null;
        if (s) pos = s;
      }
    } else if (pos) armed = null;
  }

  function signal(i, dir) {
    const a = A[i];
    const tolNow = P.tlTolAtr * a;
    const emaOk = dir === 1 ? c[i] > E9[i] && c[i] > E15[i] : c[i] < E9[i] && c[i] < E15[i];
    let setup = '', pinTouch = false, zone = null;
    const br = dir === 1 ? brUp : brDn;
    const lineNow = br.bar > -1e9 ? br.y + br.m * (i - br.x) : NaN;
    if (i - br.bar < P.armBars && (dir === 1 ? c[i] > lineNow + tolNow : c[i] < lineNow - tolNow) && emaOk) {
      setup = dir === 1 ? 'TL_BO' : 'TL_BD';
    } else if (zones.length) {
      let best = NaN;
      for (const z of zones) {
        const touched = dir === 1 ? c[i] > z.top && lowArm[i] <= z.top : c[i] < z.bottom && highArm[i] >= z.bottom;
        if (!touched) continue;
        let side = 0;
        for (let k = P.armBars; k <= 200; k++) {
          const j = i - k;
          if (j < 0) break;
          if (dir === 1) {
            if (c[j] > z.top) { side = 1; break; }
            if (c[j] < z.bottom) { side = -1; break; }
          } else {
            if (c[j] < z.bottom) { side = -1; break; }
            if (c[j] > z.top) { side = 1; break; }
          }
        }
        const span = i - z.lastBar - 1;
        // two consecutive closes beyond a level since the zone's last touch
        const brokenBeyond = (above) => {
          let run = 0;
          for (let k = 1; k <= span; k++) {
            const x = c[i - k];
            if (above ? x > z.top : x < z.bottom) { run++; if (run >= 2) return true; } else run = 0;
          }
          return false;
        };
        let typ = '';
        if (dir === 1) {
          if (side === 1) typ = brokenBeyond(false) ? '' : 'BOUNCE';
          else if (side === -1) typ = brokenBeyond(true) ? '' : 'ZONE_BO';
          if (typ && (Number.isNaN(best) || z.top > best)) { best = z.top; setup = typ; zone = z; pinTouch = l[i] <= z.top; }
        } else {
          if (side === -1) typ = brokenBeyond(true) ? '' : 'REJECT';
          else if (side === 1) typ = brokenBeyond(false) ? '' : 'ZONE_BD';
          if (typ && (Number.isNaN(best) || z.bottom < best)) { best = z.bottom; setup = typ; zone = z; pinTouch = h[i] >= z.bottom; }
        }
      }
      if ((setup === 'ZONE_BO' || setup === 'ZONE_BD') && !emaOk) { setup = ''; zone = null; }
    }
    if (!setup) return null;

    // confirmation candle
    const rng = h[i] - l[i], body = Math.abs(c[i] - o[i]);
    const upW = h[i] - Math.max(o[i], c[i]), loW = Math.min(o[i], c[i]) - l[i];
    const bullish = c[i] > o[i], bearish = c[i] < o[i];
    const strong = (dir === 1 ? bullish : bearish) && rng > 0 && body >= 0.6 * rng && body >= 0.5 * a;
    const eng = dir === 1
      ? bullish && c[i - 1] < o[i - 1] && c[i] >= o[i - 1] && o[i] <= c[i - 1] && body >= 0.5 * a
      : bearish && c[i - 1] > o[i - 1] && c[i] <= o[i - 1] && o[i] >= c[i - 1] && body >= 0.5 * a;
    const pin = dir === 1
      ? rng > 0 && loW >= 2 * body && loW >= 0.6 * rng && c[i] >= l[i] + rng * 2 / 3
      : rng > 0 && upW >= 2 * body && upW >= 0.6 * rng && c[i] <= h[i] - rng * 2 / 3;
    const pinSetup = dir === 1 ? 'BOUNCE' : 'REJECT';
    const conf = strong ? 'STRONG' : eng ? 'ENGULF' : pin && setup === pinSetup && pinTouch ? 'PIN' : '';
    if (!conf) return null;
    diag.cSet++;

    // stop (v4): bounce/rejection -> beyond the last swing; zone break -> beyond the broken zone;
    // trendline break -> beyond the breakout candle or the line, whichever is further
    const buf = P.slBufAtr * a;
    let sl;
    if (setup === 'ZONE_BO') sl = zone.bottom - buf;
    else if (setup === 'ZONE_BD') sl = zone.top + buf;
    else if (setup === 'TL_BO') sl = Math.min(l[i], lineNow) - buf;
    else if (setup === 'TL_BD') sl = Math.max(h[i], lineNow) + buf;
    else if (dir === 1) {
      let raw = Math.min(low3[i], lowArm[i]);
      if (Number.isFinite(lastPL3) && lastPL3 < c[i]) raw = Math.min(raw, lastPL3);
      sl = raw - buf;
    } else {
      let raw = Math.max(high3[i], highArm[i]);
      if (Number.isFinite(lastPH3) && lastPH3 > c[i]) raw = Math.max(raw, lastPH3);
      sl = raw + buf;
    }
    if (P.entryMode === 'pullback') {
      // v5: do not enter on the setup bar; wait for a pullback to EMA 9 and a rejection candle
      armed = { dir, bar: i, setup, conf, zone, origSL: sl };
      diag.armed++;
      return null;
    }
    return buildEntry(i, dir, sl, setup, conf, zone, true);
  }

  // stop clamp, targets, max-stop check, position object (shared by direct and pullback entries)
  function buildEntry(i, dir, sl, setup, conf, zone, record, extra) {
    const a = A[i];
    let risk = dir === 1 ? c[i] - sl : sl - c[i];
    if (risk < P.minStop * a) { sl = dir === 1 ? c[i] - P.minStop * a : c[i] + P.minStop * a; risk = P.minStop * a; }

    // target levels: swing points + opposite zones beyond entry, merged
    const raw = [];
    if (dir === 1) {
      for (const p of phP) if (p > c[i]) raw.push(p);
      for (const z of zones) if (z.bottom > c[i]) raw.push(z.bottom);
      raw.sort((x, y) => x - y);
    } else {
      for (const p of plP) if (p < c[i]) raw.push(p);
      for (const z of zones) if (z.top < c[i]) raw.push(z.top);
      raw.sort((x, y) => y - x);
    }
    const merged = [];
    for (const p of raw) {
      if (!merged.length || (dir === 1 ? p > merged[merged.length - 1] + P.zoneAtr * a : p < merged[merged.length - 1] - P.zoneAtr * a)) merged.push(p);
    }
    // v4: levels closer than minT1R x R are not targets (the trade is kept)
    const lv = merged.filter((p) => Math.abs(p - c[i]) >= P.minT1R * risk);
    if (!lv.length) { lv.push(c[i] + dir * 2 * risk, c[i] + dir * 4 * risk); }
    else if (lv.length === 1) lv.push(lv[0] + (lv[0] - c[i]));
    const t1R = Math.abs(lv[0] - c[i]) / risk;
    const riskAtr = risk / a;
    if (record) setups.push({ t: t[i], dir, setup, conf, riskAtr, t1R });

    if (risk > P.maxStop * a) { diag.cBig++; return null; }
    if (t1R < P.minT1R) { diag.cNear++; return null; }

    const ctxNow = ctxAt(i);
    return {
      dir, bar: i, entryT: t[i], entry: c[i], sl, initialSL: sl, risk, atr: a, riskAtr,
      levels: lv, stage: 0, next: 2, remain: 1, booked: 0, swapR: 0, mfe: 0, mae: 0,
      slReason: 'initial', setup, conf,
      zone: zone ? { top: zone.top, bottom: zone.bottom, touches: zone.touches, ageBars: i - zone.firstBar } : null,
      // every active zone at entry (viewer draws them as boxes; not used by the rules)
      zonesAt: zones.map((z) => ({ top: z.top, bottom: z.bottom, touches: z.touches, ageBars: i - z.firstBar })),
      bias: { state: bias.state[i], slope: round(bias.slope[i], 3), e9: bias.e9[i], e15: bias.e15[i], close: bias.close[i] },
      ctxEntry: ctxNow,
      contra: Object.values(ctxNow).some((x) => x.state === -dir),
      events: [],
      ...(extra || {}),
    };
  }

  // v5 pullback entry: armed setup + pullback to EMA9 (low <= EMA9 + pbTouchAtr x ATR within the last
  // pbLook bars) + rejection candle closing beyond both EMAs; SL beyond the pullback extreme (last 5 bars)
  function pullbackEntry(i) {
    const s = armed, dir = s.dir, a = A[i];
    if (i <= s.bar) return null;
    if (bias.state[i] !== dir) { armed = null; diag.pbCancelBias++; return null; }
    if (dir === 1 ? c[i] < s.origSL : c[i] > s.origSL) { armed = null; diag.pbCancelSL++; return null; }
    if (i - s.bar > P.pbBars) { armed = null; diag.pbExpired++; return null; }
    let touched = false;
    for (let k = 0; k < P.pbLook && i - k > s.bar; k++) {
      const j = i - k;
      if (dir === 1 ? l[j] <= E9[i] + P.pbTouchAtr * a : h[j] >= E9[i] - P.pbTouchAtr * a) { touched = true; break; }
    }
    if (!touched) return null;
    const emaOk = dir === 1 ? c[i] > E9[i] && c[i] > E15[i] : c[i] < E9[i] && c[i] < E15[i];
    if (!emaOk) return null;
    const rng = h[i] - l[i], body = Math.abs(c[i] - o[i]);
    const upW = h[i] - Math.max(o[i], c[i]), loW = Math.min(o[i], c[i]) - l[i];
    const bullish = c[i] > o[i], bearish = c[i] < o[i];
    const strong = (dir === 1 ? bullish : bearish) && rng > 0 && body >= 0.6 * rng && body >= 0.5 * a;
    const eng = dir === 1
      ? bullish && c[i - 1] < o[i - 1] && c[i] >= o[i - 1] && o[i] <= c[i - 1] && body >= 0.5 * a
      : bearish && c[i - 1] > o[i - 1] && c[i] <= o[i - 1] && o[i] >= c[i - 1] && body >= 0.5 * a;
    const pinOwnTouch = dir === 1 ? l[i] <= E9[i] + P.pbTouchAtr * a : h[i] >= E9[i] - P.pbTouchAtr * a;
    const pin = pinOwnTouch && (dir === 1
      ? rng > 0 && loW >= 2 * body && loW >= 0.6 * rng && c[i] >= l[i] + rng * 2 / 3
      : rng > 0 && upW >= 2 * body && upW >= 0.6 * rng && c[i] <= h[i] - rng * 2 / 3);
    const conf = strong ? 'STRONG' : eng ? 'ENGULF' : pin ? 'PIN' : '';
    if (!conf) return null;
    const buf = P.slBufAtr * a;
    const sl = dir === 1 ? lowArm[i] - buf : highArm[i] + buf;
    diag.cSet++;
    const p = buildEntry(i, dir, sl, 'PB_' + s.setup, conf, s.zone, true, { waitedBars: i - s.bar, setupConf: s.conf });
    if (p) armed = null; // entered; a too-wide stop keeps waiting for a better candle
    return p;
  }

  function closeTrade(p, i, px, lastPart, reason) {
    const gross = p.booked + lastPart;
    const spreadR = spread / p.risk;
    trades.push({
      asset, tf, dir: p.dir === 1 ? 'LONG' : 'SHORT', setup: p.setup, conf: p.conf,
      entryT: new Date(p.entryT).toISOString(), exitT: new Date(t[i]).toISOString(),
      hours: round((t[i] - p.entryT) / 3600000, 1),
      entry: p.entry, initialSL: p.initialSL, exit: px, risk: p.risk, atr: p.atr, riskAtr: round(p.riskAtr, 2),
      t1: p.levels[0], t2: p.levels[1], levels: p.levels.slice(0, 6), t1R: round(Math.abs(p.levels[0] - p.entry) / p.risk, 2),
      stageReached: p.stage, exitReason: reason, waitedBars: p.waitedBars, setupConf: p.setupConf,
      grossR: round(gross, 3), spreadR: round(spreadR, 3), swapR: round(p.swapR, 3), netR: round(gross - spreadR - p.swapR, 3),
      mfeR: round(p.mfe, 2), maeR: round(p.mae, 2),
      zone: p.zone, zonesAt: p.zonesAt, bias: p.bias, ctxEntry: p.ctxEntry, ctxExit: ctxAt(i), contra: p.contra,
      events: p.events,
    });
  }

  return { trades, setups, diag, open: pos ? 1 : 0 };
}

function findLine(P, c, i, pp, bb, falling, tol2) {
  const nn = pp.length;
  if (nn < 3) return null;
  let best = null, bestT = 0, bestXb = -1;
  const s0 = Math.max(0, nn - P.tlPivots);
  for (let ai = s0; ai <= nn - 2; ai++) {
    for (let bi = ai + 1; bi <= nn - 1; bi++) {
      const pa = pp[ai], xa = bb[ai], pb = pp[bi], xb = bb[bi];
      if (!(xb > xa) || (falling ? !(pb < pa) : !(pb > pa))) continue;
      const m = (pb - pa) / (xb - xa);
      let tt = 0, ok = true;
      for (let k = ai; k <= nn - 1; k++) {
        const y = pa + m * (bb[k] - xa);
        const d = falling ? pp[k] - y : y - pp[k];
        if (d > tol2) { ok = false; break; }
        if (Math.abs(d) <= tol2) tt++;
      }
      if (ok && tt >= 3 && (tt > bestT || (tt === bestT && xb > bestXb))) {
        for (let j = xa + 1; j <= i - 1; j++) {
          const y = pa + m * (j - xa);
          if (falling ? c[j] > y + tol2 : c[j] < y - tol2) { ok = false; break; }
        }
        if (ok) { bestT = tt; bestXb = xb; best = { x: xa, y: pa, m, t: tt }; }
      }
    }
  }
  return best;
}

function round(x, d) { return Number.isFinite(x) ? Math.round(x * 10 ** d) / 10 ** d : null; }

module.exports = { run, DEFAULTS, SWAP_MULT };
