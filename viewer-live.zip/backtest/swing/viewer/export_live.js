#!/usr/bin/env node
/**
 * Exports the scalp bot's CLOSED trades from MongoDB into the Backtest Viewer, one file per strategy:
 *   backtest/data/swing/trades_live-<strategyId>.jsonl
 * READ-ONLY on the database. Re-run any time to refresh (notes are kept: they are keyed by strategy+asset+entry time).
 *
 *   node backtest/swing/viewer/export_live.js                 # all strategies, all assets
 *   node backtest/swing/viewer/export_live.js --strategy=babalu,default --assets=GOLD
 *
 * Charts need 5m candles up to now:  node backtest/swing/fetch_tf.js --tf=5m
 */
const fs = require('fs');
const path = require('path');

const BACKEND = path.resolve(__dirname, '..', '..', '..');
const OUT = path.join(BACKEND, 'backtest', 'data', 'swing');
const args = Object.fromEntries(process.argv.slice(2).map((s) => s.match(/^--([^=]+)(?:=(.*))?$/)).filter(Boolean).map((m) => [m[1], m[2] ?? true]));

function loadEnv() {
  const p = path.join(BACKEND, '.env'); const e = {};
  if (fs.existsSync(p)) for (const line of fs.readFileSync(p, 'utf8').split('\n')) {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (m) e[m[1]] = m[2].replace(/^['"]|['"]$/g, '');
  }
  return e;
}
const r2 = (x, d = 3) => (Number.isFinite(x) ? Math.round(x * 10 ** d) / 10 ** d : null);
const iso = (d) => (d ? new Date(d).toISOString() : null);

function toViewer(tr) {
  const x = tr.execution || {}, o = tr.outcome || {}, eb = tr.entryBasis || {};
  const dir = tr.direction, sgn = dir === 'LONG' ? 1 : -1;
  const risk = Math.abs((x.entryPrice || 0) - (x.sl || 0));
  const checks = eb.checks || {};
  const passed = Object.entries(checks).filter(([, c]) => c && c.passed).map(([k, c]) => `${k}:${c.value}`).join(' ');
  const fp = (tr.prediction && tr.prediction.setupFingerprint) || tr.setupFingerprint || 'SETUP';
  const entryT = iso(x.entryTime), exitT = iso(o.exitTime);
  const R = Number.isFinite(o.rMultiple) ? o.rMultiple : (risk > 0 && Number.isFinite(o.exitPrice) ? sgn * (o.exitPrice - x.entryPrice) / risk : null);
  return {
    asset: tr.asset, tf: tr.timeframe || '5m', dir, setup: fp, conf: (tr.entryType || (eb.confirmationCandle ? 'CONFIRMED' : 'NO_CONF')).toUpperCase(),
    entryT, exitT, hours: entryT && exitT ? r2((Date.parse(exitT) - Date.parse(entryT)) / 3600000, 1) : null,
    entry: x.entryPrice, initialSL: x.sl, exit: o.exitPrice, risk, riskAtr: null,
    t1: x.tp1, t2: x.tp2, t1R: risk > 0 && x.tp1 ? r2(Math.abs(x.tp1 - x.entryPrice) / risk, 2) : null,
    stageReached: o.tp1Hit ? 1 : 0, exitReason: o.exitReason || '-',
    grossR: r2(R), spreadR: null, swapR: null, netR: r2(R),
    mfeR: r2(o.mfeR ?? o.mfe ?? null, 2), maeR: r2(o.maeR ?? o.mae ?? null, 2),
    zone: null,
    bias: { state: eb.htfTrend === 'BULL' ? 1 : eb.htfTrend === 'BEAR' ? -1 : 0, slope: null },
    ctxEntry: {}, contra: false, events: [],
    extra: {
      'Strategy': tr.strategyId || 'default',
      'Session': eb.session || '-',
      'Stage / HTF / ADX': `${eb.marketStage || '-'} / ${eb.htfTrend || '-'} / ${eb.adx != null ? r2(eb.adx, 1) : '-'}`,
      'Score': `bull ${eb.bullScore ?? '-'} · bear ${eb.bearScore ?? '-'} · margin ${eb.netMargin ?? '-'}`,
      'Checks passed': passed || '-',
      'News nearby': eb.newsContext && eb.newsContext.highImpactEventNearby ? 'yes' : 'no',
      'P/L USD': o.pnlUsd != null ? r2(o.pnlUsd, 2) : '-',
    },
    tradeId: tr.tradeId,
  };
}

async function main() {
  const env = loadEnv();
  const uri = env.MONGO_URI || process.env.MONGO_URI;
  if (!uri) { console.error('MONGO_URI missing in .env'); process.exit(1); }
  const mongoose = require('mongoose');
  await mongoose.connect(uri);
  const q = { 'outcome.status': 'CLOSED' };
  if (args.strategy) q.strategyId = { $in: String(args.strategy).split(',') };
  if (args.assets) q.asset = { $in: String(args.assets).toUpperCase().split(',') };
  const docs = await mongoose.connection.db.collection('trades').find(q).sort({ 'execution.entryTime': 1 }).toArray();
  const by = {};
  for (const d of docs) {
    const v = toViewer(d);
    if (!v.entryT || !Number.isFinite(v.entry) || !Number.isFinite(v.initialSL)) continue;
    (by[d.strategyId || 'default'] ||= []).push(v);
  }
  fs.mkdirSync(OUT, { recursive: true });
  for (const [id, list] of Object.entries(by)) {
    const file = path.join(OUT, `trades_live-${id}.jsonl`);
    fs.writeFileSync(file, list.map((t) => JSON.stringify(t)).join('\n') + '\n');
    const net = list.reduce((s, t) => s + (t.netR || 0), 0);
    const first = list[0].entryT.slice(0, 10), last = list[list.length - 1].entryT.slice(0, 10);
    console.log(`live-${id.padEnd(8)} ${String(list.length).padStart(5)} trades  ${first} -> ${last}  avg R ${(net / list.length).toFixed(3)}  -> ${path.basename(file)}`);
  }
  await mongoose.disconnect();
}
if (require.main === module) main().catch((e) => { console.error('export failed:', e.message); process.exit(1); });
else module.exports = { toViewer };
