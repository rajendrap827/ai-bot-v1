#!/usr/bin/env python3
"""
MT5 -> Node Bridge (Multi-Symbol, Exness)
=========================================
Reads live ticks and closed 5-minute candles for BTC, ETH, and GOLD from ONE
MetaTrader 5 terminal (Exness DEMO account) and streams them to the Node
backend over a single WebSocket connection.

This process is the ONLY thing that talks to MT5. It is read-only — it does NOT
place orders. The Node paper engine does all trade simulation.

Message contract (matches feeds/mt5Bridge.js on the Node side):
    {"type": "tick",   "asset": "BTC", "price": <float>, "ts": <ISO8601>}
    {"type": "candle", "asset": "BTC", "t": <ISO8601>, "o","h","l","c","v": <float>}

AUTO-DISCOVERY:
    Run with  --list-symbols  to print every symbol available on the account
    (filtered to BTC/ETH/XAU by default). Use this on the demo account to find
    the exact names + suffix, then put them in the SYMBOL_MAP env vars.

Run under Wine + Xvfb on the Linux server, supervised by systemd.
"""

import os
import sys
import time
import json
import signal
from datetime import datetime, timezone

try:
    import MetaTrader5 as mt5
except ImportError:
    print("[bridge] ERROR: MetaTrader5 not found. pip install MetaTrader5 (inside Wine Python)", file=sys.stderr)
    sys.exit(1)

try:
    import websocket  # websocket-client
except ImportError:
    print("[bridge] ERROR: websocket-client not found. pip install websocket-client", file=sys.stderr)
    sys.exit(1)


# ---- Config (from environment; never hard-code credentials) ----
MT5_ACCOUNT  = os.environ.get("MT5_ACCOUNT", "")
MT5_PASSWORD = os.environ.get("MT5_PASSWORD", "")
MT5_SERVER   = os.environ.get("MT5_SERVER", "")

# asset -> broker symbol name. Defaults use the "c" (cent) suffix seen on the
# live account; the DEMO account may differ — run --list-symbols to confirm,
# then override with env vars SYMBOL_BTC / SYMBOL_ETH / SYMBOL_GOLD.
SYMBOL_MAP = {
    "BTC":  os.environ.get("SYMBOL_BTC",  "BTCUSDc"),
    "ETH":  os.environ.get("SYMBOL_ETH",  "ETHUSDc"),
    "GOLD": os.environ.get("SYMBOL_GOLD", "XAUUSDc"),
}

NODE_WS_URL   = os.environ.get("MT5_BRIDGE_WS_URL", "ws://127.0.0.1:4101")
TICK_POLL_SEC = float(os.environ.get("TICK_POLL_SEC", "0.5"))
RECONNECT_SEC = float(os.environ.get("RECONNECT_SEC", "3"))

_running = True


def _log(msg):
    print(f"[bridge] {datetime.now(timezone.utc).isoformat()} {msg}", flush=True)


def _stop(signum, frame):
    global _running
    _running = False
    _log(f"received signal {signum}, shutting down")


signal.signal(signal.SIGINT, _stop)
signal.signal(signal.SIGTERM, _stop)


def init_mt5():
    if not mt5.initialize():
        _log(f"mt5.initialize() failed: {mt5.last_error()}")
        return False
    if MT5_ACCOUNT and MT5_PASSWORD and MT5_SERVER:
        if not mt5.login(int(MT5_ACCOUNT), password=MT5_PASSWORD, server=MT5_SERVER):
            _log(f"mt5.login() failed: {mt5.last_error()}")
            return False
        _log(f"logged in to account {MT5_ACCOUNT} on {MT5_SERVER}")
    else:
        _log("WARNING: MT5 credentials not fully set; relying on terminal's existing login")
    return True


def list_symbols():
    """Auto-discovery: print all symbols containing BTC / ETH / XAU."""
    if not init_mt5():
        sys.exit(1)
    all_syms = mt5.symbols_get()
    _log(f"account exposes {len(all_syms)} symbols total")
    print("\n=== Candidate symbols (BTC / ETH / XAU) ===")
    for s in all_syms:
        name = s.name.upper()
        if "BTC" in name or "ETH" in name or "XAU" in name:
            print(f"  {s.name}")
    print("\nPut the exact names into SYMBOL_BTC / SYMBOL_ETH / SYMBOL_GOLD env vars.\n")
    mt5.shutdown()


def select_symbols():
    for asset, sym in SYMBOL_MAP.items():
        if not mt5.symbol_select(sym, True):
            _log(f"WARNING: symbol_select({sym}) for {asset} failed — check the exact name with --list-symbols")
        else:
            _log(f"{asset} -> {sym} selected")


def connect_node():
    while _running:
        try:
            ws = websocket.create_connection(NODE_WS_URL, timeout=10)
            _log(f"connected to Node bridge at {NODE_WS_URL}")
            return ws
        except Exception as e:
            _log(f"could not connect to Node ({e}); retrying in {RECONNECT_SEC}s")
            time.sleep(RECONNECT_SEC)
    return None


def send(ws, payload):
    ws.send(json.dumps(payload))


def last_closed_candle(sym):
    rates = mt5.copy_rates_from_pos(sym, mt5.TIMEFRAME_M5, 0, 2)
    if rates is None or len(rates) < 2:
        return None
    r = rates[1]  # index 0 = forming, index 1 = last closed
    return {
        "t": datetime.fromtimestamp(int(r["time"]), tz=timezone.utc).isoformat(),
        "o": float(r["open"]), "h": float(r["high"]),
        "l": float(r["low"]),  "c": float(r["close"]),
        "v": float(r["tick_volume"]),
    }


def run():
    if not init_mt5():
        _log("MT5 init failed; exiting (systemd will restart)")
        sys.exit(1)
    select_symbols()

    ws = connect_node()
    if ws is None:
        return

    last_candle_ts = {a: None for a in SYMBOL_MAP}
    _log("streaming started for: " + ", ".join(f"{a}={s}" for a, s in SYMBOL_MAP.items()))

    while _running:
        try:
            for asset, sym in SYMBOL_MAP.items():
                # tick
                tick = mt5.symbol_info_tick(sym)
                if tick is not None and tick.bid:
                    mid = (tick.bid + tick.ask) / 2 if tick.ask else tick.bid
                    send(ws, {"type": "tick", "asset": asset, "price": float(mid),
                              "ts": datetime.fromtimestamp(tick.time, tz=timezone.utc).isoformat()})
                # closed candle (once per new bar)
                candle = last_closed_candle(sym)
                if candle and candle["t"] != last_candle_ts[asset]:
                    payload = {"type": "candle", "asset": asset}
                    payload.update(candle)
                    send(ws, payload)
                    last_candle_ts[asset] = candle["t"]
                    _log(f"{asset} closed candle {candle['t']} c={candle['c']}")

            time.sleep(TICK_POLL_SEC)

        except (websocket.WebSocketConnectionClosedException, BrokenPipeError, ConnectionResetError):
            _log("Node connection lost; reconnecting")
            ws = connect_node()
            if ws is None:
                break
        except Exception as e:
            _log(f"unexpected error: {e}")
            time.sleep(RECONNECT_SEC)

    try:
        if ws:
            ws.close()
    finally:
        mt5.shutdown()
        _log("shutdown complete")


if __name__ == "__main__":
    if "--list-symbols" in sys.argv:
        list_symbols()
    else:
        run()
