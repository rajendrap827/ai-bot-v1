const WebSocket = require('ws');

/**
 * Single WebSocket server the Python MT5 bridge connects to as a client.
 * The Python side streams ticks + closed candles for ALL THREE assets
 * (BTC, ETH, GOLD) over one connection, each message tagged with `asset`.
 * We fan those out to per-asset handlers registered by the workers.
 *
 * Raw ticks are used only for SL/TP/trailing checks and are never stored
 * in MongoDB (consistent with the no-raw-tick-storage decision).
 */
function startMt5Bridge(port) {
  const handlers = {}; // asset -> { onClosedCandle, onTick }
  let connected = false;

  const wss = new WebSocket.Server({ port });

  wss.on('connection', (ws) => {
    connected = true;
    console.log('[mt5-bridge] Python MT5 bridge connected');

    ws.on('message', (raw) => {
      let msg;
      try {
        msg = JSON.parse(raw.toString());
      } catch (e) {
        return;
      }
      const h = handlers[msg.asset];
      if (!h) return; // no worker registered for this asset yet
      if (msg.type === 'tick') {
        h.onTick({ price: msg.price, ts: new Date(msg.ts) });
      } else if (msg.type === 'candle') {
        h.onClosedCandle({ t: new Date(msg.t), o: msg.o, h: msg.h, l: msg.l, c: msg.c, v: msg.v || 0 });
      }
    });

    ws.on('close', () => {
      connected = false;
      console.warn('[mt5-bridge] Python MT5 bridge disconnected — waiting for reconnect');
    });
  });

  console.log(`[mt5-bridge] listening on port ${port} for the Python MT5 bridge`);

  return {
    /** Workers call this to register their per-asset callbacks. */
    register(asset, { onClosedCandle, onTick }) {
      handlers[asset] = { onClosedCandle, onTick };
      console.log(`[mt5-bridge] registered handler for ${asset}`);
    },
    isConnected: () => connected,
    close: () => wss.close(),
  };
}

module.exports = { startMt5Bridge };
