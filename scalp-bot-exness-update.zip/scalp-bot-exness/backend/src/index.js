const env = require('./config/env');
const { connectDB } = require('./config/db');
const { seedInitialBalance } = require('./config/bootstrap');
const { startChangeStreamWatchers } = require('./events/changeStreamWatcher');
const { createServer } = require('./api/server');
const { startMt5Bridge } = require('./feeds/mt5Bridge');
const { startMt5Worker } = require('./workers/mt5Worker');
const { runTuningCycle } = require('./tuning/tuner');

const MT5_BRIDGE_PORT = process.env.MT5_BRIDGE_PORT ? parseInt(process.env.MT5_BRIDGE_PORT, 10) : 4101;
const TUNING_INTERVAL_MS = 24 * 60 * 60 * 1000; // daily

async function main() {
  await connectDB();
  await seedInitialBalance();
  startChangeStreamWatchers();

  const { httpServer } = createServer();
  httpServer.listen(env.port, () => console.log(`[api] listening on port ${env.port}`));

  // One MT5 bridge feeds all three assets (BTC/ETH/GOLD) from Exness — paper
  // prices therefore match what you'd trade live on the same broker.
  const bridge = startMt5Bridge(MT5_BRIDGE_PORT);

  await startMt5Worker('BTC',  bridge, { htfMinutes: 60, htfLen: 50 });
  await startMt5Worker('ETH',  bridge, { htfMinutes: 60, htfLen: 50 });
  await startMt5Worker('GOLD', bridge, { htfMinutes: 60, htfLen: 50 });

  setInterval(async () => {
    for (const asset of ['BTC', 'ETH', 'GOLD']) {
      try {
        const result = await runTuningCycle(asset);
        console.log(result.skipped ? `[tuner:${asset}] skipped — ${result.reason}` : `[tuner:${asset}] reviewed ${result.decisions.length} component(s)`);
      } catch (err) {
        console.error(`[tuner:${asset}] error:`, err.message);
      }
    }
  }, TUNING_INTERVAL_MS);

  console.log('[main] all systems started (Exness MT5 feed for BTC/ETH/GOLD)');
}

main().catch((err) => {
  console.error('[main] fatal startup error:', err);
  process.exit(1);
});
