const { runAssetWorker } = require('./assetWorker');
const Candle = require('../models/Candle');
const { ema } = require('../strategy/indicators');

/**
 * All three assets (BTC, ETH, GOLD) now come from the single Exness MT5 feed
 * via the shared bridge, so paper prices match the prices you'd trade live.
 *
 * Seeding uses whatever 5m candles are already stored in the time-series
 * Candle collection (the Python bridge / prior runs populate it). On a cold
 * start with an empty collection the worker simply warms up over the first
 * ~215 live candles before it can emit signals.
 *
 * HTF trend is derived from the stored candles by resampling 5m -> the HTF
 * timeframe, since there's no separate free REST source here. If not enough
 * history exists yet, HTF returns { null, null } which scoring treats as
 * "no HTF opinion — allow the trade."
 */
async function startMt5Worker(asset, bridge, { timeframe = '5m', htfMinutes = 60, htfLen = 50 } = {}) {
  return runAssetWorker({
    asset,
    timeframe,
    seedCandles: async () => {
      const docs = await Candle.find({ asset, timeframe }).sort({ t: -1 }).limit(320).lean();
      return docs.reverse().map((d) => ({ t: d.t, o: d.o, h: d.h, l: d.l, c: d.c, v: d.v }));
    },
    connectFeed: ({ onClosedCandle, onTick }) => {
      bridge.register(asset, { onClosedCandle, onTick });
      return { close: () => {} }; // bridge lifecycle is managed centrally
    },
    getHtfTrend: async () => htfTrendFromCandles(asset, timeframe, htfMinutes, htfLen),
  });
}

/**
 * Resamples stored 5m candles into HTF buckets and computes the EMA trend on
 * the last CLOSED HTF bar (no look-ahead).
 */
async function htfTrendFromCandles(asset, timeframe, htfMinutes, htfLen) {
  const need = (htfLen + 5) * (htfMinutes / 5) + 5;
  const docs = await Candle.find({ asset, timeframe }).sort({ t: -1 }).limit(Math.ceil(need)).lean();
  if (docs.length < (htfMinutes / 5) * 3) return { bull: null, bear: null };
  const rows = docs.reverse();

  const bucketMs = htfMinutes * 60 * 1000;
  const buckets = new Map();
  for (const d of rows) {
    const key = Math.floor(new Date(d.t).getTime() / bucketMs) * bucketMs;
    const b = buckets.get(key);
    if (!b) buckets.set(key, { c: d.c });
    else b.c = d.c; // last close in the bucket
  }
  const closes = [...buckets.entries()].sort((a, b) => a[0] - b[0]).map(([, v]) => v.c);
  if (closes.length < 3) return { bull: null, bear: null };

  const emaSeries = ema(closes, Math.min(htfLen, closes.length - 1));
  const i = closes.length - 2; // last closed HTF bar
  if (i < 1 || emaSeries[i] == null) return { bull: null, bear: null };
  return { bull: closes[i] > emaSeries[i], bear: closes[i] < emaSeries[i] };
}

module.exports = { startMt5Worker };
