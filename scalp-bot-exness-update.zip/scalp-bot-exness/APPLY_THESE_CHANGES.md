# Exness-Only Update — All Three Assets via MT5

This bundle switches the bot so **BTC, ETH, and GOLD all come from your Exness
MT5 demo feed** (instead of BTC/ETH from Binance). Paper prices now match what
you'd trade live on the same broker.

## What to replace in your existing `scalp-bot` project

| This file | Replaces / Action |
|---|---|
| `python-mt5-bridge/mt5_bridge.py` | **Replace** the old single-symbol bridge. Now streams all 3 symbols + has `--list-symbols` auto-discovery. |
| `backend/src/feeds/mt5Bridge.js` | **New file.** Multi-asset Node-side bridge. |
| `backend/src/workers/mt5Worker.js` | **New file.** One worker used for all 3 assets. |
| `backend/src/index.js` | **Replace.** Starts one MT5 bridge + 3 MT5 workers, no Binance. |

You can **delete** (no longer used): `feeds/binanceFeed.js`, `feeds/htfTrend.js`,
`feeds/internalGoldBridge.js`, `workers/cryptoWorker.js`, `workers/goldWorker.js`.
(Leaving them in place is harmless — nothing imports them anymore.)

Everything else — models, scoring, paper engine, tuner, API, dashboard —
stays exactly the same.

## Step 1 — find your demo symbol names

Your LIVE account showed `BTCUSDc`, `ETHUSDc`, `XAUUSDc` (cent account, `c`
suffix). Your DEMO account may differ. On the server, after MT5 is installed
under Wine and logged into the demo account:

```bash
xvfb-run wine python python-mt5-bridge/mt5_bridge.py --list-symbols
```

This prints every BTC/ETH/XAU symbol on the account. Note the exact names.

## Step 2 — set the symbol env vars

In the systemd service (or your shell), set:

```bash
export SYMBOL_BTC=BTCUSDc      # use whatever --list-symbols showed on DEMO
export SYMBOL_ETH=ETHUSDc
export SYMBOL_GOLD=XAUUSDc
```

If your demo account uses no suffix, they'd be `BTCUSD`, `ETHUSD`, `XAUUSD`.

## Step 3 — run

Start the backend, then start the bridge (both under systemd as before). The
bridge connects to `ws://127.0.0.1:4101`, and all three workers register with
it and begin receiving ticks + candles.

## Note on HTF trend

With no Binance REST source, the higher-timeframe (1H) trend for each asset is
now computed by resampling the stored 5m candles. On a fresh install this needs
a few hours of candles before the HTF filter becomes active; until then the
filter simply stays neutral (doesn't block trades). This is expected.
