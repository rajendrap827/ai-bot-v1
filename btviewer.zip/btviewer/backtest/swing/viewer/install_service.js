#!/usr/bin/env node
/**
 * Installs the Backtest Viewer as a systemd service "btviewer" (starts on boot).
 * Run from ~/ai-bot-v1/scalp-bot/backend:   node backtest/swing/viewer/install_service.js
 * Optional port:                             node backtest/swing/viewer/install_service.js 5180
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execSync } = require('child_process');

const PORT = Number(process.argv[2] || 5180);
const backend = path.resolve(__dirname, '..', '..', '..');
const dataDir = path.join(backend, 'backtest', 'data', 'swing');
const keyFile = path.join(dataDir, 'viewer_key.txt');
fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(keyFile)) fs.writeFileSync(keyFile, crypto.randomBytes(9).toString('hex') + '\n');
const key = fs.readFileSync(keyFile, 'utf8').trim();

const unit = `[Unit]
Description=Backtest Viewer (read-only)
After=network.target

[Service]
WorkingDirectory=${backend}
Environment=PORT=${PORT}
ExecStart=${process.execPath} ${path.join(backend, 'backtest', 'swing', 'viewer', 'server.js')}
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
`;
fs.writeFileSync('/etc/systemd/system/btviewer.service', unit);
execSync('systemctl daemon-reload && systemctl enable btviewer && systemctl restart btviewer', { stdio: 'inherit' });

let ip = '<server-ip>';
try { ip = execSync("hostname -I | awk '{print $1}'").toString().trim() || ip; } catch {}
console.log(`\nBacktest Viewer is running.\nOpen on iPad/phone:\n  http://${ip}:${PORT}/?key=${key}\n`);
try {
  const ufw = execSync('ufw status 2>/dev/null || true').toString();
  if (/Status: active/.test(ufw) && !new RegExp(`\\b${PORT}\\b`).test(ufw)) console.log(`Firewall (ufw) is active - allow the port:\n  ufw allow ${PORT}/tcp\n`);
} catch {}
