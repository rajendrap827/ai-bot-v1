#!/usr/bin/env node
/**
 * Backtest Viewer - TradingView-style chart of every backtest trade, with notes.
 * READ-ONLY for the bot: reads backtest/data/swing/*.json(l), writes only viewer_notes.json.
 * No npm packages needed.
 *
 *   node backtest/swing/viewer/server.js            # port 5180
 *   PORT=5181 node backtest/swing/viewer/server.js
 *
 * Open: http://<server-ip>:5180/?key=<key>   (key printed at start, stored in data/swing/viewer_key.txt)
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { STRATS, TF_MS, DATA_DIR, loadBars, ema, biasSeries } = require('../lib');
const { DEFAULTS } = require('../engine');

const PORT = Number(process.env.PORT || 5180);
const KEY_FILE = path.join(DATA_DIR, 'viewer_key.txt');
const NOTES_FILE = path.join(DATA_DIR, 'viewer_notes.json');
const HTML = path.join(__dirname, 'index.html');

fs.mkdirSync(DATA_DIR, { recursive: true });
let KEY = process.env.VIEWER_KEY || (fs.existsSync(KEY_FILE) ? fs.readFileSync(KEY_FILE, 'utf8').trim() : '');
if (!KEY) { KEY = crypto.randomBytes(9).toString('hex'); fs.writeFileSync(KEY_FILE, KEY + '\n'); }

// ---- caches (keep the last few candle files in memory)
const barCache = new Map();
function bars(asset, tf) {
  const k = `${asset}_${tf}`;
  if (barCache.has(k)) { const v = barCache.get(k); barCache.delete(k); barCache.set(k, v); return v; }
  const b = loadBars(asset, tf);
  if (!b) return null;
  const strat = Object.values(STRATS).find((s) => s.tf === tf);
  const v = {
    b,
    e9: ema(b.c, 9),
    e15: ema(b.c, 15),
    bias: strat ? biasSeries(b, TF_MS[strat.htf], DEFAULTS.slopeLb, DEFAULTS.slopeThr).state : null,
  };
  barCache.set(k, v);
  while (barCache.size > 3) barCache.delete(barCache.keys().next().value);
  return v;
}

const tradeCache = new Map();
function trades(strategy) {
  const file = path.join(DATA_DIR, `trades_${strategy}.jsonl`);
  if (!fs.existsSync(file)) return [];
  const mtime = fs.statSync(file).mtimeMs;
  const c = tradeCache.get(strategy);
  if (c && c.mtime === mtime) return c.list;
  const list = fs.readFileSync(file, 'utf8').split('\n').filter(Boolean).map((l, i) => ({ id: i, ...JSON.parse(l) }));
  tradeCache.set(strategy, { mtime, list });
  return list;
}

function readNotes() {
  try { return JSON.parse(fs.readFileSync(NOTES_FILE, 'utf8')); } catch { return {}; }
}

function lowerBound(arr, x) {
  let lo = 0, hi = arr.length;
  while (lo < hi) { const m = (lo + hi) >> 1; if (arr[m] < x) lo = m + 1; else hi = m; }
  return lo;
}

function send(res, code, body, type = 'application/json') {
  res.writeHead(code, { 'Content-Type': type, 'Cache-Control': 'no-store' });
  res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body));
}

const server = http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x');
  if (u.searchParams.get('key') !== KEY) return send(res, 403, 'forbidden - add ?key=... to the URL', 'text/plain');
  try {
    if (u.pathname === '/') return send(res, 200, fs.readFileSync(HTML), 'text/html; charset=utf-8');

    if (u.pathname === '/api/meta') {
      const out = {};
      for (const id of Object.keys(STRATS)) out[id] = { ...STRATS[id], trades: fs.existsSync(path.join(DATA_DIR, `trades_${id}.jsonl`)) };
      return send(res, 200, out);
    }

    if (u.pathname === '/api/trades') {
      const s = u.searchParams.get('strategy');
      if (!STRATS[s]) return send(res, 400, { error: 'bad strategy' });
      const notes = readNotes();
      return send(res, 200, trades(s).map((t) => ({ ...t, note: notes[`${s}|${t.asset}|${t.entryT}`] || null })));
    }

    if (u.pathname === '/api/candles') {
      const asset = u.searchParams.get('asset'), tf = u.searchParams.get('tf');
      const from = Number(u.searchParams.get('from')), to = Number(u.searchParams.get('to'));
      if (!['GOLD', 'BTC', 'ETH'].includes(asset) || !TF_MS[tf]) return send(res, 400, { error: 'bad asset/tf' });
      const v = bars(asset, tf);
      if (!v) return send(res, 404, { error: `no data file for ${asset} ${tf}` });
      const { b } = v;
      const i0 = Math.max(0, lowerBound(b.t, from)), i1 = Math.min(b.n, lowerBound(b.t, to + 1));
      if (i1 - i0 > 6000) return send(res, 400, { error: 'range too large' });
      const out = [];
      for (let i = i0; i < i1; i++) {
        out.push([b.t[i] / 1000, b.o[i], b.h[i], b.l[i], b.c[i], round(v.e9[i]), round(v.e15[i]), v.bias ? v.bias[i] : 0]);
      }
      return send(res, 200, out);
    }

    if (u.pathname === '/api/note' && req.method === 'POST') {
      let body = '';
      req.on('data', (d) => { body += d; if (body.length > 20000) req.destroy(); });
      req.on('end', () => {
        try {
          const n = JSON.parse(body);
          if (!n.key || typeof n.key !== 'string') return send(res, 400, { error: 'no key' });
          const notes = readNotes();
          if (!n.verdict && !n.text) delete notes[n.key];
          else {
            const prev = notes[n.key] || {};
            notes[n.key] = {
              verdict: n.verdict || '', text: String(n.text || '').slice(0, 2000), at: new Date().toISOString(),
              blindVerdict: n.blindVerdict || prev.blindVerdict || undefined,
            };
          }
          fs.writeFileSync(NOTES_FILE, JSON.stringify(notes, null, 1));
          send(res, 200, { ok: true });
        } catch (err) { send(res, 400, { error: err.message }); }
      });
      return;
    }
    send(res, 404, { error: 'not found' });
  } catch (err) {
    console.error(err);
    send(res, 500, { error: err.message });
  }
});

function round(x) { return Number.isFinite(x) ? Math.round(x * 1e5) / 1e5 : null; }

server.listen(PORT, '0.0.0.0', () => {
  console.log(`[viewer] http://<server-ip>:${PORT}/?key=${KEY}`);
});
