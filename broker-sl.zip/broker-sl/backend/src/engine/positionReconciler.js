const Trade = require('../models/Trade');
const { BalanceLog } = require('../models/Config');

/**
 * Position reconciler — the fix for stop-loss slippage.
 *
 * Previously the engine watched ticks and closed a trade once it SAW price
 * beyond the stop. But ticks only arrive when MetaApi pushes them, so by the
 * time we noticed, price had already moved past the stop — every loss came in
 * worse than the planned 1R (measured: -1.74R average instead of -1.0R).
 *
 * Now the broker holds the real SL/TP server-side and executes them itself.
 * This module polls the broker's open positions and, when one has gone, closes
 * the matching paper trade at the broker's ACTUAL fill price. Paper and broker
 * therefore agree, and losses land where they were meant to.
 *
 * The tick handler still manages the trailing stop (moving the stop is not
 * time-critical the way triggering it is) but no longer triggers exits.
 */

let brokerConn = null;
let symbolMap = {};
let reverseMap = {};

function attachReconciler(connection, symbols) {
  brokerConn = connection;
  symbolMap = symbols || {};
  reverseMap = Object.fromEntries(Object.entries(symbolMap).map(([a, s]) => [s, a]));
}

async function currentBalance() {
  const latest = await BalanceLog.findOne({}).sort({ ts: -1 }).lean();
  return latest ? latest.balance : 0;
}

async function adjustBalance(delta, reason) {
  const bal = await currentBalance();
  const newBal = bal + delta;
  await BalanceLog.create({ balance: newBal, changeReason: reason, changedBy: 'reconciler' });
  return newBal;
}

/**
 * Reads the broker's live positions and reconciles them against our OPEN
 * trades. Anything we think is open but the broker has closed gets finalised
 * using the broker's own numbers.
 */
async function reconcileOnce() {
  if (!brokerConn) return;

  let brokerPositions;
  try {
    brokerPositions = brokerConn.terminalState.positions || [];
  } catch (err) {
    console.error('[reconcile] could not read broker positions:', err.message);
    return;
  }

  const openIds = new Set(brokerPositions.map((p) => String(p.id)));
  const ourOpen = await Trade.find({ 'outcome.status': 'OPEN', 'broker.positionId': { $ne: null } });

  for (const trade of ourOpen) {
    const posId = String(trade.broker.positionId);
    if (openIds.has(posId)) continue; // still open at the broker — nothing to do

    // The broker has closed it. Find out at what price and for how much.
    let exitPrice = null;
    let brokerPnl = null;
    try {
      const history = await brokerConn.historyStorage.getDealsByPosition(posId);
      const closingDeals = (history || []).filter((d) => d.entryType === 'DEAL_ENTRY_OUT' || d.entryType === 'DEAL_ENTRY_INOUT');
      if (closingDeals.length) {
        const last = closingDeals[closingDeals.length - 1];
        exitPrice = last.price;
        brokerPnl = closingDeals.reduce((s, d) => s + (d.profit || 0), 0);
      }
    } catch (err) {
      console.warn(`[reconcile] deal history unavailable for ${posId}: ${err.message}`);
    }

    if (exitPrice == null) {
      // Fall back to the planned stop — better than leaving it open forever.
      exitPrice = trade.execution.sl;
      console.warn(`[reconcile] no fill price for ${posId}; assuming stop at ${exitPrice}`);
    }

    await finaliseTrade(trade, exitPrice, brokerPnl);
  }
}

async function finaliseTrade(trade, exitPrice, brokerPnl) {
  const { direction, execution, outcome } = trade;
  const entry = execution.entryPrice;

  // Size still open on our side (TP1 may already have closed part of it)
  const remaining = outcome.tp1Hit
    ? execution.size - (outcome.tp1ClosedSize || 0)
    : execution.size;

  const pnlOnRemainder = direction === 'LONG'
    ? (exitPrice - entry) * remaining
    : (entry - exitPrice) * remaining;

  const tp1Pnl = outcome.tp1Hit
    ? (direction === 'LONG'
        ? (execution.tp1 - entry) * outcome.tp1ClosedSize
        : (entry - execution.tp1) * outcome.tp1ClosedSize)
    : 0;

  const totalPnl = tp1Pnl + pnlOnRemainder;
  const initialRisk = Math.abs(entry - execution.sl) * execution.size;
  const rMultiple = initialRisk ? totalPnl / initialRisk : 0;
  const notional = entry * execution.size;

  // Work out why it closed, from where the fill landed.
  const hitStop = direction === 'LONG'
    ? exitPrice <= execution.sl * 1.001
    : exitPrice >= execution.sl * 0.999;
  const reason = outcome.trailingActive ? 'TRAIL_STOP' : hitStop ? 'SL' : 'TIME';

  await adjustBalance(pnlOnRemainder, `trade:${trade.tradeId}:${reason.toLowerCase()}`);

  trade.outcome.status = 'CLOSED';
  trade.outcome.exitTime = new Date();
  trade.outcome.exitPrice = exitPrice;
  trade.outcome.exitReason = reason;
  trade.outcome.pnlUsd = Math.round(totalPnl * 100) / 100;
  trade.outcome.pnlPct = notional > 0 ? Math.round((totalPnl / notional) * 10000) / 100 : 0;
  trade.outcome.rMultiple = Math.round(rMultiple * 100) / 100;
  trade.outcome.predictionCorrect = totalPnl > 0;
  if (brokerPnl != null) {
    trade.postMortem = trade.postMortem || {};
    trade.postMortem.notes = `broker P&L on this position: ${Math.round(brokerPnl * 100) / 100}`;
  }
  await trade.save();

  console.log(`[reconcile] ${trade.asset}/${trade.strategyId} closed by broker @ ${exitPrice} (${reason}) ${trade.outcome.rMultiple}R`);
}

function startReconciler(intervalMs = 5000) {
  setInterval(() => {
    reconcileOnce().catch((err) => console.error('[reconcile] cycle error:', err.message));
  }, intervalMs);
  console.log(`[reconcile] broker position reconciler running every ${intervalMs}ms`);
}

module.exports = { attachReconciler, startReconciler, reconcileOnce };
