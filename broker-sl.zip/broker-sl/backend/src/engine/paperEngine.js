const { v4: uuidv4 } = require('uuid');
const Trade = require('../models/Trade');
const { BalanceLog } = require('../models/Config');
const broker = require('../execution/brokerExecution');

/**
 * Paper trading engine.
 *
 * IMPORTANT CHANGE: this no longer closes trades from ticks.
 *
 * Ticks arrive only when MetaApi pushes them, so triggering exits from them
 * meant every stop fired late — measured losses averaged -1.74R against a
 * planned -1.0R. The broker now holds SL and TP server-side and executes them
 * itself; positionReconciler.js notices the closure and records it at the
 * broker's real fill price.
 *
 * What ticks still do here: advance the trailing stop and take the TP1
 * partial. Moving a stop late costs a little; triggering one late costs a lot.
 */

let brokerConn = null;
let symbolMap = {};

function attachBroker(connection, symbols) {
  brokerConn = connection;
  symbolMap = symbols || {};
}

function positionSize(entry, sl, balance, riskPerTrade) {
  const riskUsd = balance * riskPerTrade;
  const perUnit = Math.abs(entry - sl);
  if (perUnit <= 0) return { size: 0, riskUsd: 0 };
  return { size: riskUsd / perUnit, riskUsd };
}

async function currentBalance() {
  const latest = await BalanceLog.findOne({}).sort({ ts: -1 }).lean();
  return latest ? latest.balance : null;
}

async function adjustBalance(delta, reason, changedBy = 'engine') {
  const bal = (await currentBalance()) ?? 0;
  const newBal = bal + delta;
  await BalanceLog.create({ balance: newBal, changeReason: reason, changedBy });
  return newBal;
}

async function openTrade({ asset, timeframe, signal, cfg, paramsVersion, newsContext, strategyId = 'default' }) {
  const balance = (await currentBalance()) ?? cfg.paperBalance ?? 10000;
  const riskPerTrade = cfg.riskPerTrade ?? 0.01;
  const { size, riskUsd } = positionSize(signal.entry, signal.sl, balance, riskPerTrade);
  if (size <= 0) return null;

  const trade = await Trade.create({
    tradeId: uuidv4(),
    strategyId,
    asset,
    timeframe,
    direction: signal.signal,
    paramsVersion,
    entryBasis: {
      marketStage: signal.stage,
      session: signal.session,
      htfTrend: signal.htfTrend,
      adx: signal.adx,
      checks: signal.checks,
      bullScore: signal.bullScore,
      bearScore: signal.bearScore,
      netMargin: signal.netMargin,
      confirmationCandle: signal.confirmationCandle,
      newsContext: newsContext || { highImpactEventNearby: false, events: [], blackoutActive: false },
    },
    prediction: {
      setupFingerprint: signal.setupFingerprint,
      predictedSuccessRate: null,
      expectedR: cfg.rrRatio || 2.0,
    },
    execution: {
      entryTime: new Date(signal.time),
      entryPrice: signal.entry,
      sl: signal.sl,
      tp1: signal.tp1,
      tp2: signal.tp2,
      size,
      riskUsd,
    },
    outcome: { status: 'OPEN' },
  });

  if (broker.isExecutionAllowed() && brokerConn && symbolMap[asset]) {
    const res = await broker.placeOrder(brokerConn, {
      symbol: symbolMap[asset],
      direction: signal.signal,
      entryPrice: signal.entry,
      sl: signal.sl,     // broker enforces this server-side — the whole point
      tp: signal.tp2,
      riskUsd,
      comment: `${strategyId.slice(0, 8)}-${asset}`,
    });
    if (res && res.positionId) {
      trade.broker = { positionId: res.positionId, symbol: symbolMap[asset], lots: res.volume || null };
      await trade.save();
    } else {
      // No broker order means nothing enforces the stop. Safer to drop the
      // paper trade than to run one the reconciler can never close.
      console.warn(`[engine] ${asset}/${strategyId}: broker order failed — cancelling paper trade`);
      await Trade.deleteOne({ _id: trade._id });
      return null;
    }
  }

  return trade;
}

/**
 * Tick handler. Manages TP1 partial and trailing stop only — it does NOT
 * close trades on stop breaches any more. The broker does that.
 */
async function manageOpenTrades(asset, tickPrice, currentAtr, cfg, strategyId = 'default') {
  const openTrades = await Trade.find({ asset, strategyId, 'outcome.status': 'OPEN' });
  const lockPct = cfg.hybridLockPct ?? 0.5;
  const trailStartR = cfg.hybridTrailStartR ?? 1.0;
  const trailMult = cfg.trailAtrMult ?? 1.25;

  for (const trade of openTrades) {
    const { direction, execution, outcome } = trade;
    const entry = execution.entryPrice;
    const initialRisk = direction === 'LONG' ? entry - execution.sl : execution.sl - entry;
    if (initialRisk <= 0) continue;

    const favorableMove = direction === 'LONG' ? tickPrice - entry : entry - tickPrice;
    const rNow = favorableMove / initialRisk;
    const positionId = trade.broker && trade.broker.positionId;

    // ── TP1 partial profit lock ──
    if (!outcome.tp1Hit) {
      const tp1Hit = direction === 'LONG' ? tickPrice >= execution.tp1 : tickPrice <= execution.tp1;
      if (tp1Hit) {
        const closedSize = execution.size * lockPct;
        const pnl = direction === 'LONG'
          ? (tickPrice - entry) * closedSize
          : (entry - tickPrice) * closedSize;
        trade.outcome.tp1Hit = true;
        trade.outcome.tp1ClosedSize = closedSize;
        await adjustBalance(pnl, `trade:${trade.tradeId}:tp1_partial`);
        await trade.save();

        if (positionId && trade.broker.lots) {
          const partialLots = parseFloat((trade.broker.lots * lockPct).toFixed(3));
          await broker.closePositionPartially(brokerConn, positionId, partialLots);
        }
      }
      continue;
    }

    // ── Trailing stop: start it, then only ever tighten ──
    if (!outcome.trailingActive) {
      if (rNow >= trailStartR) {
        trade.outcome.trailingActive = true;
        trade.outcome.currentTrailStop = direction === 'LONG'
          ? tickPrice - currentAtr * trailMult
          : tickPrice + currentAtr * trailMult;
        await trade.save();
        if (positionId) await broker.modifyStopLoss(brokerConn, positionId, trade.outcome.currentTrailStop, execution.tp2);
      }
      continue;
    }

    const proposedStop = direction === 'LONG'
      ? tickPrice - currentAtr * trailMult
      : tickPrice + currentAtr * trailMult;

    let moved = false;
    if (direction === 'LONG' && proposedStop > trade.outcome.currentTrailStop) {
      trade.outcome.currentTrailStop = proposedStop;
      moved = true;
    } else if (direction === 'SHORT' && proposedStop < trade.outcome.currentTrailStop) {
      trade.outcome.currentTrailStop = proposedStop;
      moved = true;
    }
    if (moved) {
      await trade.save();
      // Push the tightened stop to the broker — it is the one that will fire it.
      if (positionId) await broker.modifyStopLoss(brokerConn, positionId, trade.outcome.currentTrailStop, execution.tp2);
    }
  }
}

module.exports = {
  positionSize,
  currentBalance,
  adjustBalance,
  openTrade,
  manageOpenTrades,
  attachBroker,
};
