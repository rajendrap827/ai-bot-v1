# Broker-Managed Stop Loss — fixes the -1.74R problem

## The problem this fixes

Measured over 18 closed trades:

| Exit | count | avg R |
|---|---|---|
| TRAIL_STOP | 3 | +2.18 |
| SL | 15 | **-1.74** |

Winners were fine. Losers were not: a stop placed at 1R was averaging -1.74R.

Cause: the engine closed trades from ticks. Ticks only arrive when MetaApi
pushes them, so by the time we saw price beyond the stop it had already moved
past it — and we closed at that later, worse price. Every single loss leaked.

No strategy survives losing 1.7x its planned risk on every loser.

## The fix

The broker already receives the stop with each order and can enforce it
server-side, with no tick latency. So:

- The engine no longer triggers exits from ticks.
- The broker fires SL/TP itself.
- A new reconciler polls broker positions every 5s; when one disappears it
  closes the matching paper trade **at the broker's actual fill price**.
- Ticks still handle the TP1 partial and advance the trailing stop (moving a
  stop late is cheap; triggering one late is not), pushing each new stop level
  to the broker.

## Files

| File | Action |
|---|---|
| `backend/src/engine/positionReconciler.js` | **New.** Polls broker, closes paper trades at real fill prices. |
| `backend/src/engine/paperEngine.js` | **Replace.** Tick-based exit triggering removed. |

## Wiring — two edits in index.js

With the other requires:

```js
const { attachReconciler, startReconciler } = require('./engine/positionReconciler');
```

Right after `attachBroker(feed.connection, SYMBOLS);`:

```js
    attachReconciler(feed.connection, SYMBOLS);
    startReconciler(5000);
```

## Restart

```
systemctl restart scalpbot
journalctl -u scalpbot -f | grep -E "reconcile|OPENED"
```

You should see `[reconcile] broker position reconciler running every 5000ms`
at startup, and `[reconcile] ... closed by broker @ <price> (SL) -1.0R` when a
stop fires.

## One behaviour change worth knowing

If a broker order fails, the paper trade is now cancelled rather than left
running. A paper trade with no broker position behind it has nothing enforcing
its stop and the reconciler could never close it — better to skip the trade.

## What to check in a few days

Re-run the exit-reason breakdown. The SL average should sit near -1.0R rather
than -1.74R. If it does, roughly 0.7R per loser stops leaking — which on this
sample is the difference between a strategy worth studying and one that only
looked broken.
