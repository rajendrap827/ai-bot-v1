/**
 * Shared helpers for the swing backtester: data loading, Pine-equivalent indicators,
 * higher-timeframe aggregation.
 */
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data', 'swing');
const TF_MS = { '5m': 300000, '15m': 900000, '30m': 1800000, '1h': 3600000, '4h': 14400000, '1d': 86400000 };

// strategy id -> entry TF and bias TF (same mapping as the Pine "Auto" setting)
const STRATS = {
  sw5: { tf: '5m', htf: '15m' },
  sw15: { tf: '15m', htf: '1h' },
  sw30: { tf: '30m', htf: '4h' },
  sw1h: { tf: '1h', htf: '1d' },
  // v5: same setups, entry only after a pullback to EMA 9 + rejection candle (rule taken from Raj's Gold notes)
  sw5p: { tf: '5m', htf: '15m', params: { entryMode: 'pullback' }, validate: ['BTC', 'ETH'] },
  sw15p: { tf: '15m', htf: '1h', params: { entryMode: 'pullback' }, validate: ['BTC', 'ETH'] },
  sw30p: { tf: '30m', htf: '4h', params: { entryMode: 'pullback' }, validate: ['BTC', 'ETH'] },
  sw1hp: { tf: '1h', htf: '1d', params: { entryMode: 'pullback' }, validate: ['BTC', 'ETH'] },
};

// Load [[t,o,h,l,c,v],...] into column arrays. Drops broken bars and isolated spikes.
function loadBars(asset, tf) {
  const file = path.join(DATA_DIR, `${asset}_${tf}.json`);
  if (!fs.existsSync(file)) return null;
  const rows = JSON.parse(fs.readFileSync(file, 'utf8'));
  return toCols(rows);
}

function toCols(rows) {
  const keep = [];
  let dropped = 0;
  const okRow = (r) => r && [r[0], r[1], r[2], r[3], r[4]].every(Number.isFinite) && r[2] >= r[3]
    && r[2] >= Math.max(r[1], r[4]) - 1e-9 && r[3] <= Math.min(r[1], r[4]) + 1e-9;
  for (let k = 0; k < rows.length; k++) {
    const r = rows[k];
    if (!okRow(r)) { dropped++; continue; }
    const prev = keep[keep.length - 1];
    if (prev && r[0] <= prev[0]) { dropped++; continue; }
    // isolated bad tick: far (>20%) from both the previous kept bar and the next bar
    const next = rows[k + 1];
    if (prev && okRow(next) && Math.abs(r[4] - prev[4]) / prev[4] > 0.2 && Math.abs(r[4] - next[4]) / next[4] > 0.2) { dropped++; continue; }
    keep.push(r);
  }
  const n = keep.length;
  const t = new Float64Array(n), o = new Float64Array(n), h = new Float64Array(n), l = new Float64Array(n), c = new Float64Array(n);
  for (let i = 0; i < n; i++) { t[i] = keep[i][0]; o[i] = keep[i][1]; h[i] = keep[i][2]; l[i] = keep[i][3]; c[i] = keep[i][4]; }
  return { n, t, o, h, l, c, dropped };
}

// Pine ta.ema: SMA seed over the first `len` values, then alpha = 2/(len+1)
function ema(src, len) {
  const n = src.length, out = new Float64Array(n).fill(NaN);
  const a = 2 / (len + 1);
  let sum = 0;
  for (let i = 0; i < n; i++) {
    if (i < len) {
      sum += src[i];
      if (i === len - 1) out[i] = sum / len;
    } else out[i] = a * src[i] + (1 - a) * out[i - 1];
  }
  return out;
}

// Pine ta.atr(len) = ta.rma(tr, len), RMA seeded with SMA
function atr(b, len = 14) {
  const n = b.n, out = new Float64Array(n).fill(NaN);
  let sum = 0;
  for (let i = 0; i < n; i++) {
    const tr = i === 0 ? b.h[i] - b.l[i]
      : Math.max(b.h[i] - b.l[i], Math.abs(b.h[i] - b.c[i - 1]), Math.abs(b.l[i] - b.c[i - 1]));
    if (i < len) {
      sum += tr;
      if (i === len - 1) out[i] = sum / len;
    } else out[i] = (out[i - 1] * (len - 1) + tr) / len;
  }
  return out;
}

// ta.pivothigh/low(src, L, L): value at bar i means the pivot is at bar i-L (confirmed at i).
// Center must be strictly above every left bar and not below any right bar.
function pivots(arr, L, isHigh) {
  const n = arr.length, out = new Float64Array(n).fill(NaN);
  for (let i = 2 * L; i < n; i++) {
    const cIdx = i - L, v = arr[cIdx];
    let ok = true;
    for (let k = cIdx - L; k <= cIdx + L && ok; k++) {
      if (k === cIdx) continue;
      if (isHigh) ok = k < cIdx ? arr[k] < v : arr[k] <= v;
      else ok = k < cIdx ? arr[k] > v : arr[k] >= v;
    }
    if (ok) out[i] = v;
  }
  return out;
}

// rolling lowest/highest over the last n bars including the current one
function rolling(arr, n, isMin) {
  const N = arr.length, out = new Float64Array(N).fill(NaN);
  const dq = []; // monotonic deque of indices
  for (let i = 0; i < N; i++) {
    while (dq.length && (isMin ? arr[dq[dq.length - 1]] >= arr[i] : arr[dq[dq.length - 1]] <= arr[i])) dq.pop();
    dq.push(i);
    if (dq[0] <= i - n) dq.shift();
    if (i >= n - 1) out[i] = arr[dq[0]];
  }
  return out;
}

// Aggregate entry bars into higher-TF bars by UTC bucket. Returns HTF bars + for each entry bar
// the index of the HTF bar it belongs to.
function aggregate(b, tfMs) {
  const t = [], o = [], h = [], l = [], c = [];
  const map = new Int32Array(b.n);
  let key = null;
  for (let i = 0; i < b.n; i++) {
    const k = Math.floor(b.t[i] / tfMs) * tfMs;
    if (k !== key) {
      key = k;
      t.push(k); o.push(b.o[i]); h.push(b.h[i]); l.push(b.l[i]); c.push(b.c[i]);
    } else {
      const j = t.length - 1;
      if (b.h[i] > h[j]) h[j] = b.h[i];
      if (b.l[i] < l[j]) l[j] = b.l[i];
      c[j] = b.c[i];
    }
    map[i] = t.length - 1;
  }
  const n = t.length;
  return { bars: { n, t: Float64Array.from(t), o: Float64Array.from(o), h: Float64Array.from(h), l: Float64Array.from(l), c: Float64Array.from(c) }, map };
}

// Bias series on an HTF: for each entry bar, values of the PREVIOUS completed HTF bar
// (Pine: request.security(..., expr[1], lookahead_on)).
function biasSeries(b, tfMs, slopeLb, thr) {
  const { bars, map } = aggregate(b, tfMs);
  const e9 = ema(bars.c, 9), e15 = ema(bars.c, 15), a = atr(bars, 14);
  const n = b.n;
  const state = new Int8Array(n);          // 1 up, -1 down, 0 neutral/unknown
  const slope = new Float64Array(n).fill(NaN);
  const v9 = new Float64Array(n).fill(NaN), v15 = new Float64Array(n).fill(NaN), vc = new Float64Array(n).fill(NaN);
  for (let i = 0; i < n; i++) {
    const k = map[i] - 1;
    if (k < slopeLb || !Number.isFinite(e9[k]) || !Number.isFinite(e9[k - slopeLb]) || !(a[k] > 0)) continue;
    const s = (e9[k] - e9[k - slopeLb]) / (slopeLb * a[k]);
    slope[i] = s; v9[i] = e9[k]; v15[i] = e15[k]; vc[i] = bars.c[k];
    if (e9[k] > e15[k] && s >= thr && bars.c[k] > e15[k]) state[i] = 1;
    else if (e9[k] < e15[k] && s <= -thr && bars.c[k] < e15[k]) state[i] = -1;
  }
  return { state, slope, e9: v9, e15: v15, close: vc };
}

module.exports = { DATA_DIR, TF_MS, STRATS, loadBars, toCols, ema, atr, pivots, rolling, aggregate, biasSeries };
