#!/usr/bin/env node
/**
 * Swing MTF Zones backtest (sw5 / sw15 / sw30 / sw1h). READ-ONLY, never touches the bot.
 *
 *   node backtest/swing/run.js --strategy=sw1h --diag        # counts & sizes only, NO results
 *   node backtest/swing/run.js --strategy=all  --diag
 *   node backtest/swing/run.js --strategy=sw1h               # full result, spread + swap
 *
 * Options:
 *   --assets=GOLD,BTC,ETH   --from=2020-01-01  --to=YYYY-MM-DD
 *   --spread=GOLD:0.25,BTC:8,ETH:1.2      (price units, charged once per trade)
 *   --swap=GOLD:0.5222,BTC:18.336,ETH:0.565  (long swap per night in price units; shorts 0)
 *   --log                     write every trade (with events and trend context) to
 *                             backtest/data/swing/trades_<strategy>.jsonl
 *   --set=maxStop:4,minT1R:1  override frozen parameters (diagnostics only - printed as WARNING)
 *
 * Data: backtest/data/swing/<ASSET>_<tf>.json from fetch_tf.js
 */
const fs = require('fs');
const path = require('path');
const { STRATS, DATA_DIR, loadBars } = require('./lib');
const { run, DEFAULTS } = require('./engine');

const SPREAD = { GOLD: 0.25, BTC: 8, ETH: 1.2 };
const SWAP = { GOLD: 0.5222, BTC: 18.336, ETH: 0.565 };
const UNSEEN_END = Date.parse('2024-01-01T00:00:00Z'); // X and zone filters were judged on 2024+ charts

function parseArgs(argv) {
  const a = {};
  for (const s of argv) {
    const m = s.match(/^--([^=]+)(?:=(.*))?$/);
    if (m) a[m[1]] = m[2] === undefined ? true : m[2];
  }
  return a;
}
function kv(str, into) {
  if (!str) return into;
  for (const p of String(str).split(',')) { const [k, v] = p.split(':'); if (k && v !== undefined) into[k.trim()] = parseFloat(v); }
  return into;
}
const f = (x, d = 3) => (Number.isFinite(x) ? (x > 0 ? '+' : '') + x.toFixed(d) : '-');
const pct = (a, b) => (b ? ((100 * a) / b).toFixed(1) : '-');
const avg = (a) => (a.length ? a.reduce((s, x) => s + x, 0) / a.length : NaN);
function q(arr, p) {
  if (!arr.length) return NaN;
  const s = [...arr].sort((x, y) => x - y);
  return s[Math.min(s.length - 1, Math.floor(p * s.length))];
}

function diagReport(id, asset, res, months) {
  const { diag, setups, trades } = res;
  const L = [];
  L.push(`  bias: UP ${pct(diag.biasUp, diag.bars)}%  DOWN ${pct(diag.biasDn, diag.bars)}%  NEUTRAL ${pct(diag.bars - diag.biasUp - diag.biasDn, diag.bars)}%   avg zones ${(diag.zoneSum / Math.max(1, diag.bars)).toFixed(1)}   trendline breaks ${diag.tlBreaks}`);
  if (diag.armed) L.push(`  pullback: armed ${diag.armed}  cancelled (bias ${diag.pbCancelBias}, beyond SL ${diag.pbCancelSL}, expired ${diag.pbExpired})`);
  L.push(`  entry candles ${diag.cSet}  -> skip stop ${diag.cBig}, skip T1 ${diag.cNear}  -> trades ${trades.length}  (${(trades.length / months).toFixed(1)}/month)`);
  const by = (key) => {
    const g = {};
    for (const s of setups) g[s[key]] = (g[s[key]] || 0) + 1;
    return Object.entries(g).map(([k, v]) => `${k} ${v}`).join('  ');
  };
  L.push(`  setup types: ${by('setup')}`);
  L.push(`  candles:     ${by('conf')}`);
  const rk = setups.map((s) => s.riskAtr), tr = setups.map((s) => s.t1R);
  L.push(`  stop (x ATR)  p10 ${q(rk, 0.1).toFixed(2)}  p25 ${q(rk, 0.25).toFixed(2)}  median ${q(rk, 0.5).toFixed(2)}  p75 ${q(rk, 0.75).toFixed(2)}  p90 ${q(rk, 0.9).toFixed(2)}`);
  L.push(`  T1 (x R)      p10 ${q(tr, 0.1).toFixed(2)}  p25 ${q(tr, 0.25).toFixed(2)}  median ${q(tr, 0.5).toFixed(2)}  p75 ${q(tr, 0.75).toFixed(2)}  p90 ${q(tr, 0.9).toFixed(2)}`);
  L.push('  by setup type:       n   median stop(xATR)   median T1(xR)');
  const types = [...new Set(setups.map((s) => s.setup))].sort();
  for (const ty of types) {
    const g = setups.filter((s) => s.setup === ty);
    L.push(`    ${ty.padEnd(10)} ${String(g.length).padStart(6)}   ${q(g.map((s) => s.riskAtr), 0.5).toFixed(2).padStart(10)}   ${q(g.map((s) => s.t1R), 0.5).toFixed(2).padStart(14)}`);
  }
  const stops = [2, 2.5, 3, 4, 5, Infinity];
  L.push('  setups within max stop (count only, ignores overlap): ' + stops.map((ms) => `${ms === Infinity ? 'any' : ms + 'ATR'} ${setups.filter((x) => x.riskAtr <= ms).length}`).join('  '));
  return L;
}

function stats(trades) {
  const n = trades.length;
  const net = trades.map((t) => t.netR), gross = trades.map((t) => t.grossR);
  const wins = net.filter((x) => x > 0).length;
  const sorted = [...net].sort((a, b) => b - a);
  const tot = net.reduce((s, x) => s + x, 0);
  return {
    n, win: pct(wins, n), gross: avg(gross), net: avg(net), total: tot,
    wo3: n > 3 ? (tot - sorted[0] - sorted[1] - sorted[2]) / (n - 3) : NaN,
    t1: pct(trades.filter((t) => t.stageReached >= 1).length, n),
    spread: avg(trades.map((t) => t.spreadR)), swap: avg(trades.map((t) => t.swapR)),
    hours: avg(trades.map((t) => t.hours)),
  };
}

function group(trades, keyFn, order) {
  const g = {};
  for (const t of trades) { const k = keyFn(t); (g[k] = g[k] || []).push(t); }
  const keys = order ? order.filter((k) => g[k]) : Object.keys(g).sort();
  return keys.map((k) => `    ${String(k).padEnd(14)} n ${String(g[k].length).padStart(4)}  net ${f(avg(g[k].map((t) => t.netR)))}`);
}

function fullReport(trades) {
  const s = stats(trades);
  if (!s.n) return ['  no trades'];
  const L = [];
  L.push(`  trades ${s.n}  win ${s.win}%  T1 hit ${s.t1}%  avg hold ${s.hours.toFixed(1)}h`);
  L.push(`  avg R gross ${f(s.gross)}   NET ${f(s.net)}  (spread ${s.spread.toFixed(3)}R, swap ${s.swap.toFixed(3)}R per trade)   total net ${f(s.total, 1)}R`);
  L.push(`  without best 3: net ${f(s.wo3)}`);
  const unseen = trades.filter((t) => Date.parse(t.entryT) < UNSEEN_END), seen = trades.filter((t) => Date.parse(t.entryT) >= UNSEEN_END);
  L.push(`  2020-2023 (unseen): n ${unseen.length} net ${f(avg(unseen.map((t) => t.netR)))}    2024+: n ${seen.length} net ${f(avg(seen.map((t) => t.netR)))}`);
  L.push('  by year:'); L.push(...group(trades, (t) => t.entryT.slice(0, 4)));
  L.push('  by direction:'); L.push(...group(trades, (t) => t.dir, ['LONG', 'SHORT']));
  L.push('  by setup:'); L.push(...group(trades, (t) => t.setup));
  L.push('  by candle:'); L.push(...group(trades, (t) => t.conf));
  L.push('  by exit:'); L.push(...group(trades, (t) => t.exitReason, ['initial', 'breakeven', 'step', 'structure']));
  L.push('  against a bigger-TF trend (contra):'); L.push(...group(trades, (t) => (t.contra ? 'contra' : 'aligned'), ['aligned', 'contra']));
  return L;
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  const ids = !args.strategy || args.strategy === 'all' ? ['sw5', 'sw15', 'sw30', 'sw1h'] : args.strategy === 'allp' ? ['sw5p', 'sw15p', 'sw30p', 'sw1hp'] : String(args.strategy).split(',');
  for (const id of ids) if (!STRATS[id]) { console.error(`unknown strategy ${id} (${Object.keys(STRATS).join(', ')}, all)`); process.exit(1); }
  const assets = args.assets ? String(args.assets).toUpperCase().split(',') : ['GOLD', 'BTC', 'ETH'];
  const fromMs = Date.parse((args.from || '2020-01-01') + 'T00:00:00Z');
  const toMs = args.to ? Date.parse(args.to + 'T23:59:59Z') : Infinity;
  const spread = kv(args.spread, { ...SPREAD });
  const swap = kv(args.swap, { ...SWAP });
  const params = kv(args.set, {});
  const diagMode = !!args.diag;

  console.log(`\n=== Swing MTF Zones ${diagMode ? 'DIAGNOSTICS (no results shown)' : 'BACKTEST'} ===`);
  if (Object.keys(params).length) console.log(`WARNING: parameters overridden: ${JSON.stringify(params)} - not the frozen rules`);
  for (const k of Object.keys(params)) if (!(k in DEFAULTS)) { console.error(`unknown parameter ${k}`); process.exit(1); }
  if (!diagMode) console.log(`spread ${JSON.stringify(spread)}  long swap/night ${JSON.stringify(swap)}`);

  for (const id of ids) {
    const { tf, htf } = STRATS[id];
    const sParams = { ...(STRATS[id].params || {}), ...params };
    console.log(`\n##### ${id}: entry ${tf}, bias ${htf}${STRATS[id].params ? '  ' + JSON.stringify(STRATS[id].params) : ''}`);
    const all = [];
    const perAsset = {};
    for (const asset of assets) {
      const b = loadBars(asset, tf);
      if (!b || b.n < 3000) { console.log(`\n== ${asset}: no data (run fetch_tf.js --tf=${tf})`); continue; }
      const first = new Date(Math.max(b.t[0], fromMs)), last = new Date(Math.min(b.t[b.n - 1], toMs));
      const months = Math.max(1, (last - first) / (30.44 * 86400000));
      const t0 = Date.now();
      const res = run(b, { tf, htf, asset, fromMs, toMs, params: sParams, spread: spread[asset] || 0, swapLong: swap[asset] || 0 });
      console.log(`\n== ${asset}  ${first.toISOString().slice(0, 10)} -> ${last.toISOString().slice(0, 10)}  bars ${b.n} (dropped ${b.dropped})  ${((Date.now() - t0) / 1000).toFixed(1)}s${res.open ? '  (1 open trade not counted)' : ''}`);
      const lines = diagMode ? diagReport(id, asset, res, months) : fullReport(res.trades);
      lines.forEach((x) => console.log(x));
      perAsset[asset] = res.trades;
      all.push(...res.trades);
    }
    if (args.log && !diagMode) {
      const file = path.join(DATA_DIR, `trades_${id}.jsonl`);
      fs.writeFileSync(file, all.map((t) => JSON.stringify({ strategy: id, ...t })).join('\n') + (all.length ? '\n' : ''));
    }
    if (diagMode || !all.length) continue;

    console.log(`\n== ${id} ALL ASSETS`);
    fullReport(all).forEach((x) => console.log(x));
    // pass bar (agreed before any result)
    const s = stats(all);
    const years = {};
    for (const t of all) { const y = t.entryT.slice(0, 4); (years[y] = years[y] || []).push(t.netR); }
    const yKeys = Object.keys(years);
    const posYears = yKeys.filter((y) => avg(years[y]) > 0).length;
    const unseen = all.filter((t) => Date.parse(t.entryT) < UNSEEN_END);
    const checks = [
      [`net avg >= +0.10R (${f(s.net)})`, s.net >= 0.1],
      [`every asset positive (${assets.map((a) => `${a} ${f(avg((perAsset[a] || []).map((t) => t.netR)))}`).join(', ')})`, assets.every((a) => avg((perAsset[a] || []).map((t) => t.netR)) > 0)],
      [`most years positive (${posYears}/${yKeys.length})`, posYears > yKeys.length / 2],
      [`2020-2023 unseen positive (${f(avg(unseen.map((t) => t.netR)))}, n ${unseen.length})`, avg(unseen.map((t) => t.netR)) > 0],
      [`>= 30 trades per asset (${assets.map((a) => `${a} ${(perAsset[a] || []).length}`).join(', ')})`, assets.every((a) => (perAsset[a] || []).length >= 30)],
    ];
    console.log('  PASS BAR:');
    for (const [txt, ok] of checks) console.log(`    ${ok ? 'PASS' : 'FAIL'}  ${txt}`);
    console.log(`  => ${checks.every((x) => x[1]) ? 'PASSES - candidate for forward test' : 'DOES NOT PASS'}`);
    const va = STRATS[id].validate;
    if (va) {
      // rule was derived from GOLD notes -> the honest test is on the other assets only
      const vt = all.filter((t) => va.includes(t.asset));
      const vs = stats(vt);
      const vUnseen = vt.filter((t) => Date.parse(t.entryT) < UNSEEN_END);
      const vchecks = [
        [`net avg >= +0.10R (${f(vs.net)}, n ${vs.n})`, vs.net >= 0.1],
        [`each positive (${va.map((a) => `${a} ${f(avg((perAsset[a] || []).map((t) => t.netR)))}`).join(', ')})`, va.every((a) => avg((perAsset[a] || []).map((t) => t.netR)) > 0)],
        [`2020-2023 positive (${f(avg(vUnseen.map((t) => t.netR)))})`, avg(vUnseen.map((t) => t.netR)) > 0],
        [`>= 30 trades each`, va.every((a) => (perAsset[a] || []).length >= 30)],
      ];
      console.log(`  VALIDATION on ${va.join('+')} (not used to make the rule):`);
      for (const [txt, ok] of vchecks) console.log(`    ${ok ? 'PASS' : 'FAIL'}  ${txt}`);
      console.log(`  => validation ${vchecks.every((x) => x[1]) ? 'PASSES' : 'DOES NOT PASS'}`);
    }
  }
  if (args.log && !diagMode) console.log(`\ntrade logs: ${DATA_DIR}/trades_<strategy>.jsonl`);
}

main();
