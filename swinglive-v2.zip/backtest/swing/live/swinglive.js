#!/usr/bin/env node
/**
 * Swing live (semi-auto): finds setups of one or more swing strategies (default sw15p + sw5p) on GOLD every
 * closed bar and sends a Telegram alert with ✅ Take / ❌ Skip buttons. On Take it opens the trade on the DEMO
 * account (3 positions: 25% TP T1, 25% TP T2, 50% runner) and moves the stop loss exactly like the backtest
 * engine. On Skip / no answer nothing is traded. Every alert, decision and result is written to
 * backtest/data/swing/live_trades.jsonl. Each strategy has its own state, one open trade at a time per strategy.
 *
 * Separate from the scalp bot: own service, own positions (comment "<strategy> <id> <k>"), never touches others.
 * Orders only when SWING_ORDERS_ENABLED=true AND the MetaApi account is a DEMO account; otherwise paper mode.
 *
 * .env (backend/.env):
 *   TG_BOT_TOKEN=...              from @BotFather
 *   TG_CHAT_ID=...                your chat id (the service tells you if it is missing)
 *   SWING_ORDERS_ENABLED=true     demo orders (default: paper = alerts + simulated tracking only)
 *   SWING_RISK_PCT=0.5            % of balance risked per trade
 *   SWING_STRATEGIES=sw15p,sw5p   which strategies run
 *   SWING_SYMBOL=XAUUSDm          default SYMBOL_GOLD or XAUUSDm
 *   SWING_DECIDE_MIN=12           minutes to answer an alert (5m strategies: max 2 bars = 10 min)
 *
 * Run: node backtest/swing/live/swinglive.js   (normally as systemd service "swinglive")
 */
const fs = require('fs');
const path = require('path');
const { STRATS, TF_MS, DATA_DIR, toCols } = require('../lib');
const { run } = require('../engine');

const BACKEND = path.resolve(__dirname, '..', '..', '..');
const env = { ...loadEnv(), ...Object.fromEntries(Object.entries(process.env).filter(([k]) => /^(SWING_|TG_)/.test(k))) };
const IDS = String(env.SWING_STRATEGIES || env.SWING_STRATEGY || 'sw15p,sw5p').split(',').map((s) => s.trim()).filter((s) => STRATS[s]);
const ASSET = 'GOLD';
const SYMBOL = env.SWING_SYMBOL || env.SYMBOL_GOLD || 'XAUUSDm';
const ORDERS_WANTED = String(env.SWING_ORDERS_ENABLED || '').toLowerCase() === 'true';
const RISK_PCT = Number(env.SWING_RISK_PCT || 0.5);
const DECIDE_MIN = Number(env.SWING_DECIDE_MIN || 12);
const MAX_SLIP_R = 0.3;          // refuse the entry if price moved more than 0.3R from the alert price
const KEEP_BARS = 15000, RUN_BARS = 12000;
const TG = env.TG_BOT_TOKEN ? `https://api.telegram.org/bot${env.TG_BOT_TOKEN}` : null;
const CHAT = env.TG_CHAT_ID ? String(env.TG_CHAT_ID) : null;
const LOG = path.join(DATA_DIR, 'live_trades.jsonl');

// ---------------------------------------------------------------- utils
function loadEnv() {
  const p = path.join(BACKEND, '.env'); const e = {};
  if (fs.existsSync(p)) for (const line of fs.readFileSync(p, 'utf8').split('\n')) {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (m) e[m[1]] = m[2].replace(/^['"]|['"]$/g, '');
  }
  return e;
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const log = (...a) => console.log(new Date().toISOString().slice(0, 19), ...a);
const dubai = (ms) => new Date(ms + 4 * 3600000).toISOString().slice(0, 16).replace('T', ' ');
const fx = (x) => (Number.isFinite(x) ? x.toFixed(2) : '-');
let chain = Promise.resolve();
const serial = (fn) => (chain = chain.then(fn, fn).catch((e) => log('ERR', e && e.stack || e)));
function writeLog(rec) { fs.appendFileSync(LOG, JSON.stringify(rec) + '\n'); }

// ---------------------------------------------------------------- per-strategy context
function makeCtx(id) {
  const S = STRATS[id], TF = S.tf, TFMS = TF_MS[TF];
  const stateFile = path.join(DATA_DIR, `live_state_${id}.json`);
  // v1 kept sw15p state in live_state.json
  const legacy = path.join(DATA_DIR, 'live_state.json');
  if (id === 'sw15p' && !fs.existsSync(stateFile) && fs.existsSync(legacy)) fs.renameSync(legacy, stateFile);
  let st;
  try { st = JSON.parse(fs.readFileSync(stateFile, 'utf8')); } catch { st = { lastBarT: 0, pending: null, open: null, seen: [] }; }
  return {
    id, S, TF, TFMS, st, rows: [], lastFetch: 0,
    cache: path.join(DATA_DIR, `live_${ASSET}_${TF}.json`),
    decideMs: Math.min(DECIDE_MIN, 2 * TFMS / 60000) * 60000,
    save() { fs.writeFileSync(stateFile, JSON.stringify(this.st, null, 1)); },
  };
}
const ctxs = IDS.map(makeCtx);
const byId = (id) => ctxs.find((x) => x.id === id);

// ---------------------------------------------------------------- telegram
async function tg(method, body) {
  if (!TG) return null;
  try {
    const r = await fetch(`${TG}/${method}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const j = await r.json();
    if (!j.ok) log('telegram', method, j.description);
    return j.result;
  } catch (e) { log('telegram error', method, e.message); return null; }
}
const say = (text, extra = {}) => (CHAT ? tg('sendMessage', { chat_id: CHAT, text, parse_mode: 'HTML', disable_web_page_preview: true, ...extra }) : null);

async function pollTelegram() {
  if (!TG) { log('TG_BOT_TOKEN missing in .env - alerts disabled'); return; }
  let offset = 0;
  for (;;) {
    let ups = null;
    try {
      const r = await fetch(`${TG}/getUpdates`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ offset, timeout: 25 }) });
      ups = (await r.json()).result || [];
    } catch (e) { await sleep(5000); continue; }
    for (const u of ups) {
      offset = u.update_id + 1;
      const msg = u.message, cb = u.callback_query;
      const chatId = String((msg && msg.chat.id) || (cb && cb.message.chat.id) || '');
      if (!CHAT) {
        if (msg) await tg('sendMessage', { chat_id: chatId, text: `Your chat id: ${chatId}\nAdd to backend/.env:\nTG_CHAT_ID=${chatId}\nthen: systemctl restart swinglive` });
        log('chat id seen:', chatId);
        continue;
      }
      if (chatId !== CHAT) continue; // only Raj
      if (cb) serial(() => onButton(cb));
      else if (msg && msg.text) serial(() => onText(msg));
    }
  }
}

async function onText(msg) {
  const txt = msg.text.trim();
  // a reply to an alert = the reason for the decision (saved for the review analysis)
  if (msg.reply_to_message) {
    for (const c of ctxs) {
      const rec = (c.st.seen || []).find((x) => x.msgId === msg.reply_to_message.message_id);
      if (rec) { writeLog({ type: 'reason', strategy: c.id, id: rec.id, text: txt, at: new Date().toISOString() }); await say('📝 Reason saved'); return; }
    }
  }
  if (/^\/status/.test(txt)) return say(statusText());
  if (/^\/start|^\/help/.test(txt)) return say(`Swing live ${IDS.join(' + ')} · ${SYMBOL} · ${mode()}\n/status - open trades, pending alerts, last bar\nReply to an alert with text = reason (saved).`);
}

function mode() { return ORDERS_WANTED ? (conn.ready ? 'DEMO orders' : 'DEMO orders (not connected)') : 'paper (no orders)'; }
function statusText() {
  const L = [`<b>Swing live</b> · ${SYMBOL} · ${mode()}`];
  for (const c of ctxs) {
    const o = c.st.open, p = c.st.pending;
    L.push(`\n<b>${c.id}</b> (${c.TF}) last bar ${c.st.lastBarT ? dubai(c.st.lastBarT).slice(5) : '-'}`,
      p ? `pending: ${p.dirTxt} ${p.setup} until ${dubai(p.deadline).slice(11)}` : 'pending: none',
      o ? `open: ${o.dirTxt} @ ${fx(o.fill)} SL ${fx(o.sl)} stage ${o.stage || 0}` : 'open: none');
  }
  return L.join('\n');
}

// ---------------------------------------------------------------- broker (MetaApi)
const conn = { ready: false, rpc: null, account: null, spec: null };
async function connectBroker() {
  if (!env.METAAPI_TOKEN || !env.METAAPI_ACCOUNT_ID) throw new Error('METAAPI_TOKEN / METAAPI_ACCOUNT_ID missing in .env');
  const MetaApi = require('metaapi.cloud-sdk').default;
  const api = new MetaApi(env.METAAPI_TOKEN);
  conn.account = await api.metatraderAccountApi.getAccount(env.METAAPI_ACCOUNT_ID);
  if (!ORDERS_WANTED) return;
  const rpc = conn.account.getRPCConnection();
  await rpc.connect();
  await rpc.waitSynchronized();
  const info = await rpc.getAccountInformation();
  if (!/DEMO/i.test(String(info.type || ''))) {
    log('NOT a demo account (type=' + info.type + ') - orders disabled');
    await say(`⛔ Account type is "${info.type}", not DEMO. Orders disabled, paper mode only.`);
    return;
  }
  conn.rpc = rpc;
  conn.spec = await rpc.getSymbolSpecification(SYMBOL);
  conn.ready = true;
  log('broker ready', info.broker, info.server, 'balance', info.balance, 'spec', JSON.stringify({ c: conn.spec.contractSize, min: conn.spec.minVolume, step: conn.spec.volumeStep }));
}

// ---------------------------------------------------------------- candles
async function initCandles(c) {
  const src = fs.existsSync(c.cache) ? c.cache : path.join(DATA_DIR, `${ASSET}_${c.TF}.json`);
  c.rows = fs.existsSync(src) ? JSON.parse(fs.readFileSync(src, 'utf8')).slice(-KEEP_BARS) : [];
  await updateCandles(c, true);
}
async function updateCandles(c, fill) {
  const have = c.rows.length ? c.rows[c.rows.length - 1][0] : 0;
  const byT = new Map(c.rows.map((r) => [r[0], r]));
  let start;
  for (let k = 0; k < (fill ? 40 : 1); k++) {
    const batch = await conn.account.getHistoricalCandles(SYMBOL, c.TF, start ? new Date(start) : undefined, fill ? 1000 : 50);
    if (!batch || !batch.length) break;
    let minT = Infinity;
    for (const x of batch) { const t = new Date(x.time).getTime(); minT = Math.min(minT, t); byT.set(t, [t, x.open, x.high, x.low, x.close, x.tickVolume || 0]); }
    if (minT <= have || !fill) break;
    start = minT - 1000;
  }
  const now = Date.now();
  c.rows = [...byT.values()].filter((r) => r[0] + c.TFMS <= now).sort((a, b) => a[0] - b[0]).slice(-KEEP_BARS);
  fs.writeFileSync(c.cache, JSON.stringify(c.rows));
}
const bars = (c) => toCols(c.rows.slice(-RUN_BARS));
const engineOpts = (c, extra) => ({ tf: c.S.tf, htf: c.S.htf, asset: ASSET, params: c.S.params, ...extra });

// ---------------------------------------------------------------- strategy
async function onBarClose(c, barT) {
  if (c.st.pending && Date.now() > c.st.pending.deadline) await decide(c, c.st.pending.id, 'expired');
  if (c.st.open) await manage(c);
  if (c.st.open || c.st.pending) return;
  const r = run(bars(c), engineOpts(c, { fromMs: barT - 60 * c.TFMS, signalsOnly: true }));
  const sig = r.signals.find((x) => x.entryT === barT);
  if (sig) await alert(c, sig);
}

async function alert(c, sig) {
  const id = new Date(sig.entryT).toISOString().slice(0, 16).replace(/[-:T]/g, '');
  const dir = sig.dir === 1 ? 'LONG' : 'SHORT';
  const deadline = sig.entryT + c.TFMS + c.decideMs;
  const ctx = Object.entries(sig.ctxEntry || {}).map(([k, v]) => `${k} ${v.state === 1 ? 'UP' : v.state === -1 ? 'DOWN' : 'NEUTRAL'}`).join(' · ');
  const t1R = Math.abs(sig.levels[0] - sig.entry) / sig.risk, t2R = Math.abs(sig.levels[1] - sig.entry) / sig.risk;
  const text = [`${sig.dir === 1 ? '🟢' : '🔴'} <b>GOLD ${c.TF} ${dir}</b> · ${sig.setup}/${sig.conf} · <i>${c.id}</i>`,
    `Entry ~ <b>${fx(sig.entry)}</b>   SL ${fx(sig.sl)} (${fx(sig.riskAtr)} ATR, ${fx(sig.risk)})`,
    `T1 ${fx(sig.levels[0])} (${t1R.toFixed(1)}R)   T2 ${fx(sig.levels[1])} (${t2R.toFixed(1)}R)`,
    sig.zone ? `Zone ${fx(sig.zone.bottom)} – ${fx(sig.zone.top)} · ${sig.zone.touches}x` : '',
    `Trend: ${ctx}${sig.contra ? '  ⚠️ against a bigger TF' : ''}`,
    `Bar ${dubai(sig.entryT)} Dubai · answer by <b>${dubai(deadline).slice(11)}</b>`,
    `<i>${mode()}</i>`].filter(Boolean).join('\n');
  const m = await say(text, { reply_markup: { inline_keyboard: [[{ text: '✅ Take', callback_data: `take:${c.id}:${id}` }, { text: '❌ Skip', callback_data: `skip:${c.id}:${id}` }]] } });
  c.st.pending = { id, sig, deadline, dirTxt: dir, setup: sig.setup, msgId: m && m.message_id, alertAt: Date.now() };
  c.st.seen = [...(c.st.seen || []), { id, msgId: m && m.message_id }].slice(-200);
  c.save();
  writeLog({ type: 'alert', strategy: c.id, id, symbol: SYMBOL, entryT: new Date(sig.entryT).toISOString(), dir, setup: sig.setup, conf: sig.conf,
    entry: sig.entry, sl: sig.sl, levels: sig.levels.slice(0, 4), riskAtr: sig.riskAtr, zone: sig.zone, ctxEntry: sig.ctxEntry, contra: sig.contra, feat: sig.feat, mode: mode() });
  log('ALERT', c.id, id, dir, sig.setup, sig.entry, sig.sl);
}

async function onButton(cb) {
  const parts = String(cb.data || '').split(':');
  await tg('answerCallbackQuery', { callback_query_id: cb.id });
  // v1 buttons had no strategy ("take:<id>") -> sw15p
  const [act, sid, id] = parts.length === 3 ? parts : [parts[0], 'sw15p', parts[1]];
  const c = byId(sid);
  if (!c) { await say('Unknown strategy in this alert.'); return; }
  await decide(c, id, act === 'take' ? 'take' : 'skip');
}

async function decide(c, id, decision) {
  const p = c.st.pending;
  if (!p || p.id !== id) { await say('This alert is no longer active.'); return; }
  if (decision === 'take' && Date.now() > p.deadline) decision = 'expired';
  c.st.pending = null; c.save();
  const head = `${c.id} ${p.dirTxt} ${p.setup} (${dubai(p.sig.entryT)})`;
  if (p.msgId) await tg('editMessageReplyMarkup', { chat_id: CHAT, message_id: p.msgId, reply_markup: { inline_keyboard: [] } });
  if (decision !== 'take') {
    writeLog({ type: 'decision', strategy: c.id, id, decision, at: new Date().toISOString() });
    await say(decision === 'skip' ? `❌ Skipped ${head}\n<i>Reply to the alert with the reason (optional).</i>` : `⌛ Expired ${head} - not traded`);
    return;
  }
  await enter(c, p);
}

function roundVol(v) {
  const step = (conn.spec && conn.spec.volumeStep) || 0.01, min = (conn.spec && conn.spec.minVolume) || 0.01;
  return Math.max(min, Math.floor(v / step + 1e-9) * step);
}

async function enter(c, p) {
  const sig = p.sig, dir = sig.dir;
  let fill = sig.entry, vols = null, positions = [], balance = null;
  if (conn.ready) {
    const px = await conn.rpc.getSymbolPrice(SYMBOL);
    fill = dir === 1 ? px.ask : px.bid;
  }
  const risk = dir === 1 ? fill - sig.sl : sig.sl - fill;
  if (!(risk > 0) || Math.abs(fill - sig.entry) > MAX_SLIP_R * sig.risk) {
    writeLog({ type: 'decision', strategy: c.id, id: p.id, decision: 'take-refused', fill, at: new Date().toISOString() });
    await say(`⚠️ ${c.id} not entered: price ${fx(fill)} moved too far from ${fx(sig.entry)} (SL ${fx(sig.sl)}).`);
    return;
  }
  if (conn.ready) {
    const info = await conn.rpc.getAccountInformation();
    balance = info.balance;
    const csz = conn.spec.contractSize || 100;
    const total = (balance * RISK_PCT / 100) / (risk * csz);
    vols = [roundVol(total * 0.25), roundVol(total * 0.25), roundVol(total * 0.5)];
    const tps = [sig.levels[0], sig.levels[1], undefined];
    for (let k = 0; k < 3; k++) {
      const opt = { comment: `${c.id} ${p.id} ${k + 1}` };
      try {
        const res = dir === 1 ? await conn.rpc.createMarketBuyOrder(SYMBOL, vols[k], sig.sl, tps[k], opt)
          : await conn.rpc.createMarketSellOrder(SYMBOL, vols[k], sig.sl, tps[k], opt);
        positions.push({ k: k + 1, positionId: res.positionId, orderId: res.orderId, vol: vols[k], tp: tps[k] });
      } catch (e) {
        log('order failed', c.id, k + 1, e.message);
        await say(`⚠️ ${c.id} order ${k + 1}/3 failed: ${e.message}`);
      }
    }
    if (!positions.length) { writeLog({ type: 'decision', strategy: c.id, id: p.id, decision: 'take-failed', at: new Date().toISOString() }); return; }
  }
  const force = { ...sig, entry: fill, risk, riskAtr: risk / sig.atr };
  c.st.open = { id: p.id, force, fill, sl: sig.sl, dirTxt: p.dirTxt, positions, vols, balance, stage: 0, nEvents: 0, openedAt: Date.now() };
  c.save();
  writeLog({ type: 'decision', strategy: c.id, id: p.id, decision: 'take', fill, risk, vols, balance, positions, at: new Date().toISOString() });
  const money = balance ? ` · risk ≈ ${(balance * RISK_PCT / 100).toFixed(2)} (${RISK_PCT}%)` : '';
  await say(`✅ <b>Entered</b> ${c.id} ${p.dirTxt} @ ${fx(fill)}  SL ${fx(sig.sl)}${vols ? `\nlots ${vols.join(' / ')} (TP T1 / TP T2 / runner)` : '\n(paper)'}${money}`);
}

async function brokerPositions(c, o) {
  if (!conn.ready) return [];
  const all = await conn.rpc.getPositions();
  const ids = new Set(o.positions.map((x) => String(x.positionId)));
  return all.filter((x) => ids.has(String(x.id)) || String(x.comment || '').startsWith(`${c.id} ${o.id}`));
}

async function manage(c) {
  const o = c.st.open;
  const r = run(bars(c), engineOpts(c, { force: o.force }));
  const sim = r.pos || null;
  const done = !sim && r.trades.length ? r.trades[0] : null;
  const ev = (sim ? sim.events : done ? done.events : []) || [];
  for (const e of ev.slice(o.nEvents || 0)) {
    if (e.type === 'T1' || e.type === 'T2') await say(`🎯 ${c.id} ${e.type} hit @ ${fx(e.price)} (${e.r > 0 ? '+' : ''}${(e.r * 4).toFixed(2)}R on that part)`);
    if (e.type === 'SL_MOVE') await say(`🔒 ${c.id} SL ${fx(e.from)} → <b>${fx(e.to)}</b> (${e.reason})`);
  }
  o.nEvents = ev.length;
  if (sim) {
    o.stage = sim.stage;
    if (Math.abs(sim.sl - o.sl) > 1e-6) {
      o.sl = sim.sl;
      for (const bp of await brokerPositions(c, o)) {
        try { await conn.rpc.modifyPosition(bp.id, sim.sl, bp.takeProfit); } catch (e) { log('modify failed', bp.id, e.message); await say(`⚠️ ${c.id} SL modify failed (${bp.id}): ${e.message}`); }
      }
    }
  }
  const open = await brokerPositions(c, o);
  if (done) {
    for (const bp of open) { try { await conn.rpc.closePosition(bp.id, {}); } catch (e) { log('close failed', bp.id, e.message); } }
    await finish(c, o, done);
  } else if (conn.ready && o.positions.length && !open.length) {
    await finish(c, o, null); // the broker closed everything (SL / TPs)
  }
  if (c.st.open) c.save();
}

async function finish(c, o, simTrade) {
  let profit = null;
  if (conn.ready) {
    try {
      const d = await conn.rpc.getDealsByTimeRange(new Date(o.openedAt - 60000), new Date());
      const deals = Array.isArray(d) ? d : (d && d.deals) || [];
      const ids = new Set(o.positions.map((x) => String(x.positionId)));
      profit = deals.filter((x) => ids.has(String(x.positionId))).reduce((s, x) => s + (x.profit || 0) + (x.commission || 0) + (x.swap || 0), 0);
    } catch (e) { log('deals', e.message); }
  }
  const riskMoney = o.balance ? o.balance * RISK_PCT / 100 : null;
  const liveR = profit != null && riskMoney ? profit / riskMoney : null;
  writeLog({ type: 'result', strategy: c.id, id: o.id, simR: simTrade ? simTrade.grossR : null, exitReason: simTrade ? simTrade.exitReason : 'broker', profit, liveR, closedAt: new Date().toISOString() });
  await say(`🏁 <b>Closed</b> ${c.id} ${o.dirTxt} ${o.id}\nsim ${simTrade ? (simTrade.grossR > 0 ? '+' : '') + simTrade.grossR.toFixed(2) + 'R (' + simTrade.exitReason + ')' : '-'}${profit != null ? `\ndemo P/L ${profit.toFixed(2)}${liveR != null ? ` (${liveR > 0 ? '+' : ''}${liveR.toFixed(2)}R)` : ''}` : ''}`);
  c.st.open = null; c.save();
}

// ---------------------------------------------------------------- main loop
async function tick(c) {
  const lastClosed = Math.floor((Date.now() - 5000) / c.TFMS) * c.TFMS - c.TFMS;
  if (lastClosed > c.st.lastBarT && Date.now() - c.lastFetch > 60000) {
    c.lastFetch = Date.now();
    await updateCandles(c, false);
    if (c.rows.length && c.rows[c.rows.length - 1][0] >= lastClosed) {
      c.lastFetch = 0;
      c.st.lastBarT = c.rows[c.rows.length - 1][0]; c.save();
      await onBarClose(c, c.st.lastBarT);
    }
  } else if (c.st.pending && Date.now() > c.st.pending.deadline) await decide(c, c.st.pending.id, 'expired');
}

async function main() {
  log(`swinglive ${IDS.join(',')} ${SYMBOL} orders=${ORDERS_WANTED} risk=${RISK_PCT}%`);
  if (!IDS.length) throw new Error('no valid strategy in SWING_STRATEGIES');
  await connectBroker();
  for (const c of ctxs) {
    await initCandles(c);
    if (!c.st.lastBarT && c.rows.length) { c.st.lastBarT = c.rows[c.rows.length - 1][0]; c.save(); }
    log(c.id, 'candles', c.rows.length, 'last', c.rows.length ? new Date(c.rows[c.rows.length - 1][0]).toISOString() : '-');
  }
  pollTelegram();
  await say(`▶️ Swing live started · ${ctxs.map((c) => `${c.id} (${c.TF})`).join(' + ')} · ${SYMBOL} · ${mode()}\n/status for details`);
  for (;;) {
    for (const c of ctxs) await serial(() => tick(c));
    await sleep(15000);
  }
}

if (require.main === module) {
  main().catch(async (e) => { log('FATAL', e && e.stack || e); await say(`⛔ swinglive stopped: ${e.message}`); process.exit(1); });
} else {
  // test hooks
  module.exports = { _t: { ctxs, conn, onBarClose, decide, manage } };
}
