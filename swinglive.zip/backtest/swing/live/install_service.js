#!/usr/bin/env node
/**
 * Installs swinglive as a systemd service (starts on boot, restarts on failure).
 * Run from ~/ai-bot-v1/scalp-bot/backend:   node backtest/swing/live/install_service.js
 * Logs:  journalctl -u swinglive -f
 */
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const backend = path.resolve(__dirname, '..', '..', '..');
const unit = `[Unit]
Description=Swing live semi-auto (Telegram alerts, demo orders)
After=network-online.target
Wants=network-online.target

[Service]
WorkingDirectory=${backend}
ExecStart=${process.execPath} ${path.join(backend, 'backtest', 'swing', 'live', 'swinglive.js')}
Restart=always
RestartSec=20

[Install]
WantedBy=multi-user.target
`;
fs.writeFileSync('/etc/systemd/system/swinglive.service', unit);
execSync('systemctl daemon-reload && systemctl enable swinglive && systemctl restart swinglive', { stdio: 'inherit' });
console.log('swinglive started. Logs: journalctl -u swinglive -n 30 --no-pager');
