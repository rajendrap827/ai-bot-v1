#!/usr/bin/env node
/**
 * Swing live (semi-auto): finds sw15p setups on GOLD 15m every closed bar, sends a Telegram alert with
 * ✅ Take / ❌ Skip buttons. On Take it opens the trade on the DEMO account (3 positions: 25% TP T1,
 * 25% TP T2, 50% runner) and moves the stop loss exactly like the backtest engine. On Skip / no answer
 * nothing is traded. Every alert, decision and result is written to backtest/data/swing/live_trades.jsonl.
 *
 * Separate from the scalp bot: own service, own positions (comment "sw15p <id>"), never touches others.
 * Orders only when SWING_ORDERS_ENABLED=true AND the MetaApi account is a DEMO account; otherwise paper mode.
 *
 * .env (backend/.env):
 *   TG_BOT_TOKEN=...            from @BotFather
 *   TG_CHAT_ID=...              your chat id (the service tells you if it is missing)
 *   SWING_ORDERS_ENABLED=true   demo orders (default: paper = alerts + simulated tracking only)
 *   SWING_RISK_PCT=0.5          % of balance risked per trade
 *   SWING_SYMBOL=XAUUSDm        default SYMBOL_GOLD or XAUUSDm
 *   SWING_DECIDE_MIN=12         minutes to answer an alert
 *
 * Run: node backtest/swing/live/swinglive.js   (normally as systemd service "swinglive")
 */
const fs = require('fs');
const path = require('path');
const { STRATS, TF_MS, DATA_DIR, toCols } = require('../lib');
const { run } = require('../engine');

const BACKEND = path.resolve(__dirname, '..', '..', '..');
const env = { ...loadEnv(), ...Object.fromEntries(Object.entries(process.env).filter(([k]) => /^(SWING_|TG_)/.test(k))) };
const STRAT_ID = env.SWING_STRATEGY || 'sw15p';
const S = STRATS[STRAT_ID];
const ASSET = 'GOLD';
const TF = S.tf, TFMS = TF_MS[S.tf];
const SYMBOL = env.SWING_SYMBOL || env.SYMBOL_GOLD || 'XAUUSDm';
const ORDERS_WANTED = String(env.SWING_ORDERS_ENABLED || '').toLowerCase() === 'true';
const RISK_PCT = Number(env.SWING_RISK_PCT || 0.5);
const DECIDE_MIN = Number(env.SWING_DECIDE_MIN || 12);
const MAX_SLIP_R = 0.3;          // refuse the entry if price moved more than 0.3R from the alert price
const KEEP_BARS = 15000, RUN_BARS = 12000;
const TG = env.TG_BOT_TOKEN ? `https://api.telegram.org/bot${env.TG_BOT_TOKEN}` : null;
let CHAT = env.TG_CHAT_ID ? String(env.TG_CHAT_ID) : null;

const CACHE = path.join(DATA_DIR, `live_${ASSET}_${TF}.json`);
const STATE = path.join(DATA_DIR, 'live_state.json');
const LOG = path.join(DATA_DIR, 'live_trades.jsonl');

// ---------------------------------------------------------------- utils
function loadEnv() {
  const p = path.join(BACKEND, '.env'); const e = {};
  if (fs.existsSync(p)) for (const line of fs.readFileSync(p, 'utf8').split('\n')) {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (m) e[m[1]] = m[2].replace(/^['"]|['"]$/g, '');
  }
  return e;
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const log = (...a) => console.log(new Date().toISOString().slice(0, 19), ...a);
const dubai = (ms) => new Date(ms + 4 * 3600000).toISOString().slice(0, 16).replace('T', ' ');
const fx = (x) => (Number.isFinite(x) ? x.toFixed(2) : '-');
let chain = Promise.resolve();
const serial = (fn) => (chain = chain.then(fn, fn).catch((e) => log('ERR', e && e.stack || e)));

function loadState() {
  try { return JSON.parse(fs.readFileSync(STATE, 'utf8')); } catch { return { lastBarT: 0, pending: null, open: null, seen: [] }; }
}
let st = loadState();
const save = () => fs.writeFileSync(STATE, JSON.stringify(st, null, 1));
function writeLog(rec) { fs.appendFileSync(LOG, JSON.stringify(rec) + '\n'); }

// ---------------------------------------------------------------- telegram
async function tg(method, body) {
  if (!TG) return null;
  try {
    const r = await fetch(`${TG}/${method}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const j = await r.json();
    if (!j.ok) log('telegram', method, j.description);
    return j.result;
  } catch (e) { log('telegram error', method, e.message); return null; }
}
const say = (text, extra = {}) => (CHAT ? tg('sendMessage', { chat_id: CHAT, text, parse_mode: 'HTML', disable_web_page_preview: true, ...extra }) : null);

async function pollTelegram() {
  if (!TG) { log('TG_BOT_TOKEN missing in .env - alerts disabled'); return; }
  let offset = 0;
  for (;;) {
    let ups = null;
    try {
      const r = await fetch(`${TG}/getUpdates`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ offset, timeout: 25 }) });
      ups = (await r.json()).result || [];
    } catch (e) { await sleep(5000); continue; }
    for (const u of ups) {
      offset = u.update_id + 1;
      const msg = u.message, cb = u.callback_query;
      const chatId = String((msg && msg.chat.id) || (cb && cb.message.chat.id) || '');
      if (!CHAT) {
        if (msg) await tg('sendMessage', { chat_id: chatId, text: `Your chat id: ${chatId}\nAdd to backend/.env:\nTG_CHAT_ID=${chatId}\nthen: systemctl restart swinglive` });
        log('chat id seen:', chatId);
        continue;
      }
      if (chatId !== CHAT) continue; // only Raj
      if (cb) serial(() => onButton(cb));
      else if (msg && msg.text) serial(() => onText(msg));
    }
  }
}

async function onText(msg) {
  const txt = msg.text.trim();
  // a reply to an alert = the reason for the decision (saved for the review analysis)
  if (msg.reply_to_message) {
    const rec = (st.seen || []).find((x) => x.msgId === msg.reply_to_message.message_id);
    if (rec) { writeLog({ type: 'reason', id: rec.id, text: txt, at: new Date().toISOString() }); await say('📝 Reason saved'); return; }
  }
  if (/^\/status/.test(txt)) return say(statusText());
  if (/^\/start|^\/help/.test(txt)) return say(`Swing live ${STRAT_ID} · ${SYMBOL} · ${mode()}\n/status - open trade, pending alert, last bar\nReply to an alert with text = reason (saved).`);
}

function mode() { return ORDERS_WANTED ? (conn.ready ? 'DEMO orders' : 'DEMO orders (not connected)') : 'paper (no orders)'; }
function statusText() {
  const o = st.open, p = st.pending;
  return [`<b>Swing live</b> ${STRAT_ID} · ${SYMBOL} · ${mode()}`,
    `last bar: ${st.lastBarT ? dubai(st.lastBarT) : '-'} Dubai`,
    p ? `pending: ${p.dirTxt} ${p.setup} until ${dubai(p.deadline)}` : 'pending: none',
    o ? `open: ${o.dirTxt} @ ${fx(o.fill)} SL ${fx(o.sl)} stage ${o.stage || 0}` : 'open: none'].join('\n');
}

// ---------------------------------------------------------------- broker (MetaApi)
const conn = { ready: false, rpc: null, account: null, spec: null };
async function connectBroker() {
  if (!env.METAAPI_TOKEN || !env.METAAPI_ACCOUNT_ID) throw new Error('METAAPI_TOKEN / METAAPI_ACCOUNT_ID missing in .env');
  const MetaApi = require('metaapi.cloud-sdk').default;
  const api = new MetaApi(env.METAAPI_TOKEN);
  conn.account = await api.metatraderAccountApi.getAccount(env.METAAPI_ACCOUNT_ID);
  if (!ORDERS_WANTED) return;
  const rpc = conn.account.getRPCConnection();
  await rpc.connect();
  await rpc.waitSynchronized();
  const info = await rpc.getAccountInformation();
  if (!/DEMO/i.test(String(info.type || ''))) {
    log('NOT a demo account (type=' + info.type + ') - orders disabled');
    await say(`⛔ Account type is "${info.type}", not DEMO. Orders disabled, paper mode only.`);
    return;
  }
  conn.rpc = rpc;
  conn.spec = await rpc.getSymbolSpecification(SYMBOL);
  conn.ready = true;
  log('broker ready', info.broker, info.server, 'balance', info.balance, 'spec', JSON.stringify({ c: conn.spec.contractSize, min: conn.spec.minVolume, step: conn.spec.volumeStep }));
}

// ---------------------------------------------------------------- candles
async function fetchCandles(startMs, count) {
  return conn.account.getHistoricalCandles(SYMBOL, TF, startMs ? new Date(startMs) : undefined, count);
}
let rows = [];
async function initCandles() {
  const src = fs.existsSync(CACHE) ? CACHE : path.join(DATA_DIR, `${ASSET}_${TF}.json`);
  rows = fs.existsSync(src) ? JSON.parse(fs.readFileSync(src, 'utf8')) : [];
  rows = rows.slice(-KEEP_BARS);
  await updateCandles(true);
}
async function updateCandles(fill) {
  const have = rows.length ? rows[rows.length - 1][0] : 0;
  const byT = new Map(rows.map((r) => [r[0], r]));
  let start;
  for (let k = 0; k < (fill ? 40 : 1); k++) {
    const batch = await fetchCandles(start, fill ? 1000 : 50);
    if (!batch || !batch.length) break;
    let minT = Infinity;
    for (const x of batch) { const t = new Date(x.time).getTime(); minT = Math.min(minT, t); byT.set(t, [t, x.open, x.high, x.low, x.close, x.tickVolume || 0]); }
    if (minT <= have || !fill) break;
    start = minT - 1000;
  }
  const now = Date.now();
  rows = [...byT.values()].filter((r) => r[0] + TFMS <= now).sort((a, b) => a[0] - b[0]).slice(-KEEP_BARS);
  fs.writeFileSync(CACHE, JSON.stringify(rows));
}
const bars = () => toCols(rows.slice(-RUN_BARS));

// ---------------------------------------------------------------- strategy
function engineOpts(extra) { return { tf: S.tf, htf: S.htf, asset: ASSET, params: S.params, ...extra }; }

async function onBarClose(barT) {
  // pending alert past its deadline
  if (st.pending && Date.now() > st.pending.deadline) await decide(st.pending.id, 'expired');
  if (st.open) await manage();
  if (st.open || st.pending) return;
  const b = bars();
  const r = run(b, engineOpts({ fromMs: barT - 60 * TFMS, signalsOnly: true }));
  const sig = r.signals.find((x) => x.entryT === barT);
  if (sig) await alert(sig);
}

async function alert(sig) {
  const id = `${new Date(sig.entryT).toISOString().slice(0, 16).replace(/[-:T]/g, '')}`;
  const dir = sig.dir === 1 ? 'LONG' : 'SHORT';
  const deadline = sig.entryT + TFMS + DECIDE_MIN * 60000;
  const c = sig.ctxEntry || {};
  const ctx = Object.entries(c).map(([k, v]) => `${k} ${v.state === 1 ? 'UP' : v.state === -1 ? 'DOWN' : 'NEUTRAL'}`).join(' · ');
  const t1R = Math.abs(sig.levels[0] - sig.entry) / sig.risk, t2R = Math.abs(sig.levels[1] - sig.entry) / sig.risk;
  const text = [`${sig.dir === 1 ? '🟢' : '🔴'} <b>GOLD ${TF} ${dir}</b> · ${sig.setup}/${sig.conf}`,
    `Entry ~ <b>${fx(sig.entry)}</b>   SL ${fx(sig.sl)} (${fx(sig.riskAtr)} ATR, ${fx(sig.risk)})`,
    `T1 ${fx(sig.levels[0])} (${t1R.toFixed(1)}R)   T2 ${fx(sig.levels[1])} (${t2R.toFixed(1)}R)`,
    sig.zone ? `Zone ${fx(sig.zone.bottom)} – ${fx(sig.zone.top)} · ${sig.zone.touches}x` : '',
    `Trend: ${ctx}${sig.contra ? '  ⚠️ against a bigger TF' : ''}`,
    `Bar ${dubai(sig.entryT)} Dubai · answer by <b>${dubai(deadline).slice(11)}</b>`,
    `<i>${mode()}</i>`].filter(Boolean).join('\n');
  const m = await say(text, { reply_markup: { inline_keyboard: [[{ text: '✅ Take', callback_data: `take:${id}` }, { text: '❌ Skip', callback_data: `skip:${id}` }]] } });
  st.pending = { id, sig, deadline, dirTxt: dir, setup: sig.setup, msgId: m && m.message_id, alertAt: Date.now() };
  st.seen = [...(st.seen || []), { id, msgId: m && m.message_id }].slice(-200);
  save();
  writeLog({ type: 'alert', id, strategy: STRAT_ID, symbol: SYMBOL, entryT: new Date(sig.entryT).toISOString(), dir, setup: sig.setup, conf: sig.conf,
    entry: sig.entry, sl: sig.sl, levels: sig.levels.slice(0, 4), riskAtr: sig.riskAtr, zone: sig.zone, ctxEntry: sig.ctxEntry, contra: sig.contra, feat: sig.feat, mode: mode() });
  log('ALERT', id, dir, sig.setup, sig.entry, sig.sl);
}

async function onButton(cb) {
  const [act, id] = String(cb.data || '').split(':');
  await tg('answerCallbackQuery', { callback_query_id: cb.id });
  await decide(id, act === 'take' ? 'take' : 'skip');
}

async function decide(id, decision) {
  const p = st.pending;
  if (!p || p.id !== id) { await say('This alert is no longer active.'); return; }
  const late = Date.now() > p.deadline;
  if (decision === 'take' && late) decision = 'expired';
  st.pending = null; save();
  const head = `${p.dirTxt} ${p.setup} (${dubai(p.sig.entryT)})`;
  if (decision !== 'take') {
    writeLog({ type: 'decision', id, decision, at: new Date().toISOString() });
    if (p.msgId) await tg('editMessageReplyMarkup', { chat_id: CHAT, message_id: p.msgId, reply_markup: { inline_keyboard: [] } });
    await say(decision === 'skip' ? `❌ Skipped ${head}\n<i>Reply to the alert with the reason (optional).</i>` : `⌛ Expired ${head} - not traded`);
    return;
  }
  if (p.msgId) await tg('editMessageReplyMarkup', { chat_id: CHAT, message_id: p.msgId, reply_markup: { inline_keyboard: [] } });
  await enter(p);
}

function roundVol(v) {
  const step = (conn.spec && conn.spec.volumeStep) || 0.01, min = (conn.spec && conn.spec.minVolume) || 0.01;
  return Math.max(min, Math.floor(v / step + 1e-9) * step);
}

async function enter(p) {
  const sig = p.sig, dir = sig.dir;
  let fill = sig.entry, vols = null, positions = [], balance = null;
  if (conn.ready) {
    const px = await conn.rpc.getSymbolPrice(SYMBOL);
    fill = dir === 1 ? px.ask : px.bid;
  }
  const risk = dir === 1 ? fill - sig.sl : sig.sl - fill;
  if (!(risk > 0) || Math.abs(fill - sig.entry) > MAX_SLIP_R * sig.risk) {
    writeLog({ type: 'decision', id: p.id, decision: 'take-refused', fill, at: new Date().toISOString() });
    await say(`⚠️ Not entered: price ${fx(fill)} moved too far from ${fx(sig.entry)} (SL ${fx(sig.sl)}).`);
    return;
  }
  if (conn.ready) {
    const info = await conn.rpc.getAccountInformation();
    balance = info.balance;
    const csz = conn.spec.contractSize || 100;
    const total = (balance * RISK_PCT / 100) / (risk * csz);
    vols = [roundVol(total * 0.25), roundVol(total * 0.25), roundVol(total * 0.5)];
    const tps = [sig.levels[0], sig.levels[1], undefined];
    for (let k = 0; k < 3; k++) {
      const opt = { comment: `${STRAT_ID} ${p.id} ${k + 1}` };
      try {
        const res = dir === 1 ? await conn.rpc.createMarketBuyOrder(SYMBOL, vols[k], sig.sl, tps[k], opt)
          : await conn.rpc.createMarketSellOrder(SYMBOL, vols[k], sig.sl, tps[k], opt);
        positions.push({ k: k + 1, positionId: res.positionId, orderId: res.orderId, vol: vols[k], tp: tps[k] });
      } catch (e) {
        log('order failed', k + 1, e.message);
        await say(`⚠️ Order ${k + 1}/3 failed: ${e.message}`);
      }
    }
    if (!positions.length) { writeLog({ type: 'decision', id: p.id, decision: 'take-failed', at: new Date().toISOString() }); return; }
  }
  const force = { ...sig, entry: fill, risk, riskAtr: risk / sig.atr };
  st.open = { id: p.id, force, fill, sl: sig.sl, dirTxt: p.dirTxt, positions, vols, balance, stage: 0, nEvents: 0, openedAt: Date.now() };
  save();
  writeLog({ type: 'decision', id: p.id, decision: 'take', fill, risk, vols, balance, positions, at: new Date().toISOString() });
  const money = balance ? ` · risk ≈ ${(balance * RISK_PCT / 100).toFixed(2)} (${RISK_PCT}%)` : '';
  await say(`✅ <b>Entered</b> ${p.dirTxt} @ ${fx(fill)}  SL ${fx(sig.sl)}${vols ? `\nlots ${vols.join(' / ')} (TP T1 / TP T2 / runner)` : '\n(paper)'}${money}`);
}

async function brokerPositions(o) {
  if (!conn.ready) return [];
  const all = await conn.rpc.getPositions();
  const ids = new Set(o.positions.map((x) => String(x.positionId)));
  return all.filter((x) => ids.has(String(x.id)) || String(x.comment || '').startsWith(`${STRAT_ID} ${o.id}`));
}

async function manage() {
  const o = st.open;
  const r = run(bars(), engineOpts({ force: o.force }));
  const sim = r.pos || null;
  const done = !sim && r.trades.length ? r.trades[0] : null;
  const ev = (sim ? sim.events : done ? done.events : []) || [];
  for (const e of ev.slice(o.nEvents || 0)) {
    if (e.type === 'T1' || e.type === 'T2') await say(`🎯 ${e.type} hit @ ${fx(e.price)} (${e.r > 0 ? '+' : ''}${(e.r * 4).toFixed(2)}R on that part)`);
    if (e.type === 'SL_MOVE') await say(`🔒 SL ${fx(e.from)} → <b>${fx(e.to)}</b> (${e.reason})`);
  }
  o.nEvents = ev.length;
  if (sim) {
    o.stage = sim.stage;
    if (Math.abs(sim.sl - o.sl) > 1e-6) {
      o.sl = sim.sl;
      for (const bp of await brokerPositions(o)) {
        try { await conn.rpc.modifyPosition(bp.id, sim.sl, bp.takeProfit); } catch (e) { log('modify failed', bp.id, e.message); await say(`⚠️ SL modify failed (${bp.id}): ${e.message}`); }
      }
    }
  }
  const open = await brokerPositions(o);
  if (done) {
    for (const bp of open) { try { await conn.rpc.closePosition(bp.id, {}); } catch (e) { log('close failed', bp.id, e.message); } }
    await finish(o, done);
  } else if (conn.ready && o.positions.length && !open.length) {
    await finish(o, null); // the broker closed everything (SL / TPs)
  }
  if (st.open) save();
}

async function finish(o, simTrade) {
  let profit = null;
  if (conn.ready) {
    try {
      const d = await conn.rpc.getDealsByTimeRange(new Date(o.openedAt - 60000), new Date());
      const deals = Array.isArray(d) ? d : (d && d.deals) || [];
      const ids = new Set(o.positions.map((x) => String(x.positionId)));
      profit = deals.filter((x) => ids.has(String(x.positionId))).reduce((s, x) => s + (x.profit || 0) + (x.commission || 0) + (x.swap || 0), 0);
    } catch (e) { log('deals', e.message); }
  }
  const riskMoney = o.balance ? o.balance * RISK_PCT / 100 : null;
  const liveR = profit != null && riskMoney ? profit / riskMoney : null;
  writeLog({ type: 'result', id: o.id, simR: simTrade ? simTrade.grossR : null, exitReason: simTrade ? simTrade.exitReason : 'broker', profit, liveR, closedAt: new Date().toISOString() });
  await say(`🏁 <b>Closed</b> ${o.dirTxt} ${o.id}\nsim ${simTrade ? (simTrade.grossR > 0 ? '+' : '') + simTrade.grossR.toFixed(2) + 'R (' + simTrade.exitReason + ')' : '-'}${profit != null ? `\ndemo P/L ${profit.toFixed(2)}${liveR != null ? ` (${liveR > 0 ? '+' : ''}${liveR.toFixed(2)}R)` : ''}` : ''}`);
  st.open = null; save();
}

// ---------------------------------------------------------------- main loop
let lastFetch = 0; // reset after a successful bar; throttles retries to 1/min (weekend, broker lag)
async function main() {
  log(`swinglive ${STRAT_ID} ${SYMBOL} orders=${ORDERS_WANTED} risk=${RISK_PCT}%`);
  await connectBroker();
  await initCandles();
  log('candles', rows.length, 'last', rows.length ? new Date(rows[rows.length - 1][0]).toISOString() : '-');
  pollTelegram();
  await say(`▶️ Swing live started · ${STRAT_ID} · ${SYMBOL} · ${mode()}\n/status for details`);
  if (!st.lastBarT && rows.length) { st.lastBarT = rows[rows.length - 1][0]; save(); }
  for (;;) {
    await serial(async () => {
      const lastClosed = Math.floor((Date.now() - 5000) / TFMS) * TFMS - TFMS;
      if (lastClosed > st.lastBarT && Date.now() - lastFetch > 60000) {
        lastFetch = Date.now();
        await updateCandles(false);
        if (rows.length && rows[rows.length - 1][0] >= lastClosed) {
          lastFetch = 0;
          st.lastBarT = rows[rows.length - 1][0]; save();
          await onBarClose(st.lastBarT);
        }
      } else if (st.pending && Date.now() > st.pending.deadline) await decide(st.pending.id, 'expired');
    });
    await sleep(15000);
  }
}

if (require.main === module) {
  main().catch(async (e) => { log('FATAL', e && e.stack || e); await say(`⛔ swinglive stopped: ${e.message}`); process.exit(1); });
} else {
  // test hooks
  module.exports = { _t: { setRows: (r) => { rows = r; }, conn, st: () => st, setSt: (x) => { st = x; }, onBarClose, decide, manage } };
}
