/**
 * Opening Range Breakout at the US open (strategyId: 'orb')
 *
 * PRE-REGISTERED 2026-10-07, before any result was seen. Do not tune after testing.
 *
 *   range      high/low of the first 15 minutes after 09:30 New York time
 *              (13:30 UTC in US summer time, 14:30 UTC in winter), weekdays only
 *   breakout   a 5m candle closes above the range high (long) / below the low (short)
 *   support    the broken range high becomes support (low becomes resistance)
 *   entry      a later candle touches the level (within 0.1 x ATR), is bullish
 *              (close > open) and closes above the level -> enter at the close
 *   cancel     a close more than 0.5 x ATR back through the level, or no entry
 *              within 24 bars (2 hours) of the breakout
 *   stop       below min(retest low, level) - 0.1 x ATR, at least 0.5 ATR away,
 *              skip if wider than 3 x ATR
 *   target     2R (Fixed RR). Trailing mode uses the 5m ATR.
 *   limit      one trade per direction per day. Short: mirror.
 */

const DAY = 86400000;

const defaults = {
  orbTol: 0.1,
  orbCancel: 0.5,
  orbMaxWait: 24,
  orbSlBuf: 0.1,
  orbMinStop: 0.5,
  orbMaxStop: 3.0,
  orbRR: 2.0,
};

const window = 400;
const trailTf = 5;

// US daylight time: second Sunday of March to first Sunday of November
function nthSunday(year, month, n) {
  const first = new Date(Date.UTC(year, month, 1));
  const firstSun = 1 + ((7 - first.getUTCDay()) % 7);
  return Date.UTC(year, month, firstSun + 7 * (n - 1));
}
function usOpenUTC(dayStartMs) {
  const y = new Date(dayStartMs).getUTCFullYear();
  const edt = dayStartMs >= nthSunday(y, 2, 2) && dayStartMs < nthSunday(y, 10, 1);
  return dayStartMs + (edt ? 13.5 : 14.5) * 3600000;
}

function atrSeries(c, p = 14) {
  const out = new Array(c.length);
  let prev = null;
  for (let i = 0; i < c.length; i++) {
    const tr = i === 0 ? c[i].h - c[i].l
      : Math.max(c[i].h - c[i].l, Math.abs(c[i].h - c[i - 1].c), Math.abs(c[i].l - c[i - 1].c));
    prev = prev == null ? tr : (prev * (p - 1) + tr) / p;
    out[i] = prev;
  }
  return out;
}

function compute(candles, cfg) {
  const k = { ...defaults, ...(cfg || {}) };
  const n = candles.length;
  if (n < 60) return { signal: null, reason: 'warmup' };
  const tOf = (x) => new Date(x.t).getTime();
  const lastT = tOf(candles[n - 1]);
  const dayStart = Math.floor(lastT / DAY) * DAY;
  const wd = new Date(dayStart).getUTCDay();
  if (wd === 0 || wd === 6) return { signal: null, reason: 'weekend' };

  const open = usOpenUTC(dayStart);
  const orEnd = open + 15 * 60000;
  if (lastT < orEnd) return { signal: null, reason: 'before_range' };

  // Opening range: the three 5m bars 09:30, 09:35, 09:40 ET
  let orh = -Infinity, orl = Infinity, orBars = 0, first = -1;
  for (let i = 0; i < n; i++) {
    const t = tOf(candles[i]);
    if (t >= open && t < orEnd) { orh = Math.max(orh, candles[i].h); orl = Math.min(orl, candles[i].l); orBars++; }
    if (first < 0 && t >= orEnd) first = i;
  }
  if (orBars < 3 || first < 0) return { signal: null, reason: 'no_range' };

  const atr = atrSeries(candles);
  let up = { state: 0 }, dn = { state: 0 }; // 0 idle, 1 broken, 2 done
  let result = null;

  for (let i = first; i < n; i++) {
    const b = candles[i], a = atr[i];
    const isLast = i === n - 1;

    // LONG side
    if (up.state === 1) {
      if (i - up.bar > k.orbMaxWait || b.c < orh - k.orbCancel * a) up.state = 2;
      else if (i > up.bar && b.l <= orh + k.orbTol * a && b.c > orh && b.c > b.o) {
        up.state = 2;
        const sl = Math.min(Math.min(b.l, orh) - k.orbSlBuf * a, b.c - k.orbMinStop * a);
        const risk = b.c - sl;
        if (isLast && risk > 0 && risk <= k.orbMaxStop * a) result = { dir: 'LONG', entry: b.c, sl, tp: b.c + k.orbRR * risk, a };
      }
    }
    if (up.state === 0 && b.c > orh) up = { state: 1, bar: i };

    // SHORT side
    if (dn.state === 1) {
      if (i - dn.bar > k.orbMaxWait || b.c > orl + k.orbCancel * a) dn.state = 2;
      else if (i > dn.bar && b.h >= orl - k.orbTol * a && b.c < orl && b.c < b.o) {
        dn.state = 2;
        const sl = Math.max(Math.max(b.h, orl) + k.orbSlBuf * a, b.c + k.orbMinStop * a);
        const risk = sl - b.c;
        if (isLast && !result && risk > 0 && risk <= k.orbMaxStop * a) result = { dir: 'SHORT', entry: b.c, sl, tp: b.c - k.orbRR * risk, a };
      }
    }
    if (dn.state === 0 && b.c < orl) dn = { state: 1, bar: i };
  }

  if (!result) return { signal: null, reason: 'no_setup' };
  const long = result.dir === 'LONG';
  return {
    signal: result.dir,
    time: candles[n - 1].t,
    entry: result.entry,
    sl: result.sl,
    tp1: result.tp,
    tp2: result.tp,
    atr: result.a,
    stage: long ? 'ADVANCING' : 'DECLINING',
    htfTrend: 'NA',
    adx: 0,
    bullScore: long ? 3 : 0,
    bearScore: long ? 0 : 3,
    score: 3,
    oppScore: 0,
    netMargin: 3,
    confirmationCandle: true,
    checks: {
      stage: { passed: false, weight: 0, value: 'not_used' },
      aov: { passed: true, weight: 1, value: 'or_retest' },
      pattern: { passed: true, weight: 1, value: long ? 'bull_candle' : 'bear_candle' },
      ema: { passed: false, weight: 0, value: 'not_used' },
      smc: { passed: true, weight: 1, value: 'or_breakout' },
      volume: { passed: false, weight: 0, value: 'not_used' },
    },
    setupFingerprint: `ORB-${result.dir}`,
  };
}

module.exports = { compute, defaults, window, trailTf, usesHtf: false, name: 'US Open Range Breakout + retest (5m)', usOpenUTC };
