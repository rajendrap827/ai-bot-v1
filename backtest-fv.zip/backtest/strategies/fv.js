/**
 * Fabio Valentini-style trend pullback into a low-volume area (strategyId: 'fv')
 *
 * PRE-REGISTERED 2026-10-07, before any result was seen. Do not tune after testing.
 * Approximation: the original relies on real exchange volume / order flow; here the
 * volume profile is built from MT5 tick volume.
 *
 *   timeframe  5m
 *   trend      structure (last swing high > previous AND last swing low > previous,
 *              pivots 3 bars each side) AND ADX(14) >= 25      (bearish: mirror)
 *   leg        the impulse from the swing low before the last swing high up to it
 *   LVN        tick-volume profile of the leg in 20 price bins; lowest-volume bin
 *              within the middle 60% of the leg = the low-volume zone
 *   entry      after the swing high is confirmed, within 36 bars: a bar trades into
 *              the zone (low <= zone top) and is a strong green candle (body >= 60%
 *              of range and >= 0.5 x ATR) closing above the zone top -> enter at close
 *   cancel     a close below the leg low, or 36 bars passed
 *   stop       zone bottom - 0.1 x ATR, at least 0.5 ATR away, skip if > 3 ATR
 *   target     3R (Fixed RR). Trailing mode uses the 5m ATR.
 *   limit      one trade per leg. Short: mirror.
 */

const defaults = {
  fvPiv: 3,
  fvAdxMin: 25,
  fvBins: 20,
  fvMaxWait: 36,
  fvBodyPct: 0.6,
  fvBodyAtr: 0.5,
  fvSlBuf: 0.1,
  fvMinStop: 0.5,
  fvMaxStop: 3.0,
  fvRR: 3.0,
};

const window = 600; // 50 hours of 5m bars
const trailTf = 5;

function atrSeries(c, p = 14) {
  const out = new Array(c.length);
  let prev = null;
  for (let i = 0; i < c.length; i++) {
    const tr = i === 0 ? c[i].h - c[i].l
      : Math.max(c[i].h - c[i].l, Math.abs(c[i].h - c[i - 1].c), Math.abs(c[i].l - c[i - 1].c));
    prev = prev == null ? tr : (prev * (p - 1) + tr) / p;
    out[i] = prev;
  }
  return out;
}

// Wilder ADX
function adxSeries(c, p = 14) {
  const n = c.length;
  const out = new Array(n).fill(null);
  let trS = 0, pS = 0, mS = 0, adx = null, dxSum = 0, dxCount = 0;
  for (let i = 1; i < n; i++) {
    const up = c[i].h - c[i - 1].h, dn = c[i - 1].l - c[i].l;
    const pdm = up > dn && up > 0 ? up : 0;
    const mdm = dn > up && dn > 0 ? dn : 0;
    const tr = Math.max(c[i].h - c[i].l, Math.abs(c[i].h - c[i - 1].c), Math.abs(c[i].l - c[i - 1].c));
    if (i <= p) { trS += tr; pS += pdm; mS += mdm; if (i < p) continue; }
    else { trS = trS - trS / p + tr; pS = pS - pS / p + pdm; mS = mS - mS / p + mdm; }
    const pdi = trS ? 100 * pS / trS : 0, mdi = trS ? 100 * mS / trS : 0;
    const dx = pdi + mdi ? 100 * Math.abs(pdi - mdi) / (pdi + mdi) : 0;
    if (adx == null) { dxSum += dx; dxCount++; if (dxCount === p) adx = dxSum / p; }
    else adx = (adx * (p - 1) + dx) / p;
    out[i] = adx;
  }
  return out;
}

function pivots(c, L) {
  const highs = [], lows = [];
  for (let i = L; i < c.length - L; i++) {
    let isH = true, isL = true;
    for (let k = i - L; k <= i + L; k++) {
      if (k === i) continue;
      if (k < i ? c[k].h >= c[i].h : c[k].h > c[i].h) isH = false;
      if (k < i ? c[k].l <= c[i].l : c[k].l < c[i].l) isL = false;
      if (!isH && !isL) break;
    }
    if (isH) highs.push(i);
    if (isL) lows.push(i);
  }
  return { highs, lows };
}

// Lowest tick-volume price bin inside the middle 60% of [lo, hi]
function lvnZone(c, from, to, lo, hi, bins, dir) {
  if (!(hi > lo)) return null;
  const w = (hi - lo) / bins;
  const vol = new Array(bins).fill(0);
  let total = 0;
  // Spread each bar's volume over the bins in proportion to how much of its range
  // falls in each bin (symmetric for longs and shorts).
  for (let i = from; i <= to; i++) {
    const b = c[i];
    const v = b.v || 0;
    if (v <= 0) continue;
    const rng = b.h - b.l;
    for (let j = 0; j < bins; j++) {
      const bb = lo + j * w, bt = bb + w;
      if (rng > 0) {
        const ov = Math.min(b.h, bt) - Math.max(b.l, bb);
        if (ov > 0) vol[j] += (v * ov) / rng;
      } else if (b.c >= bb && b.c < bt) vol[j] += v;
    }
    total += v;
  }
  if (total <= 0) return null;
  // Lowest-volume bin in the middle 60%. Ties go to the bin nearest the leg's middle,
  // then to the one nearer the END of the leg (reached first on the pullback). Scanning
  // from the leg's end makes long and short legs choose mirror-image bins.
  const s = Math.floor(bins * 0.2), e = bins - s - 1;
  const mid = (bins - 1) / 2;
  const tol = 1e-9 * total;
  const order = [];
  if (dir === 1) for (let j = e; j >= s; j--) order.push(j); // long leg ends at the top
  else for (let j = s; j <= e; j++) order.push(j);           // short leg ends at the bottom
  let best = order[0];
  for (const j of order) {
    if (vol[j] < vol[best] - tol || (Math.abs(vol[j] - vol[best]) <= tol && Math.abs(j - mid) < Math.abs(best - mid))) best = j;
  }
  return { bottom: lo + best * w, top: lo + (best + 1) * w };
}

function compute(candles, cfg) {
  const k = { ...defaults, ...(cfg || {}) };
  const n = candles.length;
  const L = k.fvPiv;
  if (n < 120) return { signal: null, reason: 'warmup' };

  const { highs, lows } = pivots(candles, L);
  const atr = atrSeries(candles);
  const adx = adxSeries(candles);
  const last = n - 1;
  const b = candles[last];
  const strong = (dir) => {
    const rng = b.h - b.l, body = Math.abs(b.c - b.o);
    const okDir = dir === 1 ? b.c > b.o : b.c < b.o;
    return rng > 0 && okDir && body >= k.fvBodyPct * rng && body >= k.fvBodyAtr * atr[last];
  };

  const tryLong = () => {
    if (highs.length < 2) return null;
    const h1 = highs[highs.length - 1], h0 = highs[highs.length - 2];
    const lowsBefore = lows.filter((i) => i < h1);
    if (lowsBefore.length < 2) return null;
    const l1 = lowsBefore[lowsBefore.length - 1], l0 = lowsBefore[lowsBefore.length - 2];
    if (!(candles[h1].h > candles[h0].h && candles[l1].l > candles[l0].l)) return null;
    const conf = h1 + L; // swing high is known from this bar
    if (last <= conf || last - conf > k.fvMaxWait) return null;
    if (adx[conf] == null || adx[conf] < k.fvAdxMin) return null;
    const legLo = candles[l1].l, legHi = candles[h1].h;
    const zone = lvnZone(candles, l1, h1, legLo, legHi, k.fvBins, 1);
    if (!zone) return null;
    // replay bars since confirmation: cancelled or already used?
    for (let i = conf + 1; i < last; i++) {
      const x = candles[i];
      if (x.c < legLo) return null;
      const rng = x.h - x.l, body = Math.abs(x.c - x.o);
      const st = rng > 0 && x.c > x.o && body >= k.fvBodyPct * rng && body >= k.fvBodyAtr * atr[i];
      if (x.l <= zone.top && st && x.c > zone.top) return null; // entry already happened on an earlier bar
    }
    if (b.c < legLo) return null;
    if (!(b.l <= zone.top && strong(1) && b.c > zone.top)) return null;
    const a = atr[last];
    const sl = Math.min(zone.bottom - k.fvSlBuf * a, b.c - k.fvMinStop * a);
    const risk = b.c - sl;
    if (!(risk > 0) || risk > k.fvMaxStop * a) return null;
    return { dir: 'LONG', entry: b.c, sl, tp: b.c + k.fvRR * risk, a };
  };

  const tryShort = () => {
    if (lows.length < 2) return null;
    const l1 = lows[lows.length - 1], l0 = lows[lows.length - 2];
    const highsBefore = highs.filter((i) => i < l1);
    if (highsBefore.length < 2) return null;
    const h1 = highsBefore[highsBefore.length - 1], h0 = highsBefore[highsBefore.length - 2];
    if (!(candles[l1].l < candles[l0].l && candles[h1].h < candles[h0].h)) return null;
    const conf = l1 + L;
    if (last <= conf || last - conf > k.fvMaxWait) return null;
    if (adx[conf] == null || adx[conf] < k.fvAdxMin) return null;
    const legHi = candles[h1].h, legLo = candles[l1].l;
    const zone = lvnZone(candles, h1, l1, legLo, legHi, k.fvBins, -1);
    if (!zone) return null;
    for (let i = conf + 1; i < last; i++) {
      const x = candles[i];
      if (x.c > legHi) return null;
      const rng = x.h - x.l, body = Math.abs(x.c - x.o);
      const st = rng > 0 && x.c < x.o && body >= k.fvBodyPct * rng && body >= k.fvBodyAtr * atr[i];
      if (x.h >= zone.bottom && st && x.c < zone.bottom) return null;
    }
    if (b.c > legHi) return null;
    if (!(b.h >= zone.bottom && strong(-1) && b.c < zone.bottom)) return null;
    const a = atr[last];
    const sl = Math.max(zone.top + k.fvSlBuf * a, b.c + k.fvMinStop * a);
    const risk = sl - b.c;
    if (!(risk > 0) || risk > k.fvMaxStop * a) return null;
    return { dir: 'SHORT', entry: b.c, sl, tp: b.c - k.fvRR * risk, a };
  };

  const r = tryLong() || tryShort();
  if (!r) return { signal: null, reason: 'no_setup' };
  const long = r.dir === 'LONG';
  return {
    signal: r.dir,
    time: b.t,
    entry: r.entry,
    sl: r.sl,
    tp1: r.tp,
    tp2: r.tp,
    atr: r.a,
    stage: long ? 'ADVANCING' : 'DECLINING',
    htfTrend: 'NA',
    adx: 0,
    bullScore: long ? 3 : 0,
    bearScore: long ? 0 : 3,
    score: 3,
    oppScore: 0,
    netMargin: 3,
    confirmationCandle: true,
    checks: {
      stage: { passed: true, weight: 1, value: long ? 'structure_bull' : 'structure_bear' },
      aov: { passed: true, weight: 1, value: 'lvn_pullback' },
      pattern: { passed: true, weight: 1, value: 'strong_candle' },
      ema: { passed: false, weight: 0, value: 'not_used' },
      smc: { passed: false, weight: 0, value: 'not_used' },
      volume: { passed: true, weight: 1, value: 'tick_volume_profile' },
    },
    setupFingerprint: `FV-${r.dir}`,
  };
}

module.exports = { compute, defaults, window, trailTf, usesHtf: false, name: 'Fabio-style LVN pullback (5m, tick volume)' };
