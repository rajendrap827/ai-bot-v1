const env = require('./config/env');
const { connectDB } = require('./config/db');
const { seedInitialBalance } = require('./config/bootstrap');
const { startChangeStreamWatchers } = require('./events/changeStreamWatcher');
const { createServer } = require('./api/server');
const { startMetaApiFeed } = require('./feeds/metaApiFeed');
const { startMetaApiWorker } = require('./workers/metaApiWorker');
const { runTuningCycle } = require('./tuning/tuner');

const TUNING_INTERVAL_MS = 24 * 60 * 60 * 1000; // daily

// Broker symbol names — override in .env if your account uses a different suffix
const SYMBOLS = {
  BTC: process.env.SYMBOL_BTC || 'BTCUSDm',
  ETH: process.env.SYMBOL_ETH || 'ETHUSDm',
  GOLD: process.env.SYMBOL_GOLD || 'XAUUSDm',
};

async function main() {
  await connectDB();
  await seedInitialBalance();
  startChangeStreamWatchers();

  const { httpServer } = createServer();
  httpServer.listen(env.port, () => console.log(`[api] listening on port ${env.port}`));

  if (!process.env.METAAPI_TOKEN || !process.env.METAAPI_ACCOUNT_ID) {
    console.error('[main] METAAPI_TOKEN and METAAPI_ACCOUNT_ID must be set in .env — cannot start feeds.');
    return;
  }

  const feed = await startMetaApiFeed({
    token: process.env.METAAPI_TOKEN,
    accountId: process.env.METAAPI_ACCOUNT_ID,
    symbols: SYMBOLS,
  });

  await startMetaApiWorker('BTC', feed);
  await startMetaApiWorker('ETH', feed);
  await startMetaApiWorker('GOLD', feed);

  setInterval(async () => {
    for (const asset of ['BTC', 'ETH', 'GOLD']) {
      try {
        const result = await runTuningCycle(asset);
        console.log(result.skipped ? `[tuner:${asset}] skipped — ${result.reason}` : `[tuner:${asset}] reviewed ${result.decisions.length} component(s)`);
      } catch (err) {
        console.error(`[tuner:${asset}] error:`, err.message);
      }
    }
  }, TUNING_INTERVAL_MS);

  console.log('[main] all systems started (Exness via MetaApi for BTC/ETH/GOLD)');
}

main().catch((err) => {
  console.error('[main] fatal startup error:', err);
  process.exit(1);
});
