const MetaApi = require('metaapi.cloud-sdk').default;

/**
 * MetaApi feed — replaces the Wine + MT5 + Python bridge entirely.
 *
 * MetaApi hosts the MetaTrader terminal in their cloud and connects to your
 * Exness demo account there, exposing a streaming API. We get the same broker
 * prices you'd trade on live, without running MT5/Wine/Xvfb on our server.
 *
 * Raw ticks are used only for SL/TP/trailing checks and never stored in
 * MongoDB (same no-raw-tick-storage rule as before).
 */
async function startMetaApiFeed({ token, accountId, symbols }) {
  const api = new MetaApi(token);
  const handlers = {}; // asset -> { onClosedCandle, onTick }
  const lastCandleTime = {}; // asset -> ISO string of last emitted closed candle

  console.log('[metaapi] connecting to account…');
  const account = await api.metatraderAccountApi.getAccount(accountId);

  // Make sure the account is deployed and the terminal is connected
  if (account.state !== 'DEPLOYED') {
    console.log('[metaapi] account not deployed — deploying now…');
    await account.deploy();
  }
  console.log('[metaapi] waiting for broker connection…');
  await account.waitConnected();

  const connection = account.getStreamingConnection();
  await connection.connect();
  await connection.waitSynchronized();
  console.log('[metaapi] connected and synchronized');

  // Subscribe to each symbol's market data
  for (const [asset, symbol] of Object.entries(symbols)) {
    try {
      await connection.subscribeToMarketData(symbol);
      console.log(`[metaapi] subscribed ${asset} -> ${symbol}`);
    } catch (err) {
      console.error(`[metaapi] failed to subscribe ${asset} (${symbol}):`, err.message);
    }
  }

  // Price ticks arrive through a synchronization listener
  const reverse = Object.fromEntries(Object.entries(symbols).map(([a, s]) => [s, a]));

  connection.addSynchronizationListener({
    onSymbolPriceUpdated: async (instanceIndex, price) => {
      const asset = reverse[price.symbol];
      if (!asset) return;
      const h = handlers[asset];
      if (!h) return;
      const mid = price.ask ? (price.bid + price.ask) / 2 : price.bid;
      h.onTick({ price: mid, ts: new Date(price.time || Date.now()) });
    },
  });

  /**
   * MetaApi's streaming API gives ticks, not closed candles, so we poll the
   * historical endpoint for the last closed 5m bar. Polling once a minute is
   * plenty — a 5m bar only closes every 5 minutes, and this keeps us well
   * inside API rate limits.
   */
  async function pollClosedCandles() {
    for (const [asset, symbol] of Object.entries(symbols)) {
      const h = handlers[asset];
      if (!h) continue;
      try {
        const candles = await account.getHistoricalCandles(symbol, '5m', undefined, 2);
        if (!candles || candles.length < 2) continue;
        const closed = candles[candles.length - 2]; // last fully closed bar
        const t = new Date(closed.time).toISOString();
        if (lastCandleTime[asset] === t) continue;
        lastCandleTime[asset] = t;
        h.onClosedCandle({
          t: new Date(closed.time),
          o: closed.open,
          h: closed.high,
          l: closed.low,
          c: closed.close,
          v: closed.tickVolume || 0,
        });
        console.log(`[metaapi] ${asset} closed candle ${t} c=${closed.close}`);
      } catch (err) {
        console.error(`[metaapi] candle poll failed for ${asset}:`, err.message);
      }
    }
  }

  const pollTimer = setInterval(pollClosedCandles, 60 * 1000);
  pollClosedCandles(); // run once immediately

  return {
    /** Workers register their per-asset callbacks here (same shape as the old bridge). */
    register(asset, { onClosedCandle, onTick }) {
      handlers[asset] = { onClosedCandle, onTick };
      console.log(`[metaapi] registered handler for ${asset}`);
    },
    /** Fetches history to warm up a worker's candle buffer at startup. */
    async getHistory(asset, count = 320) {
      const symbol = symbols[asset];
      if (!symbol) return [];
      try {
        const candles = await account.getHistoricalCandles(symbol, '5m', undefined, count);
        return (candles || []).map((c) => ({
          t: new Date(c.time), o: c.open, h: c.high, l: c.low, c: c.close, v: c.tickVolume || 0,
        }));
      } catch (err) {
        console.error(`[metaapi] history fetch failed for ${asset}:`, err.message);
        return [];
      }
    },
    isConnected: () => connection.isSynchronized,
    close: async () => {
      clearInterval(pollTimer);
      await connection.close();
    },
  };
}

module.exports = { startMetaApiFeed };
