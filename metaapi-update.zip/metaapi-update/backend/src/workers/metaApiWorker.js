const { runAssetWorker } = require('./assetWorker');
const { ema } = require('../strategy/indicators');
const Candle = require('../models/Candle');

/**
 * All three assets (BTC, ETH, GOLD) come from the single Exness account via
 * MetaApi, so paper prices match the prices you'd trade live on the same broker.
 *
 * Unlike the old MT5 bridge, MetaApi can give us history immediately, so the
 * worker warms up straight away instead of waiting hours for live candles.
 */
async function startMetaApiWorker(asset, feed, { timeframe = '5m', htfMinutes = 60, htfLen = 50 } = {}) {
  return runAssetWorker({
    asset,
    timeframe,
    seedCandles: async () => {
      // Prefer MetaApi history (instant warmup); fall back to stored candles.
      const hist = await feed.getHistory(asset, 320);
      if (hist && hist.length > 50) return hist;
      const docs = await Candle.find({ asset, timeframe }).sort({ t: -1 }).limit(320).lean();
      return docs.reverse().map((d) => ({ t: d.t, o: d.o, h: d.h, l: d.l, c: d.c, v: d.v }));
    },
    connectFeed: ({ onClosedCandle, onTick }) => {
      feed.register(asset, { onClosedCandle, onTick });
      return { close: () => {} }; // feed lifecycle managed centrally
    },
    getHtfTrend: async () => htfTrendFromCandles(asset, timeframe, htfMinutes, htfLen),
  });
}

/** Resamples stored 5m candles into HTF buckets; EMA trend on the last CLOSED HTF bar. */
async function htfTrendFromCandles(asset, timeframe, htfMinutes, htfLen) {
  const need = (htfLen + 5) * (htfMinutes / 5) + 5;
  const docs = await Candle.find({ asset, timeframe }).sort({ t: -1 }).limit(Math.ceil(need)).lean();
  if (docs.length < (htfMinutes / 5) * 3) return { bull: null, bear: null };
  const rows = docs.reverse();

  const bucketMs = htfMinutes * 60 * 1000;
  const buckets = new Map();
  for (const d of rows) {
    const key = Math.floor(new Date(d.t).getTime() / bucketMs) * bucketMs;
    const b = buckets.get(key);
    if (!b) buckets.set(key, { c: d.c });
    else b.c = d.c;
  }
  const closes = [...buckets.entries()].sort((a, b) => a[0] - b[0]).map(([, v]) => v.c);
  if (closes.length < 3) return { bull: null, bear: null };

  const emaSeries = ema(closes, Math.min(htfLen, closes.length - 1));
  const i = closes.length - 2;
  if (i < 1 || emaSeries[i] == null) return { bull: null, bear: null };
  return { bull: closes[i] > emaSeries[i], bear: closes[i] < emaSeries[i] };
}

module.exports = { startMetaApiWorker };
