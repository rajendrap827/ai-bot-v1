# MetaApi Update — replaces Wine/MT5/Python entirely

All three assets (BTC, ETH, GOLD) now come from your Exness demo account via
MetaApi's cloud, so no MetaTrader terminal, Wine, Xvfb, VNC, or Python bridge
is needed on the server.

## Files in this bundle

| File | Action |
|---|---|
| `backend/src/feeds/metaApiFeed.js` | **New.** Connects to MetaApi, streams ticks + polls closed 5m candles. |
| `backend/src/workers/metaApiWorker.js` | **New.** One worker used for all 3 assets; seeds instantly from MetaApi history. |
| `backend/src/index.js` | **Replace.** Starts the MetaApi feed + 3 workers. |

## No longer needed (safe to delete)

- `backend/src/feeds/mt5Bridge.js`
- `backend/src/workers/mt5Worker.js`
- the whole `python-mt5-bridge/` folder
- Wine, Xvfb, VNC, MetaTrader on the server

## Required .env entries

```
METAAPI_TOKEN=<your token>
METAAPI_ACCOUNT_ID=<your account id>
SYMBOL_BTC=BTCUSDm
SYMBOL_ETH=ETHUSDm
SYMBOL_GOLD=XAUUSDm
```

## Install the SDK

```
cd backend && npm install metaapi.cloud-sdk
```

## Run

```
cd backend && npm start
```

Expect to see: MetaApi connecting, "connected and synchronized", three
`subscribed <ASSET> -> <SYMBOL>` lines, then workers seeding with ~320 candles
each (instant, unlike the old bridge) and closed-candle logs every 5 minutes.

## Note on candles

MetaApi's streaming API delivers ticks; closed 5m bars are polled once a
minute from their historical endpoint. That's well within rate limits and a
5m bar only closes every 5 minutes, so nothing is missed.
